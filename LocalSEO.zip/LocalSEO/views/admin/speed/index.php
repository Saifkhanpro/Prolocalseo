<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Optimize your database and configure performance enhancement settings.</p>
        </div>
        <div class="col-auto">
            <form action="/admin/speed/cleanup" method="POST" class="d-inline">
                <button type="submit" class="btn btn-dark shadow-sm">
                    <i class="bi bi-magic me-2"></i> Optimize Database Now
                </button>
            </form>
        </div>
    </div>

    <div class="row g-4">
        <!-- DB Sizes -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm overflow-hidden">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">Database Utilization</h5>
                </div>
                <div class="card-body p-0">
                    <div class="bg-light p-4 text-center border-bottom">
                        <div class="display-3 fw-bold text-primary mb-1"><?= $totalDbSize ?></div>
                        <p class="text-muted mb-0">Total Storage Footprint</p>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase">
                                <tr>
                                    <th class="ps-4">Table</th>
                                    <th>Rows</th>
                                    <th class="text-end pe-4">Total Size</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($tables, 0, 8) as $t): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold small"><?= $t['Name'] ?></td>
                                        <td><?= number_format($t['Rows']) ?></td>
                                        <td class="text-end pe-4 font-monospace small">
                                            <?= \Core\Helpers::formatBytes($t['Data_length'] + $t['Index_length']) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Settings -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">Speed Tweaks</h5>
                </div>
                <div class="card-body p-4">
                    <form action="/admin/speed/save" method="POST">
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" name="minify_html" id="minifyHtml" value="1" checked>
                            <label class="form-check-label fw-bold" for="minifyHtml">Minify HTML Output</label>
                            <div class="form-text small">Removes whitespaces and comments to reduce page weight.</div>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" name="combine_css" id="combineCss" value="1" checked>
                            <label class="form-check-label fw-bold" for="combineCss">Combine & Minify CSS</label>
                            <div class="form-text small">Consolidates all stylesheets into a single optimized file.</div>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" name="lazy_load" id="lazyLoad" value="1" checked>
                            <label class="form-check-label fw-bold" for="lazyLoad">Native Lazy Loading</label>
                            <div class="form-text small">Delays loading off-screen images to speed up initial paint.</div>
                        </div>
                        <hr class="my-4">
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm">Save Optimization Rules</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
