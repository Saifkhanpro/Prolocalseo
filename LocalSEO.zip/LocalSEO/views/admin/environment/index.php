<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Technical diagnostics and server environment details.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm">
                <a href="/admin/environment" class="btn btn-primary active">System Info</a>
                <a href="/admin/environment/htaccess" class="btn btn-outline-primary">.htaccess Editor</a>
                <a href="/admin/environment/database" class="btn btn-outline-primary">Database Info</a>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-7">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">Server & Software</h5>
                </div>
                <div class="card-body p-4">
                    <table class="table table-borderless align-middle mb-0">
                        <tbody>
                            <tr>
                                <td class="text-muted w-25">PHP Version</td>
                                <td class="fw-bold"><?= $phpVersion ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Server Software</td>
                                <td><?= $serverSoftware ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">MySQL Version</td>
                                <td><?= $mysqlVersion ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Rewrite Engine</td>
                                <td>
                                    <?php if ($isModRewriteEnabled === true): ?>
                                        <span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> Enabled</span>
                                    <?php elseif ($isModRewriteEnabled === false): ?>
                                        <span class="text-danger"><i class="bi bi-x-circle-fill me-1"></i> Disabled</span>
                                    <?php else: ?>
                                        <span class="text-warning"><?= $isModRewriteEnabled ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">PHP Configuration</h5>
                </div>
                <div class="card-body p-4">
                    <div class="mb-3">
                        <small class="text-muted d-block">Max Upload Size</small>
                        <span class="fw-bold"><?= $uploadMaxFilesize ?></span>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">Memory Limit</small>
                        <span class="fw-bold"><?= $memoryLimit ?></span>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted d-block">Execution Time</small>
                        <span class="fw-bold"><?= $maxExecutionTime ?>s</span>
                    </div>
                    <div class="mb-0">
                        <small class="text-muted d-block">Error Display</small>
                        <span class="badge bg-<?= $displayErrors ? 'warning' : 'success' ?> bg-opacity-10 text-<?= $displayErrors ? 'warning' : 'success' ?>">
                            <?= $displayErrors ? 'On' : 'Off' ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
