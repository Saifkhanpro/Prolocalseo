<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Directly manage URL rewriting and server-level rules.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm">
                <a href="/admin/environment" class="btn btn-outline-primary">System Info</a>
                <a href="/admin/environment/htaccess" class="btn btn-primary active">.htaccess Editor</a>
                <a href="/admin/environment/database" class="btn btn-outline-primary">Database Info</a>
            </div>
        </div>
    </div>

    <?php if (!$writable): ?>
        <div class="alert alert-warning mb-4 shadow-sm border-0">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <strong>Permissions Warning:</strong> Your <code>.htaccess</code> file is not writable by the server. Please check file permissions (chmod 644 or 664).
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <form action="/admin/environment/htaccess" method="POST">
                <div class="mb-4">
                    <label class="form-label fw-bold">File Content</label>
                    <textarea name="content" class="form-control font-monospace p-4" rows="15" style="background: #1e293b; color: #e2e8f0; font-size: 0.9rem; line-height: 1.5; border-radius: 12px;" <?= !$writable ? 'disabled' : '' ?>><?= \Core\Helpers::escape($content) ?></textarea>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="text-muted small">
                        <i class="bi bi-info-circle me-1"></i> Be extremely careful. Malformed .htaccess files can take your site offline.
                    </div>
                    <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-sm" <?= !$writable ? 'disabled' : '' ?>>
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
