<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Overview of database tables and storage utilization.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm">
                <a href="/admin/environment" class="btn btn-outline-primary">System Info</a>
                <a href="/admin/environment/htaccess" class="btn btn-outline-primary">.htaccess Editor</a>
                <a href="/admin/environment/database" class="btn btn-primary active">Database Info</a>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">Table Name</th>
                            <th>Engine</th>
                            <th>Collection</th>
                            <th>Rows</th>
                            <th>Data Size</th>
                            <th class="text-end pe-4">Index Size</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tables as $table): ?>
                            <tr>
                                <td class="ps-4 fw-bold"><?= $table['Name'] ?></td>
                                <td><span class="badge bg-secondary bg-opacity-10 text-secondary"><?= $table['Engine'] ?></span></td>
                                <td class="small"><?= $table['Collation'] ?></td>
                                <td><?= number_format($table['Rows']) ?></td>
                                <td class="text-muted"><?= \Core\Helpers::formatBytes($table['Data_length']) ?></td>
                                <td class="text-end pe-4 text-muted"><?= \Core\Helpers::formatBytes($table['Index_length']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
