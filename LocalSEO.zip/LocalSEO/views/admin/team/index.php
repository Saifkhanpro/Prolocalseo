<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Showcase the experts behind your agency.</p>
        </div>
        <div class="col-auto">
            <a href="/admin/team/create" class="btn btn-primary shadow-sm">
                <i class="bi bi-plus-lg me-2"></i> Add Team Member
            </a>
        </div>
    </div>

    <div class="row g-4">
        <?php if (empty($members)): ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm p-5 text-center">
                    <i class="bi bi-people fs-1 text-muted mb-3"></i>
                    <h5 class="fw-bold">No team members yet.</h5>
                    <p class="text-muted">Start by adding your first team member.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($members as $m): ?>
                <div class="col-md-6 col-lg-4 col-xl-3">
                    <div class="card border-0 shadow-sm h-100 text-center transition-hover">
                        <div class="card-body p-4">
                            <div class="bg-light rounded-circle mx-auto mb-3 overflow-hidden shadow-sm" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-person-circle fs-2 text-muted"></i>
                            </div>
                            <h5 class="fw-bold mb-1"><?= \Core\Helpers::escape($m['name']) ?></h5>
                            <small class="text-muted d-block mb-3"><?= \Core\Helpers::escape($m['designation']) ?></small>
                            <div class="badge bg-<?= $m['status'] == 'active' ? 'success' : 'secondary' ?> bg-opacity-10 text-<?= $m['status'] == 'active' ? 'success' : 'secondary' ?> mb-4 px-3 rounded-pill">
                                <?= ucfirst($m['status']) ?>
                            </div>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="/admin/team/edit/<?= $m['id'] ?>" class="btn btn-sm btn-outline-primary px-3 rounded-pill fw-bold">Edit</a>
                                <form action="/admin/team/delete/<?= $m['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Remove member?')">
                                    <button type="submit" class="btn btn-sm btn-outline-danger px-3 rounded-pill fw-bold">Remove</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
