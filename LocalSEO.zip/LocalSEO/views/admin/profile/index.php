<div class="container-fluid">
    <div class="row align-items-center mb-5">
        <div class="col">
            <h1 class="h3 mb-1 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted mb-0">Manage your personal information and login credentials.</p>
        </div>
    </div>

    <div class="row g-4">
        <!-- Profile Info -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm overflow-hidden">
                <div class="card-header bg-white py-3 px-4 fw-bold">Personal Details</div>
                <div class="card-body p-4">
                    <form action="/admin/profile/update" method="POST">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Username</label>
                                <input type="text" class="form-control bg-light" value="<?= \Core\Helpers::escape($user['username']) ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?= \Core\Helpers::escape($user['email']) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">First Name</label>
                                <input type="text" name="first_name" class="form-control" value="<?= \Core\Helpers::escape($user['first_name'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Last Name</label>
                                <input type="text" name="last_name" class="form-control" value="<?= \Core\Helpers::escape($user['last_name'] ?? '') ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold">Biographical Info</label>
                                <textarea name="bio" class="form-control" rows="4"><?= \Core\Helpers::escape($user['bio'] ?? '') ?></textarea>
                            </div>
                        </div>
                        <div class="mt-5 text-end">
                            <button type="submit" class="btn btn-primary px-5 fw-bold shadow-sm">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar Actions -->
        <div class="col-lg-4">
            <!-- Account Avatar -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body text-center p-5">
                    <div class="bg-light rounded-circle mx-auto mb-4 overflow-hidden shadow-sm" style="width: 120px; height: 120px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-person-fill text-muted" style="font-size: 4rem;"></i>
                    </div>
                    <form action="/admin/profile/avatar" method="POST" enctype="multipart/form-data">
                        <input type="file" name="avatar" class="d-none" id="avatarInput">
                        <button type="button" class="btn btn-sm btn-outline-dark px-4 rounded-pill fw-bold" onclick="document.getElementById('avatarInput').click()">Change Picture</button>
                    </form>
                </div>
            </div>

            <!-- Password Change -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 px-4 fw-bold">Change Password</div>
                <div class="card-body p-4">
                    <form action="/admin/profile/password" method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-bold">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-dark w-100 fw-bold py-2 shadow-sm">Reset Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
