<div class="container-fluid">
    <div class="row mb-5 align-items-center">
        <div class="col">
            <h1 class="h3 mb-1 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted mb-0">Platform maintenance utilities and administrative tools.</p>
        </div>
    </div>

    <div class="row g-4">
        <!-- Site Health -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100 transition-hover">
                <div class="card-body p-4">
                    <div class="bg-danger bg-opacity-10 text-danger p-3 rounded-3 d-inline-block mb-4">
                        <i class="bi bi-heart-pulse fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Site Health</h5>
                    <p class="text-muted small mb-4">Run diagnostic checks to identify technical SEO gaps and server misconfigurations.</p>
                    <a href="/admin/tools/site-health" class="btn btn-outline-danger w-100 fw-bold px-4 py-2">Check Health &rarr;</a>
                </div>
            </div>
        </div>

        <!-- Export -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100 transition-hover">
                <div class="card-body p-4">
                    <div class="bg-primary bg-opacity-10 text-primary p-3 rounded-3 d-inline-block mb-4">
                        <i class="bi bi-cloud-download fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Export Data</h5>
                    <p class="text-muted small mb-4">Download your content, leads, and SEO data in XML or CSV format for backups or external use.</p>
                    <a href="/admin/tools/export" class="btn btn-outline-primary w-100 fw-bold px-4 py-2">Export Content &rarr;</a>
                </div>
            </div>
        </div>

        <!-- Import -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100 transition-hover">
                <div class="card-body p-4">
                    <div class="bg-success bg-opacity-10 text-success p-3 rounded-3 d-inline-block mb-4">
                        <i class="bi bi-cloud-upload fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Import Data</h5>
                    <p class="text-muted small mb-4">Bulk import posts, services, and city pages from other platforms or LocalSEO migrations.</p>
                    <a href="/admin/tools/import" class="btn btn-outline-success w-100 fw-bold px-4 py-2">Start Import &rarr;</a>
                </div>
            </div>
        </div>

        <!-- Backup -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100 transition-hover">
                <div class="card-body p-4">
                    <div class="bg-warning bg-opacity-10 text-warning p-3 rounded-3 d-inline-block mb-4">
                        <i class="bi bi-server fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">System Backups</h5>
                    <p class="text-muted small mb-4">Create full snapshots of your database and critical configuration files.</p>
                    <a href="/admin/tools/backup" class="btn btn-outline-warning w-100 fw-bold px-4 py-2">Manage Backups &rarr;</a>
                </div>
            </div>
        </div>
    </div>
</div>
