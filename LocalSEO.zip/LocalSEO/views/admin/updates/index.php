<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="text-center mb-5">
                <div class="display-1 text-primary mb-3"><i class="bi bi-arrow-repeat"></i></div>
                <h1 class="h2 fw-bold text-gray-800"><?= $pageTitle ?></h1>
                <p class="text-muted lead">Keep your LocalSEO.pk engine up to date with the latest features and security patches.</p>
            </div>

            <div class="card border-0 shadow-lg overflow-hidden mb-4">
                <div class="card-body p-0">
                    <div class="row g-0">
                        <div class="col-md-4 bg-primary text-white p-5 text-center d-flex flex-column justify-content-center">
                            <small class="text-uppercase ls-1 opacity-75 mb-2">Current Version</small>
                            <div class="display-4 fw-bold mb-3"><?= $currentVersion ?></div>
                            <div class="badge bg-white text-primary px-3 py-2 rounded-pill fw-bold">Stable Branch</div>
                        </div>
                        <div class="col-md-8 p-5">
                            <div class="mb-4">
                                <h5 class="fw-bold mb-1">Checking for updates...</h5>
                                <p class="text-muted small">Last checked: <?= $lastCheck ?></p>
                            </div>

                            <?php if ($updateAvailable): ?>
                                <div class="alert alert-warning border-0 p-4 mb-4">
                                    <h6 class="fw-bold mb-2"><i class="bi bi-exclamation-triangle-fill me-2"></i> Update Available!</h6>
                                    <p class="mb-0 small text-dark opacity-75">A more recent version is available. We recommend updating to maintain technical SEO standards and peak performance.</p>
                                </div>
                                <div class="d-grid">
                                    <form action="/admin/updates/install" method="POST">
                                        <button type="submit" class="btn btn-primary btn-lg fw-bold py-3 shadow-sm border-0">
                                            <i class="bi bi-cloud-download me-2"></i> Install Latest Update
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-success border-0 p-4 mb-4">
                                    <h6 class="fw-bold mb-2"><i class="bi bi-check-circle-fill me-2"></i> System is Current</h6>
                                    <p class="mb-0 small text-dark opacity-75">You are running the latest version of the LocalSEO platform. No updates are currently needed.</p>
                                </div>
                                <form action="/admin/updates/check" method="POST">
                                    <button type="submit" class="btn btn-outline-primary w-100 py-3 fw-bold">
                                        Check for Updates Now
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Platform Integrity</h5>
                    <a href="/admin/updates/history" class="text-decoration-none small fw-bold">View history &rarr;</a>
                </div>
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-success bg-opacity-10 text-success p-2 rounded me-3"><i class="bi bi-shield-check fs-4"></i></div>
                        <div>
                            <div class="fw-bold">Security Compliance</div>
                            <small class="text-muted">All active security protocols are aligned with version <?= $currentVersion ?>.</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-0">
                        <div class="bg-info bg-opacity-10 text-info p-2 rounded me-3"><i class="bi bi-regex fs-4"></i></div>
                        <div>
                            <div class="fw-bold">SEO Algorithm Sync</div>
                            <small class="text-muted">Core SEO modules are synchronized with the latest search engine ranking factors.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
