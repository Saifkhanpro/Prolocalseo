<?php ob_start(); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="text-center mb-5">
            <i class="bi bi-arrow-repeat text-primary" style="font-size: 4rem;"></i>
            <h2 class="h3 fw-bold mt-3"><?= $pageTitle ?></h2>
            <p class="text-muted">Ensure your LocalSEO engine is running the latest core, security patches, and SEO algorithm alignments.</p>
        </div>

        <div class="card border-0 shadow border-top border-primary border-4 p-4">
            <div class="card-body text-center">
                <div class="mb-5">
                    <h5 class="text-muted mb-2 text-uppercase letter-spacing" style="font-size: 0.85rem;">Currently Installed Version</h5>
                    <div class="display-3 fw-bold text-dark"><?= LSEO_VERSION ?></div>
                </div>

                <?php if($updateInfo['has_update']): ?>
                    <div class="alert alert-warning py-4 mb-4 text-start shadow-sm border-0 bg-warning bg-opacity-10">
                        <div class="d-flex">
                            <i class="bi bi-exclamation-circle text-warning fs-1 me-3"></i>
                            <div>
                                <h4 class="alert-heading fw-bold">An update is available!</h4>
                                <p class="mb-0 text-dark">Version <strong><?= htmlspecialchars($updateInfo['latest_version']) ?></strong> has been officially released. We highly recommend applying this update to maintain technical SEO standards and patch security gaps.</p>
                            </div>
                        </div>
                    </div>
                    
                    <ul class="text-start mb-4 text-muted pt-2 border-top">
                        <li><strong>Release Date:</strong> <?= date('F j, Y', strtotime($updateInfo['release_date'])) ?></li>
                        <li><strong>Severity:</strong> <span class="badge bg-danger">Critical</span> Updates</li>
                        <li><strong>Changelog:</strong> Enhanced JSON-LD generation speed, Core Web Vitals optimizations, Editor bugfixes.</li>
                    </ul>

                    <form method="POST" action="/admin/system/updates/process" id="updateForm">
                        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                        <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold py-3 shadow" onclick="if(!confirm('IMPORTANT: It is recommended to backup your database before updating. Continue?')) return false; this.innerHTML='<i class=\'spinner-border spinner-border-sm me-2\'></i> Applying Update...'; this.classList.add('disabled');">
                            <i class="bi bi-cloud-download me-2"></i> Update to Version <?= htmlspecialchars($updateInfo['latest_version']) ?>
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-success py-4 mb-0 text-start shadow-sm border-0 d-flex align-items-center">
                        <i class="bi bi-check-circle-fill text-success fs-1 me-4"></i>
                        <div>
                            <h5 class="alert-heading fw-bold mb-1">You are completely up to date.</h5>
                            <p class="mb-0 text-dark small">Your CMS is running the latest available branch. No required security patches or SEO module updates are pending.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <p class="text-center text-muted small mt-4">
            <i class="bi bi-shield-check"></i> Connected securely to update servers.
        </p>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
