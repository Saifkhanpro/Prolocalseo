<?php
use Core\Helpers;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Helpers::escape($pageTitle ?? 'Admin Panel') ?> — LocalSEO.pk</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/assets/css/admin.css?v=<?= LSEO_VERSION ?>">
    
    <?= $extraHead ?? '' ?>
</head>
<body class="bg-light">

    <?php include VIEW_PATH . '/partials/admin-sidebar.php'; ?>
    
    <div class="admin-wrapper" style="margin-left: 260px;">
        <?php include VIEW_PATH . '/partials/admin-topbar.php'; ?>
        
        <div class="admin-content p-4">
            <?php if ($flash = Helpers::flash('success')): ?>
                <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($flash = Helpers::flash('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php include VIEW_PATH . '/partials/update-notification.php'; ?>

            <!-- View Content Injection -->
            <?= $content ?>
        </div>

        <footer class="admin-footer p-4 text-center mt-auto border-top bg-white">
            <small class="text-muted text-uppercase fw-bold letter-spacing-1">
                LocalSEO.pk CMS v<?= LSEO_VERSION ?> &bull; &copy; <?= date('Y') ?> All Rights Reserved
            </small>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="/assets/js/admin.js?v=<?= LSEO_VERSION ?>"></script>
    
    <?= $extraFooter ?? '' ?>
</body>
</html>
