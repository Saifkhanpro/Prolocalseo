<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Manage 301 and 302 redirects to maintain SEO equity.</p>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addRedirectModal">
                <i class="bi bi-plus-lg me-2"></i> Add New Redirect
            </button>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">Source URL</th>
                            <th>Target URL</th>
                            <th>Type</th>
                            <th>Match</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($redirects)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <i class="bi bi-arrow-left-right fs-1 text-muted d-block mb-2"></i>
                                    No redirects found.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($redirects as $r): ?>
                                <tr>
                                    <td class="ps-4">
                                        <code class="text-danger"><?= \Core\Helpers::escape($r['old_url']) ?></code>
                                    </td>
                                    <td>
                                        <code class="text-success"><?= \Core\Helpers::escape($r['new_url']) ?></code>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $r['type'] == 301 ? 'primary' : 'info' ?> bg-opacity-10 text-<?= $r['type'] == 301 ? 'primary' : 'info' ?>">
                                            <?= $r['type'] ?>
                                        </span>
                                    </td>
                                    <td class="small text-muted"><?= ucfirst($r['match_type']) ?></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" <?= $r['is_active'] ? 'checked' : '' ?> disabled>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-light btn-sm rounded-circle me-1" title="Edit"><i class="bi bi-pencil"></i></button>
                                        <form action="/admin/redirects/delete/<?= $r['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this redirect?')">
                                            <button type="submit" class="btn btn-light btn-sm rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Redirect Modal -->
<div class="modal fade" id="addRedirectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">New URL Redirect</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="/admin/redirects/store" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Old URL / Path</label>
                        <input type="text" name="old_url" class="form-control" placeholder="/old-slug" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">New URL / Path</label>
                        <input type="text" name="new_url" class="form-control" placeholder="/new-slug" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Redirect Type</label>
                            <select name="type" class="form-select">
                                <option value="301">301 (Permanent)</option>
                                <option value="302">302 (Found)</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Match Type</label>
                            <select name="match_type" class="form-select">
                                <option value="exact">Exact Path</option>
                                <option value="regex">Regex Match</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-check form-switch mt-2">
                        <input class="form-check-input" type="checkbox" name="is_active" id="active" value="1" checked>
                        <label class="form-check-label fw-bold" for="active">Enable redirect immediately</label>
                    </div>
                </div>
                <div class="modal-footer bg-light border-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4">Create Redirect</button>
                </div>
            </form>
        </div>
    </div>
</div>
