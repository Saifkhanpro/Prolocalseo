<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Manage XML sitemaps for Google, Bing, and other search engines.</p>
        </div>
        <div class="col-auto">
            <form action="/admin/sitemap/generate" method="POST" class="d-inline">
                <button type="submit" class="btn btn-primary shadow-sm">
                    <i class="bi bi-arrow-repeat me-2"></i> Regenerate Sitemap
                </button>
            </form>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 text-center">
                    <i class="bi bi-bezier2 fs-1 text-primary mb-3"></i>
                    <h5 class="fw-bold">Status</h5>
                    <p class="text-muted mb-0">Your master sitemap index is live at:</p>
                    <a href="<?= $sitemapUrl ?>" target="_blank" class="d-block mt-2 fw-bold text-decoration-none"><?= $sitemapUrl ?></a>
                    <hr class="my-3">
                    <small class="text-muted">Last generated: <br><strong><?= $lastGenerated ?></strong></small>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">Sitemap Configuration</h5>
                </div>
                <div class="card-body p-4">
                    <form action="/admin/sitemap/save" method="POST">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="include_posts" id="incPosts" value="1" <?= \Core\Helpers::setting('sitemap_include_posts', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="incPosts">Include Blog Posts</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="include_pages" id="incPages" value="1" <?= \Core\Helpers::setting('sitemap_include_pages', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="incPages">Include Static Pages</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="include_images" id="incImages" value="1" <?= \Core\Helpers::setting('sitemap_include_images', '1') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="incImages">Include Image Metadata</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Sitemap Update Frequency</label>
                                <select name="frequency" class="form-select mb-4">
                                    <option value="always">Always</option>
                                    <option value="hourly">Hourly</option>
                                    <option value="daily">Daily</option>
                                    <option value="weekly" selected>Weekly</option>
                                    <option value="monthly">Monthly</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-dark px-5 mt-3">Save Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
