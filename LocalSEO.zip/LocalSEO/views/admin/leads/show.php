<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Lead Details: <span class="text-primary"><?= htmlspecialchars($lead['full_name']) ?></span></h2>
    <a href="/admin/leads" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Inbox</a>
</div>

<div class="row g-4">
    <!-- Left Col: Client Data -->
    <div class="col-lg-8">
        <div class="card bg-white shadow-sm border-0 mb-4">
            <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                <span><i class="bi bi-person me-2"></i> Client Information</span>
                <span class="small fw-normal text-muted">Submitted: <?= date('F j, Y, g:i a', strtotime($lead['created_at'])) ?></span>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <label class="text-muted small fw-bold uppercase">Full Name</label>
                        <div class="fs-5 fw-bold"><?= htmlspecialchars($lead['full_name']) ?></div>
                    </div>
                    <div class="col-sm-6">
                        <label class="text-muted small fw-bold uppercase">Status</label>
                        <?php
                            $badges = ['new' => 'danger', 'contacted' => 'warning', 'qualified' => 'info', 'converted' => 'success', 'closed' => 'secondary'];
                            $col = $badges[$lead['status']] ?? 'primary';
                        ?>
                        <div><span class="badge bg-<?= $col ?> fs-6"><?= ucfirst($lead['status']) ?></span></div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <label class="text-muted small fw-bold uppercase">Email Address</label>
                        <div class="fw-medium"><a href="mailto:<?= htmlspecialchars($lead['email']) ?>"><?= htmlspecialchars($lead['email']) ?></a></div>
                    </div>
                    <div class="col-sm-6">
                        <label class="text-muted small fw-bold uppercase">Phone Number</label>
                        <div class="fw-medium"><a href="tel:<?= htmlspecialchars($lead['phone']) ?>"><?= htmlspecialchars($lead['phone']) ?></a></div>
                    </div>
                </div>

                <div class="row justify-content-between bg-light p-3 rounded mb-4 mx-0 border">
                    <div class="col-md-4 mb-2 mb-md-0">
                        <label class="text-muted small fw-bold uppercase">City / Location</label>
                        <div class="fw-bold"><?= htmlspecialchars($lead['city'] ?? 'Not specified') ?></div>
                    </div>
                    <div class="col-md-4 mb-2 mb-md-0">
                        <label class="text-muted small fw-bold uppercase">Service Needed</label>
                        <div class="fw-bold text-primary"><?= htmlspecialchars($lead['service_needed']) ?></div>
                    </div>
                    <div class="col-md-4">
                        <label class="text-muted small fw-bold uppercase">WhatsApp Link</label>
                        <div>
                            <?php if(!empty($lead['whatsapp_number'])): ?>
                                <?php $wa = preg_replace('/[^0-9]/', '', $lead['whatsapp_number']); ?>
                                <a href="https://wa.me/<?= $wa ?>" target="_blank" class="btn btn-sm btn-success"><i class="bi bi-whatsapp"></i> Chat</a>
                            <?php else: ?>
                                <span class="text-muted">Not provided</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="mb-0">
                    <label class="text-muted small fw-bold uppercase mb-2">Message</label>
                    <div class="bg-white border rounded p-3 text-dark fw-medium" style="white-space: pre-wrap; font-size: 1.05rem;"><?= htmlspecialchars($lead['message']) ?></div>
                </div>
            </div>
        </div>

        <!-- System & Tracking Data -->
        <div class="card bg-white shadow-sm border-0">
            <div class="card-header bg-white fw-bold"><i class="bi bi-geo-alt me-2"></i> Source & Tracking Data</div>
            <div class="card-body p-0">
                <table class="table table-borderless mb-0">
                    <tbody>
                        <tr class="border-bottom">
                            <td class="text-muted w-25">Source URL</td>
                            <td class="fw-medium"><a href="<?= htmlspecialchars($lead['source_url'] ?? '#') ?>" target="_blank"><?= htmlspecialchars($lead['source_url'] ?? 'Direct/Unknown') ?></a></td>
                        </tr>
                        <tr class="border-bottom">
                            <td class="text-muted">IP Address</td>
                            <td class="fw-medium text-monospace"><?= htmlspecialchars($lead['ip_address'] ?? '--') ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">User Agent</td>
                            <td class="small text-muted"><?= htmlspecialchars($lead['user_agent'] ?? '--') ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right Col: Lead CRM Action Panel -->
    <div class="col-lg-4">
        <form method="POST" action="/admin/leads/update">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            <input type="hidden" name="id" value="<?= $lead['id'] ?>">

            <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                <div class="card-header bg-white fw-bold">Update Lead</div>
                <div class="card-body bg-light">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Change Status</label>
                        <select name="status" class="form-select form-select-lg shadow-sm">
                            <option value="new" <?= $lead['status']==='new'?'selected':'' ?>>&#128308; New</option>
                            <option value="contacted" <?= $lead['status']==='contacted'?'selected':'' ?>>&#128304; Contacted</option>
                            <option value="qualified" <?= $lead['status']==='qualified'?'selected':'' ?>>&#128309; Qualified</option>
                            <option value="converted" <?= $lead['status']==='converted'?'selected':'' ?>>&#128994; Converted (Won)</option>
                            <option value="closed" <?= $lead['status']==='closed'?'selected':'' ?>>&#9899; Closed (Lost)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Assigned To</label>
                        <select name="assigned_to" class="form-select">
                            <option value="0">Unassigned</option>
                            <?php foreach($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $lead['assigned_to'] == $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['display_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Private Admin Notes</label>
                        <textarea name="notes" class="form-control shadow-sm" rows="5" placeholder="Add details from phone calls, quotes sent, etc..."><?= htmlspecialchars($lead['notes'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm">Update Lead Record</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
