<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Manage your website's performance and caching layers.</p>
        </div>
        <div class="col-auto">
            <form action="/admin/cache/clear-all" method="POST" class="d-inline">
                <button type="submit" class="btn btn-danger shadow-sm">
                    <i class="bi bi-trash3-fill me-2"></i> Clear All Cache
                </button>
            </form>
        </div>
    </div>

    <div class="row g-4">
        <!-- Page Cache Card -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-3 text-primary me-3">
                            <i class="bi bi-browser-safari fs-3"></i>
                        </div>
                        <div>
                            <h5 class="card-title mb-0">Page Cache</h5>
                            <small class="text-muted">Static HTML versions of your pages</small>
                        </div>
                    </div>
                    <div class="display-6 fw-bold mb-2"><?= $pageCacheCount ?></div>
                    <p class="text-muted small mb-4">Total Files: <?= $pageCacheSize ?></p>
                    <form action="/admin/cache/clear/pages" method="POST">
                        <button type="submit" class="btn btn-outline-primary w-100">Clear Page Cache</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Object Cache Card -->
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="bg-success bg-opacity-10 p-3 rounded-3 text-success me-3">
                            <i class="bi bi-database-fill fs-3"></i>
                        </div>
                        <div>
                            <h5 class="card-title mb-0">Object Cache</h5>
                            <small class="text-muted">Cached database results and API data</small>
                        </div>
                    </div>
                    <div class="display-6 fw-bold mb-2"><?= $objectCacheCount ?></div>
                    <p class="text-muted small mb-4">Total Files: <?= $objectCacheSize ?></p>
                    <form action="/admin/cache/clear/objects" method="POST">
                        <button type="submit" class="btn btn-outline-success w-100">Clear Object Cache</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Cache Settings -->
        <div class="col-lg-12 mt-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0 pt-4 px-4">
                    <h5 class="fw-bold mb-0">Cache Configuration</h5>
                </div>
                <div class="card-body p-4">
                    <form action="/admin/cache/save" method="POST">
                        <div class="row g-4">
                            <div class="col-md-4">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="cache_enabled" id="cacheEnabled" value="1" <?= $cacheEnabled ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="cacheEnabled">Enable Global Caching</label>
                                    <div class="form-text">Master switch for all caching mechanisms.</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Default TTL (Seconds)</label>
                                <input type="number" name="cache_ttl" class="form-control" value="3600">
                                <div class="form-text">How long to keep cached data (default: 1 hour).</div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check form-switch mb-3 mt-4">
                                    <input class="form-check-input" type="checkbox" name="cache_separate_mobile" id="mobileCache" value="1" checked>
                                    <label class="form-check-label fw-bold" for="mobileCache">Separate Mobile Cache</label>
                                    <div class="form-text">Store different cache versions for mobile devices.</div>
                                </div>
                            </div>
                        </div>
                        <hr class="my-4">
                        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold">Save Cache Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
