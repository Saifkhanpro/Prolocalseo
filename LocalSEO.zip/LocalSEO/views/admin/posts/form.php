<?php ob_start(); ?>

<form method="POST" action="/admin/posts/save">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <input type="hidden" name="id" value="<?= $post['id'] ?? 0 ?>">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save Post</button>
    </div>

    <div class="row g-4">
        <!-- Main Content Area -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Post Title</label>
                        <input type="text" name="title" class="form-control form-control-lg" required value="<?= htmlspecialchars($post['title'] ?? '') ?>">
                        <?php if(isset($post['slug'])): ?>
                            <div class="form-text mt-2"><i class="bi bi-link-45deg"></i> Permalink: <strong><?= rtrim(APP_URL, '/') ?>/blog/<?= htmlspecialchars($post['slug']) ?></strong></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Content</label>
                        <textarea name="content" class="wysiwyg form-control"><?= htmlspecialchars($post['content'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Excerpt</label>
                        <textarea name="excerpt" class="form-control" rows="3"><?= htmlspecialchars($post['excerpt'] ?? '') ?></textarea>
                        <div class="form-text">Optional hand-crafted summary. Ideal for blog listings.</div>
                    </div>
                </div>
            </div>

            <!-- Pre-Built Rank Math Style SEO Module box -->
            <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0 text-primary"><i class="bi bi-search me-2"></i> Rank Math SEO Parameters</h5>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs mb-3" id="seoTabs">
                        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#general">General</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#advanced">Advanced</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#schema">Schema Setup</a></li>
                    </ul>
                    
                    <div class="tab-content">
                        <!-- General Tab -->
                        <div class="tab-pane fade show active" id="general">
                            <div class="mb-3">
                                <label class="form-label fw-bold fw-bold">Focus Keyword</label>
                                <input type="text" name="focus_keyword" class="form-control" placeholder="e.g. Local SEO Services" value="<?= htmlspecialchars($post['focus_keyword'] ?? '') ?>">
                                <div class="form-text text-success">Enter multiple comma-separated keywords in Secondary Keywords below.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Secondary Keywords</label>
                                <input type="text" name="secondary_keywords" class="form-control" value="<?= htmlspecialchars($post['secondary_keywords'] ?? '') ?>">
                            </div>
                            
                            <hr class="my-4">
                            <h6 class="fw-bold mb-3">Snippet Editor (SERP Preview)</h6>
                            <div class="mb-3">
                                <label class="form-label fw-bold">SEO Title</label>
                                <input type="text" name="seo_title" class="form-control" value="<?= htmlspecialchars($post['seo_title'] ?? '') ?>" placeholder="Defaults to Post Title if blank">
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Meta Description</label>
                                <textarea name="meta_description" class="form-control" rows="3"><?= htmlspecialchars($post['meta_description'] ?? '') ?></textarea>
                            </div>
                        </div>

                        <!-- Advanced Tab -->
                        <div class="tab-pane fade" id="advanced">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Robots Meta (Index)</label>
                                <select name="robots_index" class="form-select">
                                    <option value="default" <?= ($post['robots_index'] ?? '') == 'default' ? 'selected' : '' ?>>Default (Index)</option>
                                    <option value="noindex" <?= ($post['robots_index'] ?? '') == 'noindex' ? 'selected' : '' ?>>No Index</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Robots Meta (Follow)</label>
                                <select name="robots_follow" class="form-select">
                                    <option value="default" <?= ($post['robots_follow'] ?? '') == 'default' ? 'selected' : '' ?>>Default (Follow)</option>
                                    <option value="nofollow" <?= ($post['robots_follow'] ?? '') == 'nofollow' ? 'selected' : '' ?>>No Follow</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Canonical URL</label>
                                <input type="url" name="canonical_url" class="form-control" placeholder="Leave blank for default" value="<?= htmlspecialchars($post['canonical_url'] ?? '') ?>">
                            </div>
                        </div>

                        <!-- Schema Tab -->
                        <div class="tab-pane fade" id="schema">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Primary Schema Type</label>
                                <select name="schema_type" class="form-select">
                                    <option value="Article" <?= ($post['schema_type'] ?? '') == 'Article' ? 'selected' : '' ?>>Article / Blog Post</option>
                                    <option value="NewsArticle" <?= ($post['schema_type'] ?? '') == 'NewsArticle' ? 'selected' : '' ?>>News Article</option>
                                    <option value="FAQPage" <?= ($post['schema_type'] ?? '') == 'FAQPage' ? 'selected' : '' ?>>FAQ Page</option>
                                    <option value="HowTo" <?= ($post['schema_type'] ?? '') == 'HowTo' ? 'selected' : '' ?>>How-To</option>
                                </select>
                            </div>
                            <div class="alert alert-info py-2 small mb-0"><i class="bi bi-info-circle"></i> Basic JSON-LD Schema is generated automatically based on this selection. You can configure global schema defaults in SEO settings.</div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Sidebar Area -->
        <div class="col-lg-4">
            <!-- Publishing Box -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Publishing</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= ($post['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="pending" <?= ($post['status'] ?? '') === 'pending' ? 'selected' : '' ?>>Pending Review</option>
                            <option value="published" <?= ($post['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Publish Date</label>
                        <input type="datetime-local" name="published_at" class="form-control" value="<?= isset($post['published_at']) ? date('Y-m-d\TH:i', strtotime($post['published_at'])) : date('Y-m-d\TH:i') ?>">
                    </div>

                    <?php if(isset($post['seo_score'])): ?>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="small fw-bold">SEO Score:</span>
                        <span class="badge bg-<?= $post['seo_score'] >= 80 ? 'success' : 'warning' ?>"><?= $post['seo_score'] ?>/100</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="small fw-bold">Readability:</span>
                        <span class="badge bg-<?= $post['readability_score'] >= 60 ? 'success' : 'warning' ?>"><?= $post['readability_score'] ?>/100</span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer bg-light text-end">
                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </div>
            </div>

            <!-- Categories Box -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Categories</div>
                <div class="card-body" style="max-height: 200px; overflow-y: auto;">
                    <?php 
                        $selectedCats = $postCategories ?? [];
                        function renderCatTreeForm($cats, $selected) {
                            echo '<ul class="list-unstyled mb-0 ms-3">';
                            foreach($cats as $c) {
                                $checked = in_array($c['id'], $selected) ? 'checked' : '';
                                echo "<li><label class='form-check-label'><input type='checkbox' name='categories[]' value='{$c['id']}' class='form-check-input me-1' $checked> ".htmlspecialchars($c['name'])."</label>";
                                if(!empty($c['children'])) renderCatTreeForm($c['children'], $selected);
                                echo "</li>";
                            }
                            echo '</ul>';
                        }
                        if(empty($categories)) {
                            echo '<em class="text-muted small">No categories. Add them in Categories menu.</em>';
                        } else {
                            renderCatTreeForm($categories, $selectedCats);
                        }
                    ?>
                </div>
            </div>

            <!-- Tags Box -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Tags</div>
                <div class="card-body">
                    <input type="text" name="tags" class="form-control" placeholder="seo, marketing, local..." value="<?= htmlspecialchars($tagsString ?? '') ?>">
                    <div class="form-text small">Comma separated list of tags.</div>
                </div>
            </div>

            <!-- Featured Image Box -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Featured Image</div>
                <div class="card-body text-center">
                    <input type="hidden" name="featured_image_id" id="featured_image_id" value="<?= $post['featured_image_id'] ?? '' ?>">
                    
                    <div id="image-preview" class="mb-3 <?= empty($featuredImageUrl) ? 'd-none' : '' ?>">
                        <img src="<?= htmlspecialchars($featuredImageUrl ?? '') ?>" class="img-fluid rounded border" alt="Featured Image Preview">
                    </div>
                    
                    <button type="button" class="btn btn-outline-secondary w-100" onclick="alert('Media Library Selection UI would open here');">
                        <i class="bi bi-image"></i> Select / Upload Image
                    </button>
                    <!-- In a full implementation, this triggers a JS modal to select from Media API -->
                </div>
            </div>
            
        </div>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
