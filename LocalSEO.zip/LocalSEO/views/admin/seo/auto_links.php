<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-link-45deg me-2 text-primary"></i> <?= $pageTitle ?></h2>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#autolinkModal">
        <i class="bi bi-plus-lg"></i> New Auto-Link Rule
    </button>
</div>

<div class="alert alert-info py-3 border-0 shadow-sm d-flex align-items-center">
    <i class="bi bi-info-circle-fill fs-2 text-info me-3"></i>
    <div>
        <strong>What is this?</strong> Automated Internal Links scan your published blog content dynamically and automatically inject anchor links. E.g. If you set "SEO" to link to "/services/seo", every post mentioning "SEO" will automatically have a hyperlink inserted, driving link juice perfectly.
    </div>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Keyword Phrase</th>
                    <th>Target URL</th>
                    <th>Max/Post</th>
                    <th>Priority</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($links)): ?>
                    <tr><td colspan="5" class="text-center py-5 text-muted">No automation rules configured.</td></tr>
                <?php else: ?>
                    <?php foreach($links as $l): ?>
                        <tr>
                            <td>
                                <div class="fw-bold text-dark mb-1">"<?= htmlspecialchars($l['keyword']) ?>"</div>
                                <div class="small">
                                    <a href="#" class="text-primary text-decoration-none" onclick="editLink(<?= htmlspecialchars(json_encode($l)) ?>)">Edit</a>
                                </div>
                            </td>
                            <td><a href="<?= htmlspecialchars($l['target_url']) ?>" target="_blank" class="small"><?= htmlspecialchars($l['target_url']) ?></a></td>
                            <td><span class="badge bg-light text-dark border"><?= $l['max_links_per_post'] ?> times</span></td>
                            <td><?= $l['priority'] ?></td>
                            <td>
                                <?php if($l['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Paused</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="autolinkModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="/admin/seo/auto-links/save" id="autolinkForm">
          <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
          <input type="hidden" name="id" id="al_id" value="0">
          
          <div class="modal-header">
            <h5 class="modal-title fw-bold" id="modalTitle">Auto-Link Rule</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Keyword / Phrase</label>
                <input type="text" name="keyword" id="al_keyword" class="form-control" required placeholder="e.g. Local SEO Services">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Target URL (Internal or External)</label>
                <input type="text" name="target_url" id="al_target" class="form-control" required placeholder="/services/local-seo">
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold small">Max Links Per Post</label>
                    <input type="number" name="max_links_per_post" id="al_max" class="form-control" value="1" min="1" max="100">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold small">Execution Priority</label>
                    <input type="number" name="priority" id="al_priority" class="form-control" value="10">
                </div>
            </div>
            <div class="form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" name="is_active" id="al_active" value="1" checked>
                <label class="form-check-label fw-bold small" for="al_active">Rule is Active</label>
            </div>
          </div>
          <div class="modal-footer bg-light">
            <button type="submit" class="btn btn-primary w-100 fw-bold">Save Configuration</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script>
function editLink(data) {
    document.getElementById('al_id').value = data.id;
    document.getElementById('al_keyword').value = data.keyword;
    document.getElementById('al_target').value = data.target_url;
    document.getElementById('al_max').value = data.max_links_per_post;
    document.getElementById('al_priority').value = data.priority;
    document.getElementById('al_active').checked = data.is_active == 1;
    
    var myModal = new bootstrap.Modal(document.getElementById('autolinkModal'));
    myModal.show();
}

document.getElementById('autolinkModal').addEventListener('hidden.bs.modal', function () {
    document.getElementById('autolinkForm').reset();
    document.getElementById('al_id').value = '0';
});
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
