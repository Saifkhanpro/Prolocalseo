<?php ob_start(); ?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-lg overflow-hidden">
            <div class="bg-primary p-5 text-white text-center position-relative">
                <div class="position-absolute top-0 end-0 p-4 opacity-10">
                    <i class="bi bi-magic display-1"></i>
                </div>
                <h2 class="fw-bold mb-2">LocalSEO.pk Setup Wizard</h2>
                <p class="mb-0 opacity-75 text-uppercase small tracking-widest">Enterprise SEO Configuration</p>
            </div>
            
            <div class="card-body p-5">
                <!-- Wizard Steps -->
                <div class="d-flex justify-content-between mb-5 position-relative">
                    <div class="position-absolute top-50 start-0 translate-middle-y w-100 bg-light" style="height: 2px; z-index: 1;"></div>
                    <div class="rounded-pill bg-primary text-white d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 40px; height: 40px; z-index: 2;">1</div>
                    <div class="rounded-pill bg-white border text-muted d-flex align-items-center justify-content-center fw-bold" style="width: 40px; height: 40px; z-index: 2;">2</div>
                    <div class="rounded-pill bg-white border text-muted d-flex align-items-center justify-content-center fw-bold" style="width: 40px; height: 40px; z-index: 2;">3</div>
                    <div class="rounded-pill bg-white border text-muted d-flex align-items-center justify-content-center fw-bold" style="width: 40px; height: 40px; z-index: 2;">4</div>
                </div>

                <div class="text-center mb-5">
                    <h4 class="fw-bold text-dark">Welcome to Performance & SEO Perfection</h4>
                    <p class="text-muted">This wizard will configure your site for Google's latest ranking algorithms including Core Web Vitals, E-E-A-T, and Semantic SILO architecture.</p>
                </div>

                <div class="row g-4 mb-5">
                    <div class="col-md-12">
                        <div class="p-4 bg-light rounded-3 border">
                            <h6 class="fw-bold mb-3">Choose Your Configuration Level:</h6>
                            <div class="form-check card-radio p-3 bg-white border mb-3 rounded hover-shadow cursor-pointer transition-all active">
                                <input class="form-check-input mt-1" type="radio" name="mode" id="easy" checked>
                                <label class="form-check-label ms-2" for="easy">
                                    <div class="fw-bold text-dark fs-5">Easy (Recommended)</div>
                                    <div class="small text-muted">Automated optimization for most sites. Safe and efficient.</div>
                                </label>
                            </div>
                            <div class="form-check card-radio p-3 bg-white border rounded hover-shadow cursor-pointer transition-all">
                                <input class="form-check-input mt-1" type="radio" name="mode" id="advanced">
                                <label class="form-check-label ms-2" for="advanced">
                                    <div class="fw-bold text-dark fs-5">Advanced (Full Control)</div>
                                    <div class="small text-muted">Custom settings for indexation, schema fine-tuning, and performance.</div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between">
                    <button class="btn btn-link text-muted text-decoration-none px-0">Return to Dashboard</button>
                    <button class="btn btn-primary px-5 fw-bold shadow-sm rounded-pill py-2">Start Setup <i class="bi bi-arrow-right ms-2"></i></button>
                </div>
            </div>
        </div>

        <div class="text-center mt-4 text-muted small">
            Powered by <strong>LocalSEO.pk Core Engine</strong> v1.0
        </div>
    </div>
</div>

<style>
.tracking-widest { letter-spacing: 0.2em; }
.card-radio:hover { border-color: var(--bs-primary) !important; }
.cursor-pointer { cursor: pointer; }
</style>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
