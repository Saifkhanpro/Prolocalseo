<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-geo-alt me-2 text-primary"></i> Local SEO Settings</h2>
    <button class="btn btn-primary shadow-sm" onclick="document.getElementById('localSeoForm').submit()"><i class="bi bi-save me-2"></i> Save Settings</button>
</div>

<div class="row">
    <div class="col-lg-8">
        <form method="POST" action="/admin/seo/local" id="localSeoForm">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            
            <!-- Person or Organization -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3">Knowledge Graph & Schema</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Person or Organization</label>
                        <select name="seo_local_type" class="form-select">
                            <option value="organization" <?= ($settings['seo_local_type'] ?? '') === 'organization' ? 'selected' : '' ?>>Organization</option>
                            <option value="person" <?= ($settings['seo_local_type'] ?? '') === 'person' ? 'selected' : '' ?>>Person</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Name</label>
                        <input type="text" name="seo_local_name" class="form-control" value="<?= htmlspecialchars($settings['seo_local_name'] ?? $settings['site_name'] ?? '') ?>" placeholder="e.g. LocalSEO.pk">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Logo</label>
                        <div class="input-group">
                            <input type="text" name="seo_local_logo" id="local_logo" class="form-control" value="<?= htmlspecialchars($settings['seo_local_logo'] ?? '') ?>">
                            <button type="button" class="btn btn-outline-secondary" onclick="openMediaManager('local_logo')">Select Image</button>
                        </div>
                        <div class="form-text">Used in Google Knowledge Graph and structured data.</div>
                    </div>
                </div>
            </div>

            <!-- Business Info -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3">Local Business Info</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Business Type</label>
                        <select name="seo_business_type" class="form-select">
                            <option value="LocalBusiness" <?= ($settings['seo_business_type'] ?? '') === 'LocalBusiness' ? 'selected' : '' ?>>Local Business (General)</option>
                            <option value="ProfessionalService" <?= ($settings['seo_business_type'] ?? '') === 'ProfessionalService' ? 'selected' : '' ?>>Professional Service</option>
                            <option value="Organization" <?= ($settings['seo_business_type'] ?? '') === 'Organization' ? 'selected' : '' ?>>Organization</option>
                        </select>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Phone Number</label>
                            <input type="text" name="seo_local_phone" class="form-control" value="<?= htmlspecialchars($settings['seo_local_phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email Address</label>
                            <input type="email" name="seo_local_email" class="form-control" value="<?= htmlspecialchars($settings['seo_local_email'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Street Address</label>
                        <input type="text" name="seo_local_address" class="form-control" value="<?= htmlspecialchars($settings['seo_local_address'] ?? '') ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Locality (City)</label>
                            <input type="text" name="seo_local_city" class="form-control" value="<?= htmlspecialchars($settings['seo_local_city'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Region (State/Province)</label>
                            <input type="text" name="seo_local_region" class="form-control" value="<?= htmlspecialchars($settings['seo_local_region'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Postal Code</label>
                            <input type="text" name="seo_local_zip" class="form-control" value="<?= htmlspecialchars($settings['seo_local_zip'] ?? '') ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Opening Hours -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3">Opening Hours</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Hours Format</label>
                        <select name="seo_hours_format" class="form-select mb-3">
                            <option value="24h" <?= ($settings['seo_hours_format'] ?? '') === '24h' ? 'selected' : '' ?>>24 Hours (Open Always)</option>
                            <option value="custom" <?= ($settings['seo_hours_format'] ?? '') === 'custom' ? 'selected' : '' ?>>Custom Hours</option>
                        </select>
                    </div>
                </div>
            </div>
        </form>
    </div>
    
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm bg-light pb-2">
            <div class="card-header bg-white fw-bold">Live Preview</div>
            <div class="card-body">
                <div class="p-3 bg-white border rounded shadow-sm">
                    <div class="d-flex align-items-center mb-2">
                        <div class="bg-secondary bg-opacity-10 rounded p-2 me-2">
                            <i class="bi bi-google text-primary"></i>
                        </div>
                        <span class="small text-muted">Knowledge Graph Preview</span>
                    </div>
                    <div class="fw-bold mb-1"><?= htmlspecialchars($settings['seo_local_name'] ?? 'Business Name') ?></div>
                    <div class="small text-muted mb-2">Website · localseo.pk</div>
                    <div class="border-top pt-2 mt-2">
                        <div class="small mb-1"><strong>Address:</strong> <?= htmlspecialchars($settings['seo_local_address'] ?? 'Street Info') ?></div>
                        <div class="small"><strong>Phone:</strong> <?= htmlspecialchars($settings['seo_local_phone'] ?? 'Phone Number') ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
