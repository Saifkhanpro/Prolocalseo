<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-grid-fill me-2 text-primary"></i> RankMath Modules</h2>
    <div class="d-flex gap-2">
        <button class="btn btn-primary shadow-sm" onclick="document.getElementById('modulesForm').submit()"><i class="bi bi-save me-2"></i> Save Modules</button>
    </div>
</div>

<div class="alert alert-info border-0 shadow-sm mb-4 d-flex align-items-center">
    <i class="bi bi-info-circle-fill fs-4 me-3"></i>
    <div>
        <strong>Pro Tip:</strong> Enable only the modules you actually need to keep your site as lightweight as possible. All LocalSEO.pk core features are optimized for maximum speed.
    </div>
</div>

<form method="POST" action="/admin/seo/modules" id="modulesForm">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <div class="row g-4">
        <?php 
            $seoModules = [
                'seo_module_404' => [
                    'title' => '404 Monitor', 
                    'desc' => 'Log all 404 hit attempts locally to identify broken links.',
                    'icon' => 'exclamation-octagon',
                    'color' => 'danger'
                ],
                'seo_module_acf' => [
                    'title' => 'ACF Mapping', 
                    'desc' => 'Auto-inject schema data from Advanced Custom Fields.',
                    'icon' => 'code-slash',
                    'color' => 'success'
                ],
                'seo_module_image_seo' => [
                    'title' => 'Image SEO', 
                    'desc' => 'Auto-generate missing ALT tags from file names.',
                    'icon' => 'image',
                    'color' => 'primary'
                ],
                'seo_module_instant_indexing' => [
                    'title' => 'Instant Indexing', 
                    'desc' => 'Ping Google/Bing Indexing API on every publish event.',
                    'icon' => 'lightning-fill',
                    'color' => 'warning'
                ],
                'seo_module_link_counter' => [
                    'title' => 'Link Counter', 
                    'desc' => 'Monitor internal/external link counts in content.',
                    'icon' => 'link-45deg',
                    'color' => 'info'
                ],
                'seo_module_local' => [
                    'title' => 'Local SEO', 
                    'desc' => 'Inject LocalBusiness JSON-LD and Knowledge Graph nodes.',
                    'icon' => 'geo-alt-fill',
                    'color' => 'primary'
                ],
                'seo_module_redirections' => [
                    'title' => 'Redirections', 
                    'desc' => 'Easily manage 301/302/410 rules and bulk imports.',
                    'icon' => 'arrow-repeat',
                    'color' => 'success'
                ],
                'seo_module_schema' => [
                    'title' => 'Schema (Snippets)', 
                    'desc' => 'Inject Article, Product, or Service schema automatically.',
                    'icon' => 'node-plus-fill',
                    'color' => 'indigo'
                ],
                'seo_module_sitemap' => [
                    'title' => 'XML Sitemap', 
                    'desc' => 'Generate dynamic sitemaps for posts and image targets.',
                    'icon' => 'diagram-3',
                    'color' => 'dark'
                ],
                'seo_module_analytics' => [
                    'title' => 'Analytics Dashboard', 
                    'desc' => 'Pull data from GSC and GA4 into your admin panel.',
                    'icon' => 'bar-chart-fill',
                    'color' => 'primary'
                ]
            ];
        ?>
        <?php foreach($seoModules as $k => $v): ?>
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 border-0 shadow-sm hover-shadow transition-all">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div class="rounded-3 bg-<?= $v['color'] ?> bg-opacity-10 p-3 text-<?= $v['color'] ?>">
                                <i class="bi bi-<?= $v['icon'] ?> fs-3"></i>
                            </div>
                            <div class="form-check form-switch m-0 p-0" style="min-height: auto;">
                                <input class="form-check-input ms-0" type="checkbox" role="switch" name="modules[<?= $k ?>]" id="<?= $k ?>" <?= ($settings['seo'][$k] ?? '') === '1' ? 'checked' : '' ?> style="transform: scale(1.5);">
                            </div>
                        </div>
                        <h5 class="fw-bold text-dark mb-2"><?= $v['title'] ?></h5>
                        <p class="small text-muted mb-0"><?= $v['desc'] ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
