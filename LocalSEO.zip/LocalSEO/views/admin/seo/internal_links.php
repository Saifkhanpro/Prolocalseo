<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-link-45deg me-2 text-primary"></i> Internal Link Analysis</h2>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-primary" onclick="window.location.reload()"><i class="bi bi-arrow-clockwise"></i> Recalculate</button>
        <a href="/admin/seo/auto-links" class="btn btn-primary shadow-sm"><i class="bi bi-magic"></i> Auto-Linker</a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 text-center">
            <h1 class="display-6 fw-bold text-primary">485</h1>
            <div class="text-uppercase small text-muted">Total Internal Links</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 text-center">
            <h1 class="display-6 fw-bold text-danger">3</h1>
            <div class="text-uppercase small text-muted">Orphan Pages Detected</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 text-center border-top border-success border-3">
            <h1 class="display-6 fw-bold text-success">98%</h1>
            <div class="text-uppercase small text-muted">Connectivity Score</div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold py-3"><i class="bi bi-bar-chart me-2"></i> Content Connectivity Report</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="py-3 px-4">Post/Page</th>
                    <th class="py-3">Inbound</th>
                    <th class="py-3">Outbound</th>
                    <th class="py-3">External</th>
                    <th class="py-3 px-4 text-end">Suggestions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="px-4">
                        <div class="fw-bold">SEO Services in Karachi</div>
                        <div class="small text-muted">/services/seo-karachi</div>
                    </td>
                    <td><span class="badge bg-light text-dark border">42</span></td>
                    <td><span class="badge bg-light text-dark border">15</span></td>
                    <td><span class="badge bg-light text-dark border">2</span></td>
                    <td class="px-4 text-end">
                        <button class="btn btn-sm btn-outline-info">View Options</button>
                    </td>
                </tr>
                <tr class="table-danger bg-opacity-10">
                    <td class="px-4">
                        <div class="fw-bold">Hidden Service Page</div>
                        <div class="small text-muted">/local-seo/lahore-expert</div>
                    </td>
                    <td><span class="badge bg-danger">0</span></td>
                    <td><span class="badge bg-light text-dark border">3</span></td>
                    <td><span class="badge bg-light text-dark border">0</span></td>
                    <td class="px-4 text-end">
                        <button class="btn btn-sm btn-primary py-1 px-3">Fix Orphan</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
