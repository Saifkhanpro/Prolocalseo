<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-bar-chart-line me-2 text-primary"></i> Search Analytics</h2>
    <div class="d-flex gap-2">
        <select class="form-select form-select-sm w-auto">
            <option>Last 28 Days</option>
            <option>Last 3 Months</option>
            <option>Last 6 Months</option>
        </select>
        <button class="btn btn-primary btn-sm shadow-sm" onclick="window.location.reload()"><i class="bi bi-arrow-clockwise"></i> Sync Now</button>
    </div>
</div>

<?php if (!$isConnected): ?>
<div class="card border-0 shadow-sm mb-4 bg-gradient-primary text-white">
    <div class="card-body p-5 text-center">
        <img src="https://www.gstatic.com/images/branding/product/2x/search_console_64dp.png" height="64" class="mb-4 bg-white rounded-circle p-2">
        <h3 class="fw-bold">Connect Google Search Console</h3>
        <p class="opacity-75 mb-4 mx-auto" style="max-width: 600px;">Get real-world data on how people find your site. Monitor Clicks, Impressions, and Keyword Rankings directly within your LocalSEO.pk dashboard.</p>
        <form action="/admin/seo/analytics/connect" method="POST">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            <button type="submit" class="btn btn-light btn-lg px-5 fw-bold text-primary shadow">Connect My Google Account</button>
        </form>
    </div>
</div>
<?php else: ?>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-4">
            <div class="text-muted small text-uppercase mb-1 tracking-wider">Total Clicks</div>
            <div class="d-flex align-items-end gap-2">
                <h2 class="fw-bold mb-0"><?= number_format($analytics['clicks']) ?></h2>
                <span class="text-success small mb-1"><i class="bi bi-caret-up-fill"></i> 12%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-4">
            <div class="text-muted small text-uppercase mb-1 tracking-wider">Impressions</div>
            <div class="d-flex align-items-end gap-2">
                <h2 class="fw-bold mb-0"><?= number_format($analytics['impressions']) ?></h2>
                <span class="text-success small mb-1"><i class="bi bi-caret-up-fill"></i> 8.4%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-4">
            <div class="text-muted small text-uppercase mb-1 tracking-wider">Avg. CTR</div>
            <div class="d-flex align-items-end gap-2">
                <h2 class="fw-bold mb-0"><?= $analytics['ctr'] ?>%</h2>
                <span class="text-danger small mb-1"><i class="bi bi-caret-down-fill"></i> 0.5%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-4 border-bottom border-primary border-4">
            <div class="text-muted small text-uppercase mb-1 tracking-wider">Avg. Position</div>
            <div class="d-flex align-items-end gap-2">
                <h2 class="fw-bold mb-0"><?= $analytics['position'] ?></h2>
                <span class="text-success small mb-1"><i class="bi bi-caret-up-fill"></i> 2.1</span>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold py-3 d-flex justify-content-between align-items-center">
                <span>Top Performing Keywords</span>
                <span class="badge bg-light text-dark fw-normal border">Search Console Data</span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="px-4 py-3">Keyword Query</th>
                            <th>Clicks</th>
                            <th>Impressions</th>
                            <th>CTR</th>
                            <th>Position</th>
                            <th class="text-end px-4">Trend</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($analytics['keywords'] as $kw): ?>
                        <tr>
                            <td class="px-4 fw-bold text-dark"><?= htmlspecialchars($kw['query']) ?></td>
                            <td><?= number_format($kw['clicks']) ?></td>
                            <td><?= number_format($kw['impressions']) ?></td>
                            <td><span class="text-primary"><?= $kw['ctr'] ?>%</span></td>
                            <td><span class="badge bg-info bg-opacity-10 text-info fw-bold">#<?= $kw['position'] ?></span></td>
                            <td class="text-end px-4">
                                <i class="bi bi-graph-up text-success"></i>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
