<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-graph-up-arrow me-2 text-primary"></i> SEO Dashboard</h2>
    <div class="d-flex gap-2">
        <a href="/admin/seo/setup" class="btn btn-primary d-none d-md-block"><i class="bi bi-magic"></i> Setup Wizard</a>
        <button class="btn btn-outline-primary" onclick="window.location.reload()"><i class="bi bi-arrow-clockwise"></i> Sync Data</button>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center py-4 bg-gradient-primary text-white">
            <h1 class="display-5 fw-bold mb-0"><?= $stats['score'] ?? 0 ?></h1>
            <div class="text-uppercase small opacity-75">SEO Health Score</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center py-4">
            <h1 class="display-5 fw-bold mb-0 text-success"><?= $stats['indexed'] ?? 0 ?></h1>
            <div class="text-uppercase small text-muted">Total Indexed URLs</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center py-4">
            <h1 class="display-5 fw-bold mb-0 text-warning"><?= $stats['404s'] ?? 0 ?></h1>
            <div class="text-uppercase small text-muted">404 Errors (24h)</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center py-4">
            <h1 class="display-5 fw-bold mb-0 text-info"><?= $stats['backlinks'] ?? 0 ?></h1>
            <div class="text-uppercase small text-muted">Internal Links</div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <!-- SEO Health Audit -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold py-3"><i class="bi bi-clipboard-check me-2 text-primary"></i> Site-Wide Analysis</div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <?php if(empty($audit)): ?>
                        <div class="text-center py-4">
                            <i class="bi bi-search display-1 text-light mb-3"></i>
                            <p class="text-muted">No audit data yet. Run the analyzer to see results.</p>
                            <button class="btn btn-outline-primary rounded-pill px-4">Analyze Entire Site</button>
                        </div>
                    <?php else: ?>
                        <?php foreach($audit as $item): ?>
                            <div class="list-group-item d-flex align-items-center py-3 px-0 border-0 border-bottom">
                                <i class="bi bi-<?= $item['status'] === 'pass' ? 'check-circle-fill text-success' : ($item['status'] === 'fail' ? 'x-circle-fill text-danger' : 'exclamation-circle-fill text-warning') ?> fs-4 me-3"></i>
                                <div class="flex-grow-1">
                                    <div class="fw-bold fs-6"><?= htmlspecialchars($item['title']) ?></div>
                                    <div class="small text-muted"><?= htmlspecialchars($item['desc']) ?></div>
                                </div>
                                <?php if($item['status'] !== 'pass'): ?>
                                    <a href="<?= $item['link'] ?? '#' ?>" class="btn btn-sm btn-light border">Fix It</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent SEO Activity -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold py-3">Recent SEO Activity</div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="small py-2">Entity</th>
                            <th class="small py-2">SEO Score</th>
                            <th class="small py-2">Focus Keyword</th>
                            <th class="small py-2">Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent as $r): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($r['title']) ?></div>
                                    <div class="small text-muted"><?= htmlspecialchars($r['type']) ?></div>
                                </td>
                                <td>
                                    <div class="progress" style="height: 6px; width: 60px;">
                                        <div class="progress-bar bg-<?= $r['score'] > 80 ? 'success' : ($r['score'] > 50 ? 'warning' : 'danger') ?>" style="width: <?= $r['score'] ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?= $r['score'] ?>/100</small>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($r['keyword']) ?></span></td>
                                <td class="small text-muted"><?= date('M j, Y', strtotime($r['updated_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- Google Search Console Status -->
        <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <img src="https://www.gstatic.com/images/branding/product/2x/search_console_64dp.png" height="32" class="me-3">
                    <h6 class="fw-bold mb-0">Search Console</h6>
                </div>
                <?php if(empty($settings['gsc_token'])): ?>
                    <p class="small text-muted mb-4">Connect your Google account to see clicks, impressions, and rankings natively inside the dashboard.</p>
                    <a href="/admin/seo/analytics/connect" class="btn btn-outline-primary w-100">Connect GSC</a>
                <?php else: ?>
                    <div class="alert alert-success py-2 small mb-0"><i class="bi bi-check-circle-fill me-2"></i> Account Connected</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Indexing Status -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold">Instant Indexing API</div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="small text-muted">Daily Limit:</span>
                    <span class="small fw-bold text-dark">20/200</span>
                </div>
                <div class="progress mb-4" style="height: 5px;">
                    <div class="progress-bar" style="width: 10%"></div>
                </div>
                <button type="button" class="btn btn-sm btn-outline-info w-100" data-bs-toggle="modal" data-bs-target="#indexingModal">Manual Submit URL</button>
            </div>
        </div>

        <!-- Useful Links -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="list-group list-group-flush rounded border-0">
                    <a href="/sitemap.xml" target="_blank" class="list-group-item list-group-item-action border-0 py-3"><i class="bi bi-diagram-3 me-2 text-primary"></i> View XML Sitemap</a>
                    <a href="/robots.txt" target="_blank" class="list-group-item list-group-item-action border-0 py-3"><i class="bi bi-robot me-2 text-danger"></i> View Robots.txt</a>
                    <a href="/admin/seo/redirections" class="list-group-item list-group-item-action border-0 py-3"><i class="bi bi-arrow-left-right me-2 text-success"></i> Redirect Manager</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
