<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-lightning-fill me-2 text-warning"></i> Instant Indexing</h2>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-bold py-3">Submit URL to Google/Bing</div>
            <div class="card-body">
                <form action="/admin/seo/instant-indexing/submit" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Enter URL(s)</label>
                        <textarea name="url" class="form-control" rows="5" placeholder="https://localseo.pk/blog/new-post"></textarea>
                        <div class="form-text">One URL per line. Maximum 100 per day.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Action</label>
                        <select class="form-select">
                            <option value="publish">URL Publish / Updated</option>
                            <option value="remove">URL Removed</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold py-2 shadow-sm">Send to Indexing API</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold py-3">API Console Log</div>
            <div class="card-body p-0">
                <div class="bg-dark text-success p-3 rounded-bottom font-monospace" style="height: 300px; overflow-y: auto; font-size: 0.85rem;">
                    [<?= date('H:i:s') ?>] System initialized...<br>
                    [<?= date('H:i:s') ?>] Waiting for manual submission...<br>
                    <span class="text-muted">No API requests recorded in current session.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mt-4">
    <div class="card-header bg-white fw-bold py-3">Indexing History</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="px-4 py-3">URL</th>
                    <th>Search Engine</th>
                    <th>Response</th>
                    <th class="text-end px-4">Time</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="4" class="text-center py-4 text-muted small">History is currently clear.</td></tr>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
