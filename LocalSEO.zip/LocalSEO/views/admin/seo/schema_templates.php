<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-node-plus-fill me-2 text-primary"></i> Schema Templates</h2>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSchemaModal"><i class="bi bi-plus-lg"></i> Add New Template</button>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="py-3 px-4">Template Name</th>
                        <th class="py-3">Schema Type</th>
                        <th class="py-3">Condition</th>
                        <th class="py-3">Status</th>
                        <th class="py-3 px-4 text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="bg-primary bg-opacity-10">
                        <td class="px-4">
                            <div class="fw-bold text-dark">Default Article Schema</div>
                            <div class="small text-muted">Core RankMath logic for blog posts</div>
                        </td>
                        <td>Article</td>
                        <td>All Posts</td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td class="px-4 text-end">
                            <button class="btn btn-sm btn-outline-primary shadow-sm px-3">Edit</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-4">
                            <div class="fw-bold text-dark">Service Pages FAQ</div>
                            <div class="small text-muted">Auto-injected FAQ schema for conversions</div>
                        </td>
                        <td>FAQPage</td>
                        <td>Post Type: Service</td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td class="px-4 text-end">
                            <button class="btn btn-sm btn-outline-primary shadow-sm px-3">Edit</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="px-4">
                            <div class="fw-bold text-dark">LocalBusiness (Global)</div>
                            <div class="small text-muted">Knowledge Graph data for the whole site</div>
                        </td>
                        <td>LocalBusiness</td>
                        <td>Entire Site</td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td class="px-4 text-end">
                            <button class="btn btn-sm btn-outline-primary shadow-sm px-3">Edit</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="alert alert-info border-0 shadow-sm mt-4 d-flex align-items-center bg-white">
    <i class="bi bi-lightbulb-fill fs-4 me-3 text-warning"></i>
    <div>
        <strong>Did you know?</strong> Structured data (Schema) helps Google understand your content better and can lead to rich snippets like stars, prices, and FAQ accordions in search results.
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
