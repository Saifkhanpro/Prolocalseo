<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-exclamation-octagon me-2 text-danger"></i> 404 Monitor</h2>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-danger" onclick="if(confirm('Clear all logs?')) window.location.href='/admin/seo/404-monitor/cleanup'"><i class="bi bi-trash"></i> Clear Logs</button>
        <button class="btn btn-primary" onclick="window.location.reload()"><i class="bi bi-arrow-clockwise"></i> Refresh</button>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="py-3 px-4">Requested URL</th>
                        <th class="py-3">Hits</th>
                        <th class="py-3">IP Address</th>
                        <th class="py-3">Last Detection</th>
                        <th class="py-3 px-4 text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($logs)): ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No 404 errors recorded yet. Good job!</td></tr>
                    <?php else: ?>
                        <?php foreach($logs as $log): ?>
                            <tr>
                                <td class="px-4">
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($log['request_uri']) ?></div>
                                    <div class="small text-muted"><?= htmlspecialchars($log['user_agent'] ?? 'Unknown User Agent') ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-danger rounded-pill px-3"><?= (int)$log['additional_data'] ?></span>
                                </td>
                                <td class="small text-monospace"><?= htmlspecialchars($log['ip_address']) ?></td>
                                <td class="small text-muted"><?= date('M j, Y, g:ia', strtotime($log['created_at'])) ?></td>
                                <td class="px-4 text-end">
                                    <button class="btn btn-sm btn-outline-primary" onclick="openRedirectModal('<?= htmlspecialchars($log['request_uri']) ?>')">Create Redirect</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Redirect Modal -->
<div class="modal fade" id="redirectModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="/admin/seo/redirections/store" method="POST" class="modal-content">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            <div class="modal-header">
                <h5 class="modal-title">Create Redirect</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Source URL (404 Path)</label>
                    <input type="text" name="old_url" id="modal_old_url" class="form-control" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Destination URL</label>
                    <input type="text" name="new_url" class="form-control" placeholder="e.g. /new-page-path" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Redirect Type</label>
                    <select name="type" class="form-select">
                        <option value="301" selected>301 Permanent Move</option>
                        <option value="302">302 Temporary Move</option>
                        <option value="410">410 Content Deleted (Gone)</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Fix 404 with Redirect</button>
            </div>
        </form>
    </div>
</div>

<script>
function openRedirectModal(url) {
    document.getElementById('modal_old_url').value = url;
    new bootstrap.Modal(document.getElementById('redirectModal')).show();
}
</script>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
