<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-gear-fill me-2 text-primary"></i> General SEO Settings</h2>
    <button class="btn btn-primary shadow-sm" onclick="document.getElementById('generalSeoForm').submit()"><i class="bi bi-save me-2"></i> Save Changes</button>
</div>

<div class="row">
    <div class="col-lg-12">
        <form method="POST" action="/admin/seo/general" id="generalSeoForm">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            
            <!-- Global Meta -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold border-0 pt-4 px-4">Global Metadata Logic</div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Title Separator</label>
                            <div class="d-flex gap-3">
                                <?php $sep = $settings['seo_title_separator'] ?? '-'; ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="seo_title_separator" value="-" id="sep1" <?= $sep === '-' ? 'checked' : '' ?>>
                                    <label class="form-check-label px-2 border rounded" for="sep1">-</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="seo_title_separator" value="|" id="sep2" <?= $sep === '|' ? 'checked' : '' ?>>
                                    <label class="form-check-label px-2 border rounded" for="sep2">|</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="seo_title_separator" value="»" id="sep3" <?= $sep === '»' ? 'checked' : '' ?>>
                                    <label class="form-check-label px-2 border rounded" for="sep3">»</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Capitalize Titles</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="seo_capitalize_titles" value="1" <?= ($settings['seo_capitalize_titles'] ?? '') === '1' ? 'checked' : '' ?>>
                                <label class="form-check-label">Automatically capitalize the first letter of each word.</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Indexing Control -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3">Global Indexing Controls</div>
                <div class="card-body">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label d-block fw-bold">Noindex Paginated Pages</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="seo_noindex_paginated" value="1" <?= ($settings['seo_noindex_paginated'] ?? '') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label small text-muted">Prevents duplicate content issues on /page/2, /page/3 etc.</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label d-block fw-bold">Noindex Archive Dates</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="seo_noindex_dates" value="1" <?= ($settings['seo_noindex_dates'] ?? '') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label small text-muted">Dates archives are often considered "thin content" by Google.</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label d-block fw-bold">Noindex Search Results</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="seo_noindex_search" value="1" <?= ($settings['seo_noindex_search'] ?? '1') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label small text-muted">Highly recommended to prevent SERP bloat.</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Breadcrumbs -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold py-3">Breadcrumbs Configuration</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Enable Breadcrumbs</label>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="seo_breadcrumbs_enabled" value="1" <?= ($settings['seo_breadcrumbs_enabled'] ?? '') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label">Enables Schema.org BreadcrumbList for better SERP visibility.</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Breadcrumb Separator</label>
                            <input type="text" name="seo_breadcrumbs_sep" class="form-control" value="<?= htmlspecialchars($settings['seo_breadcrumbs_sep'] ?? '/') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Home Page Link Text</label>
                            <input type="text" name="seo_breadcrumbs_home" class="form-control" value="<?= htmlspecialchars($settings['seo_breadcrumbs_home'] ?? 'Home') ?>">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
