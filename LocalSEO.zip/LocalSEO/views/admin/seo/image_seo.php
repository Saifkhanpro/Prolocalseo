<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-image me-2 text-primary"></i> Image SEO</h2>
    <form action="/admin/seo/image-seo/bulk-alt" method="POST">
        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
        <button type="submit" class="btn btn-primary shadow-sm"><i class="bi bi-magic"></i> Auto-Generate Missing ALT Tags</button>
    </form>
</div>

<div class="alert alert-info border-0 shadow-sm mb-4">
    <i class="bi bi-info-circle-fill me-2"></i> Automatically generate ALT tags for images based on their file names. This is a critical factor for Image Search rankings and Accessibility.
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold py-3">Images with Missing ALT Text</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="px-4 py-3">Preview</th>
                    <th>File Path</th>
                    <th>Suggested ALT</th>
                    <th class="text-end px-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($missingAlt)): ?>
                    <tr><td colspan="4" class="text-center py-5 text-muted">All images have ALT tags. Great job!</td></tr>
                <?php else: ?>
                    <?php foreach($missingAlt as $img): ?>
                        <tr>
                            <td class="px-4 py-2">
                                <img src="<?= $img['file_path'] ?>" class="rounded" style="width: 50px; height: 50px; object-fit: cover;">
                            </td>
                            <td class="small text-muted"><?= htmlspecialchars($img['file_path']) ?></td>
                            <td>
                                <span class="badge bg-light text-dark border fw-normal">
                                    <?= ucwords(str_replace(['-', '_'], ' ', pathinfo($img['file_path'], PATHINFO_FILENAME))) ?>
                                </span>
                            </td>
                            <td class="text-end px-4">
                                <button class="btn btn-sm btn-outline-primary">Edit</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(dirname(__DIR__)) . '/_layout.php';
?>
