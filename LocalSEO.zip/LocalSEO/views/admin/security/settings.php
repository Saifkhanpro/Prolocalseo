<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Configure your platform's security policies.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm">
                <a href="/admin/security/log" class="btn btn-outline-primary">Security Logs</a>
                <a href="/admin/security/blocked-ips" class="btn btn-outline-primary">Blocked IPs</a>
                <a href="/admin/security/settings" class="btn btn-primary active">Security Settings</a>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <form action="/admin/security/settings" method="POST">
                <div class="row g-5">
                    <div class="col-md-6">
                        <h5 class="fw-bold mb-3 d-flex align-items-center">
                            <i class="bi bi-shield-lock-fill text-primary me-2"></i> Brute Force Protection
                        </h5>
                        <div class="mb-4">
                            <label class="form-label fw-bold">Max Login Attempts</label>
                            <input type="number" name="max_attempts" class="form-control" value="<?= \Core\Helpers::setting('security_login_max_attempts', '5') ?>">
                            <div class="form-text">Number of failed login attempts before lockout.</div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold">Lockout Duration (Minutes)</label>
                            <input type="number" name="lockout_duration" class="form-control" value="<?= \Core\Helpers::setting('security_lockout_duration', '15') ?>">
                            <div class="form-text">How long a user is blocked from signing in.</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h5 class="fw-bold mb-3 d-flex align-items-center">
                            <i class="bi bi-eye-fill text-primary me-2"></i> Firewall Settings
                        </h5>
                        <div class="form-check form-switch mb-4 mt-2">
                            <input class="form-check-input" type="checkbox" name="block_suspicious" id="suspicious" value="1" <?= \Core\Helpers::setting('security_block_suspicious', '1') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="suspicious">Auto-Block Suspicious IPs</label>
                            <div class="form-text">Automatically block IPs that hit too many 404s or show malicious patterns.</div>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" name="hide_backend" id="hideBackend" value="1" <?= \Core\Helpers::setting('security_hide_backend', '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="hideBackend">Stealth Admin Mode</label>
                            <div class="form-text">Removes common footprints that reveal this is a PHP engine.</div>
                        </div>
                    </div>
                </div>

                <hr class="my-5">

                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-success small"><i class="bi bi-check2-circle me-1"></i> Core security modules are active.</span>
                    </div>
                    <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-sm">
                        Apply Security Policies
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
