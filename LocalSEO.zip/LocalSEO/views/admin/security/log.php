<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Monitor and manage access security for your platform.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm">
                <a href="/admin/security/log" class="btn btn-primary active">Security Logs</a>
                <a href="/admin/security/blocked-ips" class="btn btn-outline-primary">Blocked IPs</a>
                <a href="/admin/security/settings" class="btn btn-outline-primary">Security Settings</a>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">Event</th>
                            <th>IP Address</th>
                            <th>Severity</th>
                            <th>Timestamp</th>
                            <th class="text-end pe-4">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <i class="bi bi-shield-check fs-1 text-muted d-block mb-2"></i>
                                    No security events recorded.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold"><?= \Core\Helpers::escape($log['event_type']) ?></div>
                                        <small class="text-muted"><?= \Core\Helpers::escape($log['username'] ?? 'Guest') ?></small>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-geo-alt me-2 text-muted"></i>
                                            <?= \Core\Helpers::escape($log['ip_address']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                            $color = match($log['severity']) {
                                                'low' => 'info',
                                                'medium' => 'warning',
                                                'high' => 'danger',
                                                'critical' => 'dark',
                                                default => 'secondary'
                                            };
                                        ?>
                                        <span class="badge bg-<?= $color ?> bg-opacity-10 text-<?= $color ?> rounded-pill px-3">
                                            <?= ucfirst($log['severity']) ?>
                                        </span>
                                    </td>
                                    <td class="small text-muted">
                                        <?= date('M j, Y H:i:s', strtotime($log['created_at'])) ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-light btn-sm rounded-circle" title="View Details">
                                            <i class="bi bi-info-circle"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
