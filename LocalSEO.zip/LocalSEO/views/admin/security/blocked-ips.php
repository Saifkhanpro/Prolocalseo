<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <p class="text-muted">Proactive protection by blocking malicious actors.</p>
        </div>
        <div class="col-auto">
            <div class="btn-group shadow-sm me-3">
                <a href="/admin/security/log" class="btn btn-outline-primary">Security Logs</a>
                <a href="/admin/security/blocked-ips" class="btn btn-primary active">Blocked IPs</a>
                <a href="/admin/security/settings" class="btn btn-outline-primary">Security Settings</a>
            </div>
            <button class="btn btn-dark shadow-sm" data-bs-toggle="modal" data-bs-target="#blockIpModal">
                <i class="bi bi-slash-circle me-2"></i> Block New IP
            </button>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">IP Address</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Blocked On</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ips)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <i class="bi bi-globe-americas fs-1 text-muted d-block mb-2"></i>
                                    No IPs are currently blocked.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ips as $ip): ?>
                                <tr>
                                    <td class="ps-4 fw-bold">
                                        <?= \Core\Helpers::escape($ip['ip_address']) ?>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= \Core\Helpers::escape($ip['reason']) ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger bg-opacity-10 text-danger rounded-pill px-3">
                                            Blocked
                                        </span>
                                    </td>
                                    <td class="small text-muted">
                                        <?= date('M j, Y', strtotime($ip['created_at'])) ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <form action="/admin/security/unblock-ip/<?= $ip['id'] ?>" method="POST" class="d-inline">
                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                <i class="bi bi-unlock-fill me-1"></i> Unblock
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Block IP Modal -->
<div class="modal fade" id="blockIpModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Manual IP Block</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="/admin/security/block-ip" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label">IPv4 or IPv6 Address</label>
                        <input type="text" name="ip_address" class="form-control" placeholder="0.0.0.0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Blocking Reason</label>
                        <textarea name="reason" class="form-control" rows="2" placeholder="e.g. Brute force attempts"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light border-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger px-4">Apply Block</button>
                </div>
            </form>
        </div>
    </div>
</div>
