<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-images me-2 text-primary"></i> <?= $pageTitle ?></h2>
    <form method="POST" action="/admin/media/upload" enctype="multipart/form-data" class="d-flex align-items-center">
        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
        <input type="file" name="file" class="form-control form-control-sm me-2" required accept="image/*,application/pdf">
        <button type="submit" class="btn btn-primary btn-sm px-3 shadow-sm"><i class="bi bi-upload"></i> Upload</button>
    </form>
</div>

<!-- Alert for WebP Conversion Status -->
<div class="alert alert-info py-2 small shadow-sm border-0 mb-4 d-flex align-items-center">
    <i class="bi bi-magic fs-4 me-3"></i>
    <div>
        <strong>Auto Optimization Enabled:</strong> Uploaded images are automatically converted to WebP format if configured in Global Settings, significantly reducing file size while maintaining quality.
    </div>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body p-4 bg-light">
        <div class="row g-4">
            <?php if(empty($media)): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i class="bi bi-cloud-arrow-up display-1 text-light mb-3"></i>
                    <h4>Media Library is Empty</h4>
                    <p>Upload files using the tool above to see them here.</p>
                </div>
            <?php else: ?>
                <?php foreach($media as $m): ?>
                    <div class="col-6 col-md-3 col-lg-2">
                        <div class="card h-100 border shadow-sm media-card position-relative overflow-hidden" title="<?= htmlspecialchars($m['original_name']) ?>">
                            <div class="ratio ratio-1x1 bg-secondary bg-opacity-10 d-flex align-items-center justify-content-center">
                                <?php if(strpos($m['mime_type'], 'image') !== false): ?>
                                    <img src="<?= htmlspecialchars($m['file_path']) ?>" class="object-fit-cover w-100 h-100" loading="lazy" alt="<?= htmlspecialchars($m['alt_text'] ?? '') ?>">
                                <?php else: ?>
                                    <i class="bi bi-file-earmark-text display-3 text-muted m-auto"></i>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-2 text-truncate" style="font-size: 0.75rem;">
                                <div class="fw-bold mb-1" title="<?= htmlspecialchars($m['original_name']) ?>"><?= htmlspecialchars($m['original_name']) ?></div>
                                <div class="text-muted d-flex justify-content-between">
                                    <span><?= round($m['file_size'] / 1024) ?> KB</span>
                                    <span><?= strtoupper(pathinfo($m['file_path'], PATHINFO_EXTENSION)) ?></span>
                                </div>
                            </div>
                            
                            <!-- Hover Overlay Action -->
                            <div class="media-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark bg-opacity-75 d-flex flex-column align-items-center justify-content-center opacity-0 transition-all">
                                <form method="POST" action="/admin/media/delete/<?= $m['id'] ?>" onsubmit="return confirm('Delete this media file permanently?');">
                                    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                                    <button type="submit" class="btn btn-sm btn-danger mb-2"><i class="bi bi-trash"></i> Delete</button>
                                </form>
                                <button type="button" class="btn btn-sm btn-light" onclick="prompt('File URL:', '<?= htmlspecialchars(APP_URL . $m['file_path']) ?>')"><i class="bi bi-link"></i> Copy URL</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if($pagination['last_page'] > 1): ?>
    <div class="card-footer bg-white py-3">
        <nav>
            <ul class="pagination pagination-sm mb-0 justify-content-end">
                <?php for($i=1; $i<=$pagination['last_page']; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <a class="page-link" href="?p=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<style>
.media-card { transition: all 0.2s; }
.media-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important; z-index: 10; }
.media-card:hover .media-overlay { opacity: 1 !important; }
.opacity-0 { opacity: 0; }
.transition-all { transition: all 0.2s ease-in-out; }
</style>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
