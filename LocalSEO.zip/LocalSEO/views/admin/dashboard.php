<?php $content = ob_get_clean(); ?>

<div class="row g-4 mb-4">
    <!-- Stats Row -->
    <div class="col-md-3">
        <div class="card h-100 border-0 shadow-sm transition-hover">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h6 class="text-muted mb-0 fw-bold text-uppercase ls-1" style="font-size: 0.7rem;">Total Leads</h6>
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="bi bi-inbox fs-5"></i></div>
                </div>
                <h2 class="mb-1 fw-bold"><?= number_format($stats['leads_total']) ?></h2>
                <?php if($stats['leads_unread'] > 0): ?>
                    <div class="d-flex align-items-center text-danger small fw-bold">
                        <span class="pulse-danger me-2"></span>
                        <?= $stats['leads_unread'] ?> New Unread
                    </div>
                <?php else: ?>
                    <div class="text-success small fw-medium"><i class="bi bi-check-circle-fill me-1"></i> All Caught Up</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card h-100 border-0 shadow-sm transition-hover">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h6 class="text-muted mb-0 fw-bold text-uppercase ls-1" style="font-size: 0.7rem;">Published Posts</h6>
                    <div class="bg-success bg-opacity-10 text-success rounded-circle p-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="bi bi-file-earmark-text fs-5"></i></div>
                </div>
                <h2 class="mb-1 fw-bold"><?= number_format($stats['posts']) ?></h2>
                <a href="/admin/posts/create" class="text-primary text-decoration-none small fw-bold">
                    <i class="bi bi-plus-lg me-1"></i> Create New
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card h-100 border-0 shadow-sm transition-hover">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h6 class="text-muted mb-0 fw-bold text-uppercase ls-1" style="font-size: 0.7rem;">City Targets</h6>
                    <div class="bg-info bg-opacity-10 text-info rounded-circle p-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="bi bi-geo-alt fs-5"></i></div>
                </div>
                <h2 class="mb-1 fw-bold"><?= number_format($stats['cities']) ?></h2>
                <div class="text-info small fw-medium">Active Locations</div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card h-100 border-0 shadow-sm transition-hover border-start border-4 border-<?= $healthScore >= 80 ? 'success' : ($healthScore >= 50 ? 'warning' : 'danger') ?>">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h6 class="text-muted mb-0 fw-bold text-uppercase ls-1" style="font-size: 0.7rem;">SEO Health</h6>
                    <div class="bg-<?= $healthScore >= 80 ? 'success' : ($healthScore >= 50 ? 'warning' : 'danger') ?> bg-opacity-10 text-<?= $healthScore >= 80 ? 'success' : ($healthScore >= 50 ? 'warning' : 'danger') ?> rounded-circle p-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="bi bi-shield-check fs-5"></i></div>
                </div>
                <h2 class="mb-1 fw-bold"><?= $healthScore ?>%</h2>
                <a href="/admin/system/health" class="text-muted text-decoration-none small">View Details &rarr;</a>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span>Recent Leads</span>
                <a href="/admin/leads" class="btn btn-sm btn-light">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Service</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($recentLeads)): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">No leads found.</td></tr>
                        <?php else: ?>
                            <?php foreach($recentLeads as $lead): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($lead['full_name']) ?></div>
                                        <div class="small text-muted"><?= htmlspecialchars($lead['city']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($lead['service_needed']) ?></td>
                                    <td>
                                        <?php
                                            $badges = ['new' => 'danger', 'contacted' => 'warning', 'qualified' => 'info', 'converted' => 'success', 'closed' => 'secondary'];
                                            $col = $badges[$lead['status']] ?? 'primary';
                                        ?>
                                        <span class="badge bg-<?= $col ?>"><?= ucfirst($lead['status']) ?></span>
                                    </td>
                                    <td class="small text-muted"><?= date('M j, Y', strtotime($lead['created_at'])) ?></td>
                                    <td class="text-end">
                                        <a href="/admin/leads/<?= $lead['id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- System Updates Card -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white">
                CMS Status
            </div>
            <div class="card-body">
                <div class="fw-semibold mb-1">LocalSEO.pk Engine</div>
                <div class="text-muted small mb-3">Version <?= LSEO_VERSION ?></div>
                
                <?php if($updateInfo['has_update']): ?>
                    <div class="alert alert-warning py-2 small mb-0">
                        <i class="bi bi-info-circle me-1"></i> Version <?= htmlspecialchars($updateInfo['latest_version']) ?> is available.
                        <a href="/admin/system/updates" class="d-block mt-1 fw-bold">Review & Update</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success py-2 small mb-0">
                        <i class="bi bi-check-circle me-1"></i> Your system is up to date.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Activity Log -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                Recent Activity
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if(empty($recentActivity)): ?>
                        <div class="p-3 text-center text-muted small">No recent activity.</div>
                    <?php else: ?>
                        <?php foreach($recentActivity as $act): ?>
                            <div class="list-group-item p-3 border-light">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1 text-dark fs-6"><?= htmlspecialchars($act['description']) ?></h6>
                                    <small class="text-muted" title="<?= $act['created_at'] ?>"><?= date('M j, H:i', strtotime($act['created_at'])) ?></small>
                                </div>
                                <p class="mb-0 small text-muted">
                                    <i class="bi bi-person me-1"></i> <?= htmlspecialchars($act['display_name'] ?? 'System') ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$content = ob_get_clean();
require '_layout.php';
?>
