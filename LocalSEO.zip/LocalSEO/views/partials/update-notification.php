<?php
use Core\Helpers;
$updateInfo = $updateInfo ?? null;
?>
<?php if ($updateInfo && $updateInfo['update_available']): ?>
    <div class="alert alert-info border-0 shadow-sm d-flex align-items-center justify-content-between mb-4">
        <div>
            <i class="bi bi-info-circle-fill me-2"></i>
            A new version of LocalSEO.pk CMS is available (v<?= $updateInfo['latest_version'] ?>). 
            <a href="/admin/updates" class="fw-bold text-decoration-none ms-2">Update Now</a>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
