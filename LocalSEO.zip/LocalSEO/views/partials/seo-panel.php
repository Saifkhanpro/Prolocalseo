<div class="seo-panel card shadow-sm mt-4 border-0">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold text-primary"><i class="bi bi-search me-2"></i> SEO Analysis & Meta</h6>
        <div class="seo-score-badge badge bg-success p-2 px-3 rounded-pill" id="global-seo-score">Score: 0/100</div>
    </div>
    <div class="card-body p-4">
        <ul class="nav nav-pills mb-4 gap-2" id="seoTabs" role="tablist">
            <li class="nav-item"><button class="nav-link active rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#seo-general">General</button></li>
            <li class="nav-item"><button class="nav-link rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#seo-analysis">Analysis</button></li>
            <li class="nav-item"><button class="nav-link rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#seo-advanced">Advanced / Robots</button></li>
        </ul>
        
        <div class="tab-content">
            <div class="tab-pane fade show active" id="seo-general">
                <?php include VIEW_PATH . '/partials/google-preview.php'; ?>
                
                <div class="mb-3 mt-4">
                    <label class="form-label fw-bold">Focus Keyword</label>
                    <input type="text" name="focus_keyword" class="form-control" value="<?= $post['focus_keyword'] ?? '' ?>" placeholder="e.g. Local SEO Lahore">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">SEO Title</label>
                    <input type="text" name="seo_title" class="form-control" value="<?= $post['seo_title'] ?? '' ?>" maxlength="70">
                    <div class="progress mt-1" style="height: 4px;"><div class="progress-bar bg-success" id="title-progress" style="width: 0%"></div></div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Meta Description</label>
                    <textarea name="meta_description" class="form-control" rows="3" maxlength="160"><?= $post['meta_description'] ?? '' ?></textarea>
                    <div class="progress mt-1" style="height: 4px;"><div class="progress-bar bg-success" id="desc-progress" style="width: 0%"></div></div>
                </div>
            </div>
            
            <div class="tab-pane fade" id="seo-analysis">
                <div id="seo-analysis-results" class="list-group list-group-flush">
                    <div class="text-center py-5 opacity-50">Enter content to see analysis results.</div>
                </div>
            </div>
            
            <div class="tab-pane fade" id="seo-advanced">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Robots Index</label>
                        <select name="robots_index" class="form-select">
                            <option value="index" <?= ($post['robots_index'] ?? '') == 'index' ? 'selected' : '' ?>>Index (Default)</option>
                            <option value="noindex" <?= ($post['robots_index'] ?? '') == 'noindex' ? 'selected' : '' ?>>No-Index</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Robots Follow</label>
                        <select name="robots_follow" class="form-select">
                            <option value="follow" <?= ($post['robots_follow'] ?? '') == 'follow' ? 'selected' : '' ?>>Follow (Default)</option>
                            <option value="nofollow" <?= ($post['robots_follow'] ?? '') == 'nofollow' ? 'selected' : '' ?>>No-Follow</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Canonical URL</label>
                    <input type="url" name="canonical_url" class="form-control" value="<?= $post['canonical_url'] ?? '' ?>" placeholder="<?= APP_URL ?>/your-page">
                </div>
            </div>
        </div>
    </div>
</div>
