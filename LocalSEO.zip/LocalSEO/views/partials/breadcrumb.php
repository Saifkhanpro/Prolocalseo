<?php
use Core\Helpers;
?>
<div class="breadcrumb-container py-3 bg-light border-bottom mb-4">
    <div class="container px-lg-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <?php if (!empty($breadcrumbs)): ?>
                    <?php foreach ($breadcrumbs as $label => $link): ?>
                        <?php if ($link): ?>
                            <li class="breadcrumb-item"><a href="<?= $link ?>" class="text-decoration-none"><?= Helpers::escape($label) ?></a></li>
                        <?php else: ?>
                            <li class="breadcrumb-item active" aria-current="page"><?= Helpers::escape($label) ?></li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ol>
        </nav>
    </div>
</div>
