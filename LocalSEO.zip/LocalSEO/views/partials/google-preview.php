<div class="google-preview p-3 border rounded mb-4 bg-light">
    <div class="small text-muted mb-2"><i class="bi bi-google me-1"></i> Google Search Preview</div>
    <div class="preview-url text-success small mb-1" style="font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
        <?= APP_URL ?> › ... › <span id="preview-slug"><?= $post['slug'] ?? 'sample-url' ?></span>
    </div>
    <h5 class="preview-title text-primary mb-1 fw-normal" style="font-family: Arial, sans-serif; cursor: pointer;" id="preview-title">
        <?= $post['seo_title'] ?: ($post['title'] ?: 'Page Title Goes Here — LocalSEO.pk') ?>
    </h5>
    <p class="preview-desc text-secondary small mb-0" style="font-family: Arial, sans-serif;" id="preview-desc">
        <?= $post['meta_description'] ?: 'Please provide a meta description by editing the field below. This is what will appear in search engine results.' ?>
    </p>
</div>
