<?php
use Core\Helpers;
?>
<ul class="navbar-nav ms-auto mb-2 mb-lg-0 fw-medium">
    <li class="nav-item"><a class="nav-link px-lg-3" href="/">Home</a></li>
    <li class="nav-item"><a class="nav-link px-lg-3" href="/services">SEO Services</a></li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle px-lg-3" href="#" id="cityDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Locations
        </a>
        <ul class="dropdown-menu border-0 shadow-sm" aria-labelledby="cityDropdown">
            <?php 
            $cities = ['Karachi', 'Lahore', 'Islamabad', 'Faisalabad'];
            foreach ($cities as $city): 
            ?>
                <li><a class="dropdown-item" href="/local-seo/<?= strtolower($city) ?>"><?= $city ?></a></li>
            <?php endforeach; ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="/services">View All Services</a></li>
        </ul>
    </li>
    <li class="nav-item"><a class="nav-link px-lg-3" href="/case-studies">Case Studies</a></li>
    <li class="nav-item"><a class="nav-link px-lg-3" href="/blog">Blog</a></li>
    <li class="nav-item"><a class="nav-link px-lg-3" href="/about">About Us</a></li>
</ul>
