<?php
use Core\Helpers;
$current = $pagination['current_page'];
$total = $pagination['total_pages'];
$url = $pagination['base_url'];
?>
<?php if ($total > 1): ?>
<nav aria-label="Page navigation" class="mt-5">
    <ul class="pagination justify-content-center">
        <li class="page-item <?= ($current <= 1) ? 'disabled' : '' ?>">
            <a class="page-link rounded-start-pill px-3" href="<?= $url . ($current - 1) ?>" aria-label="Previous">
                <i class="bi bi-chevron-left"></i>
            </a>
        </li>
        
        <?php for($i = 1; $i <= $total; $i++): ?>
            <?php if ($i == 1 || $i == $total || ($i >= $current - 2 && $i <= $current + 2)): ?>
                <li class="page-item <?= ($i == $current) ? 'active' : '' ?>">
                    <a class="page-link px-3" href="<?= $url . $i ?>"><?= $i ?></a>
                </li>
            <?php elseif ($i == $current - 3 || $i == $current + 3): ?>
                <li class="page-item disabled"><span class="page-link">...</span></li>
            <?php endif; ?>
        <?php endfor; ?>

        <li class="page-item <?= ($current >= $total) ? 'disabled' : '' ?>">
            <a class="page-link rounded-end-pill px-3" href="<?= $url . ($current + 1) ?>" aria-label="Next">
                <i class="bi bi-chevron-right"></i>
            </a>
        </li>
    </ul>
</nav>

<style>
    .pagination .page-link { color: var(--primary-color); border: none; margin: 0 2px; }
    .pagination .page-item.active .page-link { background-color: var(--primary-color); border-radius: 50% !important; }
    .pagination .page-item:not(.active):hover .page-link { background-color: #f1f5f9; border-radius: 50%; }
</style>
<?php endif; ?>
