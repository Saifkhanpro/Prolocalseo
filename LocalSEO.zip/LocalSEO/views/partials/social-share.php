<?php
use Core\Helpers;
?>
<div class="share-buttons mt-5 p-4 bg-light rounded shadow-sm">
    <h6 class="fw-bold mb-3"><i class="bi bi-share-fill me-2"></i> Share this article</h6>
    <div class="d-flex flex-wrap gap-2">
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(Helpers::currentUrl()) ?>" target="_blank" class="btn btn-primary btn-sm rounded-pill"><i class="bi bi-facebook me-1"></i> Facebook</a>
        <a href="https://twitter.com/intent/tweet?url=<?= urlencode(Helpers::currentUrl()) ?>" target="_blank" class="btn btn-info btn-sm text-white rounded-pill"><i class="bi bi-twitter me-1"></i> Twitter</a>
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= urlencode(Helpers::currentUrl()) ?>" target="_blank" class="btn btn-secondary btn-sm rounded-pill"><i class="bi bi-linkedin me-1"></i> LinkedIn</a>
        <a href="https://wa.me/?text=<?= urlencode(Helpers::currentUrl()) ?>" target="_blank" class="btn btn-success btn-sm rounded-pill"><i class="bi bi-whatsapp me-1"></i> WhatsApp</a>
        <a href="mailto:?subject=Interesting Article&body=Check this out: <?= urlencode(Helpers::currentUrl()) ?>" class="btn btn-dark btn-sm rounded-pill"><i class="bi bi-envelope me-1"></i> Email</a>
    </div>
</div>
