<?php
use Core\Helpers;
?>
<aside class="sidebar h-100">
    <!-- Search Box -->
    <div class="sidebar-widget mb-5 p-4 bg-white rounded shadow-sm">
        <h6 class="fw-bold mb-4 border-start border-primary border-4 ps-3">Search</h6>
        <form action="/search" method="GET">
            <div class="input-group">
                <input type="text" name="q" class="form-control border-end-0" placeholder="Search blog..." required>
                <button class="btn btn-outline-secondary border-start-0" type="submit">
                    <i class="bi bi-search"></i>
                </button>
            </div>
        </form>
    </div>

    <!-- Categories -->
    <div class="sidebar-widget mb-5 p-4 bg-white rounded shadow-sm">
        <h6 class="fw-bold mb-4 border-start border-primary border-4 ps-3">Categories</h6>
        <ul class="list-unstyled mb-0">
            <?php foreach ($categories as $cat): ?>
                <li class="mb-2 d-flex justify-content-between align-items-center">
                    <a href="/category/<?= $cat['slug'] ?>" class="text-decoration-none text-dark hover-primary"><?= Helpers::escape($cat['name']) ?></a>
                    <span class="badge bg-light text-dark rounded-pill fw-normal"><?= $cat['post_count'] ?? 0 ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- Free SEO Audit CTA -->
    <div class="sidebar-widget mb-5 p-4 bg-primary text-white rounded shadow text-center position-relative overflow-hidden">
        <div class="position-relative z-1">
            <h5 class="fw-bold mb-3">Free SEO Audit</h5>
            <p class="opacity-75 small mb-4">Discover how well your website ranks in Pakistan's local search.</p>
            <a href="/contact" class="btn btn-light rounded-pill px-4 fw-bold w-100">Analyze Now</a>
        </div>
        <i class="bi bi-graph-up position-absolute bottom-0 end-0 opacity-10" style="font-size: 8rem; transform: translate(20%, 20%);"></i>
    </div>
</aside>
