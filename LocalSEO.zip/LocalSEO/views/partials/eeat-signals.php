<?php
use Core\Helpers;
?>
<div class="eeat-signals py-4 bg-light rounded shadow-sm mt-5">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <div class="d-flex flex-column align-items-center">
                    <i class="bi bi-patch-check-fill text-primary fs-2 mb-2"></i>
                    <h6 class="fw-bold mb-1">Expert Verified</h6>
                    <p class="small text-muted mb-0">Reviewed by SEO Architects</p>
                </div>
            </div>
            <div class="col-md-4 border-start border-end">
                <div class="d-flex flex-column align-items-center">
                    <i class="bi bi-calendar-check text-primary fs-2 mb-2"></i>
                    <h6 class="fw-bold mb-1">Updated Weekly</h6>
                    <p class="small text-muted mb-0">Last updated: <?= date('M d, Y') ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="d-flex flex-column align-items-center">
                    <i class="bi bi-shield-lock-fill text-primary fs-2 mb-2"></i>
                    <h6 class="fw-bold mb-1">Data Trusted</h6>
                    <p class="small text-muted mb-0">500+ Local Success Stories</p>
                </div>
            </div>
        </div>
    </div>
</div>
