<?php
use Core\Helpers;
$currentRoute = Helpers::currentRoute();
?>
<div class="admin-sidebar bg-dark text-white h-100 flex-column d-flex" style="width: 260px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
    <div class="sidebar-header p-4 d-flex align-items-center">
        <i class="bi bi-geo-alt-fill text-primary fs-3 me-2"></i>
        <span class="fw-bold fs-5">LSEO Admin</span>
    </div>
    
    <div class="sidebar-menu flex-grow-1 overflow-auto custom-scrollbar">
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-1">
                <a href="/admin/dashboard" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'dashboard') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-header mt-3 mb-2 small text-uppercase opacity-50 px-3">Content</li>
            <li class="nav-item mb-1">
                <a href="/admin/posts" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'posts') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-journal-text me-2"></i> Posts
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="/admin/pages" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'pages') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-file-earmark-text me-2"></i> Pages
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="/admin/services" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'services') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-gear-fill me-2"></i> Services
                </a>
            </li>
            <li class="nav-header mt-3 mb-2 small text-uppercase opacity-50 px-3">SEO & Marketing</li>
            <li class="nav-item mb-1">
                <a href="/admin/seo" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'seo') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-search me-2"></i> SEO Panel
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="/admin/leads" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'leads') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-envelope-paper me-2"></i> Leads
                </a>
            </li>
            <li class="nav-header mt-3 mb-2 small text-uppercase opacity-50 px-3">Settings</li>
            <li class="nav-item mb-1">
                <a href="/admin/settings" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'settings') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-sliders me-2"></i> General
                </a>
            </li>
            <li class="nav-item mb-1">
                <a href="/admin/users" class="nav-link text-white rounded p-3 <?= strpos($currentRoute, 'users') !== false ? 'bg-primary active' : 'opacity-75' ?>">
                    <i class="bi bi-people me-2"></i> Users
                </a>
            </li>
        </ul>
    </div>
    
    <div class="sidebar-footer p-4 border-top border-secondary">
        <a href="/" target="_blank" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-eye me-1"></i> Visit Site
        </a>
        <a href="/admin/logout" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
        </a>
    </div>
</div>
