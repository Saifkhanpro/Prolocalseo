<?php
use Core\Helpers;
?>
<div class="author-box mt-5 p-4 bg-white rounded shadow-sm border-start border-primary border-5 d-flex flex-column flex-md-row align-items-center align-items-md-start">
    <img src="<?= $author['avatar_url'] ?? '/assets/images/author-placeholder.jpg' ?>" class="rounded-circle mb-3 mb-md-0 me-md-4 border border-3 border-light shadow-sm" width="100" height="100" alt="<?= Helpers::escape($author['name']) ?>">
    <div>
        <h5 class="fw-bold mb-1"><?= Helpers::escape($author['name']) ?></h5>
        <p class="text-primary small fw-semibold mb-3"><?= Helpers::escape($author['designation'] ?? 'SEO Expert') ?></p>
        <p class="text-secondary mb-3 small">
            <?= Helpers::escape($author['bio'] ?? 'Senior content strategist and technical SEO specialist at LocalSEO.pk with over 10 years of experience in ranking businesses across Pakistan.') ?>
        </p>
        <div class="social-links d-flex gap-2">
            <?php if (!empty($author['twitter'])): ?><a href="<?= $author['twitter'] ?>" class="btn btn-light btn-sm rounded-circle"><i class="bi bi-twitter"></i></a><?php endif; ?>
            <?php if (!empty($author['linkedin'])): ?><a href="<?= $author['linkedin'] ?>" class="btn btn-light btn-sm rounded-circle"><i class="bi bi-linkedin"></i></a><?php endif; ?>
            <?php if (!empty($author['facebook'])): ?><a href="<?= $author['facebook'] ?>" class="btn btn-light btn-sm rounded-circle"><i class="bi bi-facebook"></i></a><?php endif; ?>
        </div>
    </div>
</div>
