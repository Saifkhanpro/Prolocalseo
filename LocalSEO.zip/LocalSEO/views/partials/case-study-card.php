<?php
use Core\Helpers;
?>
<div class="case-study-card h-100 border-0 shadow-sm overflow-hidden bg-white">
    <div class="row g-0 h-100">
        <div class="col-md-5">
            <div class="case-study-img h-100 bg-light" style="min-height: 250px; background-image: url('<?= $caseStudy['featured_image'] ?? '' ?>'); background-size: cover; background-position: center;"></div>
        </div>
        <div class="col-md-7 p-4 p-lg-5 d-flex flex-column justify-content-center">
            <div class="badge bg-primary-subtle text-primary border-0 fw-bold mb-3" style="width: fit-content;"><?= Helpers::escape($caseStudy['industry'] ?? 'Local Business') ?></div>
            <h3 class="h4 fw-bold mb-3"><?= Helpers::escape($caseStudy['title']) ?></h3>
            <p class="text-secondary mb-4"><?= Helpers::escape(Helpers::limitWords($caseStudy['summary'] ?? '', 25)) ?></p>
            <div class="stats-grid d-flex gap-4 mb-4">
                <div>
                    <h5 class="fw-bold text-success mb-0"><?= Helpers::escape($caseStudy['stat1_value'] ?? '+150%') ?></h5>
                    <small class="text-muted"><?= Helpers::escape($caseStudy['stat1_label'] ?? 'Traffic') ?></small>
                </div>
                <div>
                    <h5 class="fw-bold text-success mb-0"><?= Helpers::escape($caseStudy['stat2_value'] ?? 'Top 3') ?></h5>
                    <small class="text-muted"><?= Helpers::escape($caseStudy['stat2_label'] ?? 'Ranking') ?></small>
                </div>
            </div>
            <a href="/case-studies/<?= $caseStudy['slug'] ?>" class="btn btn-outline-primary rounded-pill px-4 align-self-start">View Results</a>
        </div>
    </div>
</div>
