<?php
use Core\Helpers;
?>
<div class="d-flex gap-3">
    <?php if ($fb = Helpers::setting('social_facebook')): ?>
    <a href="<?= Helpers::escape($fb) ?>" class="text-white opacity-75 text-decoration-none fs-5" target="_blank"><i class="bi bi-facebook"></i></a>
    <?php endif; ?>
    <?php if ($li = Helpers::setting('social_linkedin')): ?>
    <a href="<?= Helpers::escape($li) ?>" class="text-white opacity-75 text-decoration-none fs-5" target="_blank"><i class="bi bi-linkedin"></i></a>
    <?php endif; ?>
    <?php if ($tw = Helpers::setting('social_twitter')): ?>
    <a href="<?= Helpers::escape($tw) ?>" class="text-white opacity-75 text-decoration-none fs-5" target="_blank"><i class="bi bi-twitter"></i></a>
    <?php endif; ?>
    <?php if ($ig = Helpers::setting('social_instagram')): ?>
    <a href="<?= Helpers::escape($ig) ?>" class="text-white opacity-75 text-decoration-none fs-5" target="_blank"><i class="bi bi-instagram"></i></a>
    <?php endif; ?>
</div>
