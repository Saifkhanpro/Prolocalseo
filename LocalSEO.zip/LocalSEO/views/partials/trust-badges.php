<?php
use Core\Helpers;
?>
<div class="trust-badge-strip py-4 bg-light border-top border-bottom">
    <div class="container">
        <div class="row align-items-center justify-content-center text-center g-4">
            <div class="col-6 col-md-3">
                <div class="d-flex align-items-center justify-content-center opacity-75">
                    <i class="bi bi-google fs-2 me-2 text-primary"></i>
                    <span class="fw-bold">Google Partner</span>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="d-flex align-items-center justify-content-center opacity-75">
                    <i class="bi bi-shield-check fs-2 me-2 text-success"></i>
                    <span class="fw-bold">5-Star Rated</span>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="d-flex align-items-center justify-content-center opacity-75">
                    <i class="bi bi-people fs-2 me-2 text-info"></i>
                    <span class="fw-bold">500+ Clients</span>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="d-flex align-items-center justify-content-center opacity-75">
                    <i class="bi bi-clock-history fs-2 me-2 text-warning"></i>
                    <span class="fw-bold">Since 2020</span>
                </div>
            </div>
        </div>
    </div>
</div>
