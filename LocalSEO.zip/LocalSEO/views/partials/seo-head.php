<?php
use Core\Helpers;
$pageTitle = $pageTitle ?? Helpers::setting('site_title', 'LocalSEO.pk');
$metaDescription = $metaDescription ?? Helpers::setting('site_description', '');
$canonicalUrl = $canonicalUrl ?? (APP_URL . $_SERVER['REQUEST_URI']);
$robots = $robots ?? ['index', 'follow'];
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<title><?= Helpers::escape($pageTitle) ?></title>

<?php if (!empty($metaDescription)): ?>
<meta name="description" content="<?= Helpers::escape($metaDescription) ?>">
<?php endif; ?>

<link rel="canonical" href="<?= Helpers::escape($canonicalUrl) ?>">
<meta name="robots" content="<?= Helpers::escape(implode(', ', $robots)) ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="<?= $ogType ?? 'website' ?>">
<meta property="og:url" content="<?= Helpers::escape($canonicalUrl) ?>">
<meta property="og:title" content="<?= Helpers::escape($pageTitle) ?>">
<meta property="og:description" content="<?= Helpers::escape($metaDescription) ?>">
<meta property="og:image" content="<?= Helpers::escape($ogImage ?? APP_URL . '/assets/images/og-default.jpg') ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?= Helpers::escape($canonicalUrl) ?>">
<meta property="twitter:title" content="<?= Helpers::escape($pageTitle) ?>">
<meta property="twitter:description" content="<?= Helpers::escape($metaDescription) ?>">
<meta property="twitter:image" content="<?= Helpers::escape($ogImage ?? APP_URL . '/assets/images/og-default.jpg') ?>">

<!-- Schema Markup Injection -->
<?php if (!empty($schema)): ?>
<script type="application/ld+json">
    <?= json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
</script>
<?php endif; ?>

<!-- Verification Codes -->
<?php if ($googleVerify = Helpers::setting('verify_google')): ?>
<meta name="google-site-verification" content="<?= Helpers::escape($googleVerify) ?>">
<?php endif; ?>

<!-- Preloads & Critical Assets -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@500;700;800&display=swap" rel="stylesheet">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!-- Global Custom Styles -->
<link rel="stylesheet" href="/assets/css/style.css?v=<?= LSEO_VERSION ?>">

<style>
    :root {
        --primary-color: <?= Helpers::setting('primary_color', '#2563eb') ?>;
        --secondary-color: <?= Helpers::setting('secondary_color', '#1e40af') ?>;
        --accent-color: #f59e0b;
        --body-font: 'Inter', sans-serif;
        --heading-font: 'Outfit', sans-serif;
    }
</style>
