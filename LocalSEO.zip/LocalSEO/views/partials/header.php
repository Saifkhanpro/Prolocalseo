<?php
use Core\Helpers;
?>
<header class="site-header sticky-top bg-white shadow-sm border-bottom">
    <div class="container-fluid px-lg-5">
        <nav class="navbar navbar-expand-lg navbar-light py-3">
            <a class="navbar-brand fw-bold fs-4 d-flex align-items-center" href="/">
                <?php if ($logoUrl = Helpers::setting('logo_url')): ?>
                    <img src="<?= Helpers::escape($logoUrl) ?>" alt="<?= Helpers::escape(Helpers::setting('site_title', 'LocalSEO.pk')) ?> Logo" height="40" class="me-2">
                <?php else: ?>
                    <i class="bi bi-geo-alt-fill text-primary me-2"></i> LocalSEO.pk
                <?php endif; ?>
            </a>
            
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="mainNav">
                <?php include VIEW_PATH . '/partials/nav.php'; ?>
                
                <div class="d-flex align-items-center ms-lg-4 mt-3 mt-lg-0">
                    <a href="tel:<?= Helpers::escape(str_replace(' ', '', Helpers::setting('contact_phone', '+92 347 9007473'))) ?>" class="text-decoration-none fw-bold text-dark me-4 d-none d-xl-block">
                        <i class="bi bi-telephone text-primary me-2"></i> <?= Helpers::escape(Helpers::setting('contact_phone', '+92 347 9007473')) ?>
                    </a>
                    <a href="/contact" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold shadow-sm">Get Free Audit</a>
                </div>
            </div>
        </nav>
    </div>
</header>
