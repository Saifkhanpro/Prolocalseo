<?php
use Core\Helpers;
?>
<div class="cookie-notice position-fixed bottom-0 start-0 w-100 p-3 bg-dark text-white shadow-lg" id="cookieNotice" style="z-index: 1050; display: none;">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center">
        <p class="mb-3 mb-md-0 small">
            <?= Helpers::escape(Helpers::setting('cookie_notice_text', 'We use cookies to improve your experience. By continuing to visit this site, you agree to our use of cookies.')) ?>
        </p>
        <button class="btn btn-primary btn-sm px-4 rounded-pill" onclick="acceptCookies()">
            <?= Helpers::escape(Helpers::setting('cookie_notice_button', 'Accept')) ?>
        </button>
    </div>
</div>

<script>
function acceptCookies() {
    localStorage.setItem('cookiesAccepted', 'true');
    document.getElementById('cookieNotice').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    if (!localStorage.getItem('cookiesAccepted')) {
        document.getElementById('cookieNotice').style.display = 'block';
    }
});
</script>
