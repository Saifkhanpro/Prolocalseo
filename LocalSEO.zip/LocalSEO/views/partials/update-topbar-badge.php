<?php
$updateInfo = $updateInfo ?? null;
?>
<?php if ($updateInfo && $updateInfo['update_available']): ?>
    <a href="/admin/updates" class="btn btn-light position-relative p-2" title="Update Available">
        <i class="bi bi-cloud-arrow-down fs-5"></i>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
            1
        </span>
    </a>
<?php endif; ?>
