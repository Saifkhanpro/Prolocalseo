<?php
use Core\Helpers;
$whatsapp = str_replace(['+', ' ', '-'], '', Helpers::setting('whatsapp_number', '923479007473'));
$message = urlencode(Helpers::setting('whatsapp_default_message', 'Hi! I need Local SEO services for my business. Can you help?'));
?>
<a href="https://wa.me/<?= $whatsapp ?>?text=<?= $message ?>" target="_blank" class="whatsapp-float bg-success text-white shadow" title="Chat on WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>

<style>
    .whatsapp-float { 
        position: fixed; 
        width: 60px; 
        height: 60px; 
        bottom: 40px; 
        right: 40px; 
        border-radius: 50px; 
        text-align: center; 
        font-size: 30px; 
        box-shadow: 2px 2px 3px rgba(0,0,0,0.2); 
        z-index: 100; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        text-decoration: none; 
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
    }
    .whatsapp-float:hover { 
        transform: scale(1.1) rotate(5deg); 
        color: white; 
        box-shadow: 2px 5px 10px rgba(0,0,0,0.3);
    }
    @keyframes pulse-whatsapp {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    .whatsapp-float { animation: pulse-whatsapp 2s infinite; }
</style>
