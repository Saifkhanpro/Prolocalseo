<?php
use Core\Helpers;
?>
<div class="testimonial-card h-100 p-4 bg-white rounded shadow-sm border border-light">
    <div class="stars mb-3 text-warning">
        <?php for($i=0; $i < ($testimonial['rating'] ?? 5); $i++): ?>
            <i class="bi bi-star-fill"></i>
        <?php endfor; ?>
    </div>
    <p class="fst-italic text-secondary mb-4">"<?= Helpers::escape($testimonial['content']) ?>"</p>
    <div class="author d-flex align-items-center border-top pt-3">
        <img src="<?= $testimonial['avatar_url'] ?? '/assets/images/user-placeholder.png' ?>" class="rounded-circle me-3" width="50" height="50" alt="<?= Helpers::escape($testimonial['author_name']) ?>">
        <div>
            <h6 class="mb-0 fw-bold"><?= Helpers::escape($testimonial['author_name']) ?></h6>
            <small class="text-muted"><?= Helpers::escape($testimonial['author_designation'] ?? 'Business Owner') ?>, <?= Helpers::escape($testimonial['author_city'] ?? 'Pakistan') ?></small>
        </div>
    </div>
</div>
