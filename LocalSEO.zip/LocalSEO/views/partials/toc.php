<?php
use Core\Helpers;
?>
<div class="toc mb-5 p-4 bg-light rounded border-start border-primary border-4">
    <h6 class="fw-bold mb-3"><i class="bi bi-list-stars me-2"></i> Table of Contents</h6>
    <nav id="toc-nav" class="nav flex-column small">
        <!-- JS will populate this based on H2/H3 tags -->
    </nav>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const headings = document.querySelectorAll('.single-content h2, .single-content h3');
    const tocNav = document.getElementById('toc-nav');
    
    if (headings.length < 2) {
        document.querySelector('.toc').style.display = 'none';
        return;
    }
    
    headings.forEach((heading, index) => {
        const id = 'heading-' + index;
        heading.setAttribute('id', id);
        
        const link = document.createElement('a');
        link.className = 'nav-link py-1 text-dark hover-primary ' + (heading.tagName === 'H3' ? 'ms-3' : 'fw-semibold');
        link.href = '#' + id;
        link.textContent = heading.textContent;
        
        tocNav.appendChild(link);
    });
});
</script>
