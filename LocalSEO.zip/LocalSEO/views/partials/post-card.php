<?php
use Core\Helpers;
?>
<div class="card h-100 border-0 shadow-sm hover-up overflow-hidden">
    <?php if ($image = $post['featured_image_url'] ?? null): ?>
        <a href="/blog/<?= $post['slug'] ?>">
            <img src="<?= $image ?>" class="card-img-top" alt="<?= Helpers::escape($post['title']) ?>" loading="lazy">
        </a>
    <?php endif; ?>
    <div class="card-body p-4">
        <div class="d-flex align-items-center mb-3">
            <span class="badge bg-primary-subtle text-primary border-0 fw-bold me-2"><?= Helpers::escape($post['category_name'] ?? 'Uncategorized') ?></span>
            <small class="text-muted"><i class="bi bi-clock me-1"></i> <?= date('M d, Y', strtotime($post['created_at'])) ?></small>
        </div>
        <h4 class="card-title h5 fw-bold mb-3">
            <a href="/blog/<?= $post['slug'] ?>" class="text-dark text-decoration-none transition-all hover-primary">
                <?= Helpers::escape($post['title']) ?>
            </a>
        </h4>
        <p class="card-text text-secondary line-clamp-3">
            <?= Helpers::escape($post['excerpt'] ?? Helpers::limitWords($post['content'], 20)) ?>
        </p>
    </div>
    <div class="card-footer bg-transparent border-0 p-4 pt-0">
        <a href="/blog/<?= $post['slug'] ?>" class="btn btn-link p-0 text-primary text-decoration-none fw-bold">
            Read More <i class="bi bi-arrow-right ms-1"></i>
        </a>
    </div>
</div>
