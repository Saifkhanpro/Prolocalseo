<?php
use Core\Helpers;
$user = $_SESSION['user'] ?? null;
?>
<header class="admin-topbar bg-white border-bottom p-3 d-flex justify-content-between align-items-center" style="margin-left: 260px; position: sticky; top: 0; z-index: 999;">
    <div class="d-flex align-items-center">
        <button class="btn btn-light d-md-none me-2"><i class="bi bi-list"></i></button>
        <h5 class="mb-0 fw-bold"><?= $pageTitle ?? 'Admin Dashboard' ?></h5>
    </div>
    
    <div class="d-flex align-items-center gap-3">
        <?php include VIEW_PATH . '/partials/update-topbar-badge.php'; ?>
        
        <div class="dropdown">
            <button class="btn btn-light rounded-circle p-0" type="button" data-bs-toggle="dropdown" style="width: 40px; height: 40px;">
                <img src="<?= $user['avatar_url'] ?? '/assets/images/admin-placeholder.jpg' ?>" class="rounded-circle" width="36" height="36">
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                <li class="p-3 border-bottom">
                    <h6 class="mb-0 fw-bold"><?= Helpers::escape($user['display_name'] ?? 'Admin') ?></h6>
                    <small class="text-muted"><?= Helpers::escape($user['email'] ?? 'admin@localseo.pk') ?></small>
                </li>
                <li><a class="dropdown-item py-2" href="/admin/profile"><i class="bi bi-person me-2"></i> Profile</a></li>
                <li><a class="dropdown-item py-2" href="/admin/settings"><i class="bi bi-gear me-2"></i> Settings</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item py-2 text-danger" href="/admin/logout"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</header>
