<?php
use Core\Helpers;
?>
<div class="card h-100 border-0 shadow-sm hover-up text-center p-4">
    <div class="service-icon mb-4 mx-auto bg-primary-subtle rounded-circle d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
        <i class="bi <?= $service['icon_class'] ?? 'bi-gear' ?> text-primary fs-1"></i>
    </div>
    <h4 class="h5 fw-bold mb-3"><?= Helpers::escape($service['title']) ?></h4>
    <p class="text-secondary mb-4 line-clamp-3">
        <?= Helpers::escape($service['excerpt'] ?? Helpers::limitWords($service['content'], 15)) ?>
    </p>
    <a href="/services/<?= $service['slug'] ?>" class="btn btn-outline-primary rounded-pill px-4 stretched-link transition-all">
        Learn More
    </a>
</div>
