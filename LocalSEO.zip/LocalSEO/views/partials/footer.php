<?php
use Core\Helpers;
?>
<footer class="site-footer bg-dark text-white pt-5 pb-3 mt-5">
    <div class="container pt-4">
        <div class="row g-5 mb-5">
            <div class="col-lg-4 col-md-6">
                <a href="/" class="d-inline-flex align-items-center text-white text-decoration-none mb-4 fs-4 fw-bold">
                    <i class="bi bi-geo-alt-fill text-primary me-2"></i> LocalSEO.pk
                </a>
                <p class="text-light opacity-75 mb-4">
                    <?= Helpers::escape(Helpers::setting('site_description', 'The leading local SEO agency in Pakistan helping businesses dominate local search results and drive real revenue.')) ?>
                </p>
                <?php include VIEW_PATH . '/partials/social-icons.php'; ?>
            </div>
            
            <div class="col-lg-2 col-md-6">
                <h5 class="text-white mb-4 fw-bold">Company</h5>
                <ul class="list-unstyled footer-links">
                    <li class="mb-2"><a href="/about" class="text-white opacity-75 text-decoration-none">About Us</a></li>
                    <li class="mb-2"><a href="/services" class="text-white opacity-75 text-decoration-none">SEO Services</a></li>
                    <li class="mb-2"><a href="/case-studies" class="text-white opacity-75 text-decoration-none">Case Studies</a></li>
                    <li class="mb-2"><a href="/blog" class="text-white opacity-75 text-decoration-none">SEO Blog</a></li>
                    <li class="mb-2"><a href="/contact" class="text-white opacity-75 text-decoration-none">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4 fw-bold">Top Locations</h5>
                <ul class="list-unstyled footer-links">
                    <li class="mb-2"><a href="/local-seo/lahore" class="text-white opacity-75 text-decoration-none">SEO Services Lahore</a></li>
                    <li class="mb-2"><a href="/local-seo/karachi" class="text-white opacity-75 text-decoration-none">SEO Services Karachi</a></li>
                    <li class="mb-2"><a href="/local-seo/islamabad" class="text-white opacity-75 text-decoration-none">SEO Services Islamabad</a></li>
                    <li class="mb-2"><a href="/local-seo/faisalabad" class="text-white opacity-75 text-decoration-none">SEO Services Faisalabad</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-6">
                <h5 class="text-white mb-4 fw-bold">Contact Info</h5>
                <ul class="list-unstyled">
                    <li class="mb-3 d-flex text-white opacity-75">
                        <i class="bi bi-geo-alt text-primary fs-5 me-3"></i> 
                        <span><?= Helpers::escape(Helpers::setting('business_address', 'Lahore, Pakistan')) ?></span>
                    </li>
                    <li class="mb-3 d-flex text-white opacity-75">
                        <i class="bi bi-telephone text-primary fs-5 me-3"></i> 
                        <span><?= Helpers::escape(Helpers::setting('contact_phone', '+92 347 9007473')) ?></span>
                    </li>
                    <li class="mb-3 d-flex text-white opacity-75">
                        <i class="bi bi-envelope text-primary fs-5 me-3"></i> 
                        <span><?= Helpers::escape(Helpers::setting('contact_email', 'info@localseo.pk')) ?></span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="border-top border-secondary pt-4 d-flex flex-column flex-md-row justify-content-between align-items-center">
            <p class="mb-0 text-white opacity-50 small">&copy; <?= date('Y') ?> LocalSEO.pk. All Rights Reserved.</p>
            <div class="mt-3 mt-md-0">
                <a href="/privacy-policy" class="text-white opacity-50 text-decoration-none small me-3">Privacy Policy</a>
                <a href="/terms-of-service" class="text-white opacity-50 text-decoration-none small">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>
