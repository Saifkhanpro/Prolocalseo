<?php ob_start(); ?>

<section class="py-5 bg-light">
    <div class="container py-lg-5">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <span class="badge bg-primary-soft text-primary text-uppercase tracking-wider mb-2">Search Results</span>
                <h1 class="display-4 fw-bold text-dark">Results for "<?= htmlspecialchars($query) ?>"</h1>
                <p class="lead text-muted">Showing results found across blog posts, services, and official pages.</p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-10 mx-auto">
                <form action="/search" method="GET" class="mb-5">
                    <div class="input-group input-group-lg shadow-sm">
                        <input type="text" name="s" class="form-control border-0" value="<?= htmlspecialchars($query) ?>" placeholder="Search again...">
                        <button class="btn btn-primary px-4" type="submit"><i class="bi bi-search"></i></button>
                    </div>
                </form>

                <?php if (empty($results)): ?>
                    <div class="text-center py-5 bg-white rounded-4 shadow-sm">
                        <div class="mb-4">
                            <i class="bi bi-question-circle display-1 text-light"></i>
                        </div>
                        <h3>No results found</h3>
                        <p class="text-muted">We couldn't find anything matching your search. Try different keywords.</p>
                        <a href="/" class="btn btn-outline-primary mt-3">Back to Home</a>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush border-0 rounded-4 shadow-sm bg-white overflow-hidden">
                        <?php foreach ($results as $item): ?>
                            <?php 
                                $link = '/' . $item['slug'];
                                if ($item['type'] === 'blog') $link = '/blog/' . $item['slug'];
                                if ($item['type'] === 'service') $link = '/services/' . $item['slug'];
                            ?>
                            <a href="<?= $link ?>" class="list-group-item list-group-item-action p-4 border-0 border-bottom">
                                <span class="badge bg-light text-dark text-uppercase small mb-2"><?= $item['type'] ?></span>
                                <h4 class="fw-bold text-dark mb-2"><?= htmlspecialchars($item['title']) ?></h4>
                                <p class="text-muted mb-0 small"><?= htmlspecialchars(substr(strip_tags($item['desc']), 0, 180)) ?>...</p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
