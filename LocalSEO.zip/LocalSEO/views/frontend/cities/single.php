<?php ob_start(); ?>

<div class="container-fluid px-0">
    <div class="row g-0">
        <!-- Hero Content -->
        <div class="col-lg-6 bg-primary text-white d-flex align-items-center py-6 position-relative z-1" style="min-height: 500px;">
            <!-- Background Decoration -->
            <div class="position-absolute end-0 bottom-0 text-white opacity-10 pe-none" style="transform: translate(20%, 20%); font-size: 30rem; line-height: 1;">
                <i class="bi bi-geo-alt-fill"></i>
            </div>
            
            <div class="container-fluid px-4 px-md-5 mx-xl-4 position-relative z-1">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/local-seo" class="text-white-50 text-decoration-none">Locations</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page"><?= \Core\Helpers::escape($city['city_name']) ?></li>
                  </ol>
                </nav>
                
                <h1 class="display-3 fw-bolder mb-4 text-white lh-sm">
                    Local SEO Expert in<br>
                    <span class="text-warning text-decoration-underline"><?= \Core\Helpers::escape($city['city_name']) ?></span>
                </h1>
                
                <p class="lead fs-4 opacity-85 mb-5 pe-lg-5">
                    Dominate the local search results in <?= \Core\Helpers::escape($city['city_name']) ?>, <?= \Core\Helpers::escape($city['state_province'] ?: 'Pakistan') ?>. We help your business claim the top spot on Google Maps and organic rankings.
                </p>
                
                <div class="d-flex flex-wrap gap-3">
                    <a href="/contact?city=<?= urlencode($city['city_name']) ?>" class="btn btn-warning btn-lg rounded-pill px-5 py-3 fw-bold text-dark shadow-sm">
                        Get Free SEO Audit <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                    <a href="tel:<?= \Core\Helpers::escape(\Core\Helpers::setting('seo_business_phone', '+923000000000')) ?>" class="btn btn-outline-light btn-lg rounded-pill px-4 py-3 fw-bold">
                        <i class="bi bi-telephone ms-0 me-2"></i> Call Now
                    </a>
                </div>
                
                <?php if ($city['population']): ?>
                <div class="mt-5 pt-3 border-top border-light border-opacity-25 d-inline-block pe-5">
                    <span class="d-block small text-white-50 mb-1 text-uppercase fw-semibold tracking-wide">Target Demographics</span>
                    <span class="fw-bold fs-5"><i class="bi bi-people-fill me-2 text-warning"></i> <?= \Core\Helpers::escape($city['population']) ?> Population</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Hero Map/Image -->
        <div class="col-lg-6 position-relative d-none d-lg-block bg-dark">
            <?php if ($city['featured_image_id']): ?>
                <?php 
                    $db = \Core\Database::getInstance();
                    $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$city['featured_image_id']]);
                    if ($media): ?>
                        <div class="w-100 h-100" style="background-image: url('/<?= ltrim($media['file_path'], '/') ?>'); background-size: cover; background-position: center;"></div>
                <?php endif; ?>
            <?php elseif ($city['map_embed_code']): ?>
                <div class="w-100 h-100 map-container grayscale-map">
                    <?= $city['map_embed_code'] ?>
                </div>
            <?php else: ?>
                <div class="w-100 h-100 bg-secondary d-flex align-items-center justify-content-center">
                    <i class="bi bi-map text-white-50" style="font-size: 10rem;"></i>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="container py-5 my-lg-5">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8">
            <article class="content-formatted fs-5">
                <?= $city['content'] ?>
            </article>
            
            <?php if ($city['map_embed_code'] && !$city['featured_image_id']): ?>
                <!-- Show map here if it wasn't shown in header due to img priority -->
                <div class="mt-5 rounded-4 overflow-hidden border shadow-sm">
                    <div class="bg-light px-4 py-3 border-bottom d-flex align-items-center">
                        <i class="bi bi-geo-alt-fill text-danger me-2 fs-5"></i> 
                        <h4 class="mb-0 fw-bold fs-5">Service Area Map: <?= \Core\Helpers::escape($city['city_name']) ?></h4>
                    </div>
                    <div class="ratio ratio-21x9">
                        <?= $city['map_embed_code'] ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .py-6 { padding-top: 6rem!important; padding-bottom: 6rem!important; }
    .tracking-wide { letter-spacing: 0.05em; }
    .grayscale-map iframe { filter: grayscale(50%) contrast(1.1); width: 100%!important; height: 100%!important; }
    .content-formatted h2 { margin-top: 2.5rem; margin-bottom: 1.25rem; font-weight: 800; color: #0f172a; font-size: 2.5rem; letter-spacing: -0.02em; }
    .content-formatted h3 { margin-top: 2rem; margin-bottom: 1rem; font-weight: 700; color: #1e293b; font-size: 1.75rem; }
    .content-formatted p { line-height: 1.8; color: #334155; margin-bottom: 1.5rem; }
    .content-formatted ul { margin-bottom: 1.5rem; color: #334155; line-height: 1.8; padding-left: 2rem; }
    .content-formatted li { margin-bottom: 0.5rem; padding-left: 0.5rem; }
    .content-formatted li::marker { color: var(--primary-color); font-weight: bold; }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
