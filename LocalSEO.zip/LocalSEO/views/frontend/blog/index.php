<?php ob_start(); ?>

<div class="bg-dark py-5 text-white border-bottom">
    <div class="container py-4 text-center">
        <h1 class="display-4 fw-bolder mb-3 text-white">Local SEO Blog</h1>
        <p class="lead text-white-50 max-w-700 mx-auto">Latest insights, case studies, and advanced strategies on how to position your local business #1 on Google Maps and Organic Search.</p>
    </div>
</div>

<div class="container py-5 my-4">
    <div class="row g-5">
        <!-- Main Content -->
        <div class="col-lg-8">
            <?php if (empty($posts['items'])): ?>
                <div class="alert alert-light border text-center p-5 rounded-4">
                    <i class="bi bi-journal-text fs-1 text-muted mb-3 d-block"></i>
                    <h4 class="fw-bold">No posts found</h4>
                    <p class="text-muted mb-0">Check back soon for latest SEO tips and strategies.</p>
                </div>
            <?php else: ?>
                <?php foreach ($posts['items'] as $post): ?>
                    <article class="card border-0 shadow-sm rounded-4 mb-5 overflow-hidden post-card">
                        <div class="row g-0">
                            <?php if ($post['featured_image_id']): ?>
                                <?php 
                                    $db = \Core\Database::getInstance();
                                    $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$post['featured_image_id']]);
                                ?>
                                <div class="col-md-5 col-xl-4 bg-light d-flex align-items-center justify-content-center overflow-hidden">
                                    <img src="/<?= ltrim($media['file_path'], '/') ?>" class="img-fluid h-100 w-100 object-fit-cover post-image" alt="<?= \Core\Helpers::escape($post['title']) ?>">
                                </div>
                                <div class="col-md-7 col-xl-8">
                            <?php else: ?>
                                <div class="col-12">
                            <?php endif; ?>
                                <div class="card-body p-4 p-lg-5 d-flex flex-column h-100">
                                    <div class="d-flex align-items-center text-muted small fw-medium mb-3 gap-3">
                                        <span><i class="bi bi-calendar3 me-2"></i><?= date('M d, Y', strtotime($post['published_at'])) ?></span>
                                        <span><i class="bi bi-check2-circle text-primary me-2"></i>SEO Tips</span>
                                    </div>
                                    <h2 class="h3 fw-bold mb-3"><a href="/blog/<?= \Core\Helpers::escape($post['slug']) ?>" class="text-dark text-decoration-none post-title"><?= \Core\Helpers::escape($post['title']) ?></a></h2>
                                    <p class="text-muted mb-4 flex-grow-1"><?= \Core\Helpers::escape($post['excerpt'] ?: strip_tags(substr($post['content'], 0, 150)) . '...') ?></p>
                                    
                                    <div class="mt-auto border-top pt-3 text-end text-md-start">
                                        <a href="/blog/<?= \Core\Helpers::escape($post['slug']) ?>" class="fw-bold text-primary text-decoration-none d-inline-flex align-items-center text-uppercase fs-7 tracking-wide">
                                            Read Article <i class="bi bi-arrow-right ms-2 transition-transform"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
                
                <!-- Pagination -->
                <?php if ($posts['last_page'] > 1): ?>
                    <nav aria-label="Blog pagination" class="mt-5 pt-4 border-top">
                        <ul class="pagination pagination-lg justify-content-center">
                            <?php if ($posts['current'] > 1): ?>
                                <li class="page-item"><a class="page-link shadow-sm border-0 bg-white text-dark rounded-pill px-4 mx-1 fw-bold" href="/blog?p=<?= $posts['current'] - 1 ?>">Previous</a></li>
                            <?php endif; ?>
                            
                            <!-- Simplified Pagination logic for demo -->
                            <?php for ($i = max(1, $posts['current'] - 2); $i <= min($posts['last_page'], $posts['current'] + 2); $i++): ?>
                                <li class="page-item <?= $i == $posts['current'] ? 'active' : '' ?>">
                                    <a class="page-link shadow-sm border-0 <?= $i == $posts['current'] ? 'bg-primary text-white' : 'bg-white text-dark' ?> rounded-circle mx-1 d-flex align-items-center justify-content-center" style="width:48px;height:48px;" href="/blog?p=<?= $i ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($posts['current'] < $posts['last_page']): ?>
                                <li class="page-item"><a class="page-link shadow-sm border-0 bg-white text-dark rounded-pill px-4 mx-1 fw-bold" href="/blog?p=<?= $posts['current'] + 1 ?>">Next</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4 ps-xl-5">
            <div class="sticky-sidebar top-100">
                <!-- Newsletter Widget -->
                <div class="card border-0 shadow-sm rounded-4 mb-4 bg-primary text-white overflow-hidden">
                    <div class="position-absolute end-0 top-0 opacity-10 pe-none" style="transform: translate(20%, -20%); font-size: 15rem; line-height: 1;">
                        <i class="bi bi-envelope"></i>
                    </div>
                    <div class="card-body p-4 p-xl-5 position-relative z-1">
                        <h4 class="fw-bold mb-3 text-white">Advanced SEO Tips</h4>
                        <p class="mb-4 opacity-75 small">Get exclusive local SEO strategies and Google algorithm updates delivered directly to your inbox. No spam.</p>
                        <form action="#" method="POST">
                            <div class="input-group mb-2">
                                <input type="email" class="form-control border-0 px-3 py-2 bg-white" placeholder="Email address" required>
                            </div>
                            <button class="btn btn-dark w-100 py-2 fw-bold" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>

                <!-- Featured Testimonial Widget -->
                <div class="card border border-2 border-primary-subtle rounded-4 bg-light shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex text-warning mb-3 fs-5">
                            <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                        <p class="fst-italic text-dark fw-medium mb-3">"LocalSEO.pk took our business from nowhere on the map to consistently ranking #1 for our main keywords. Traffic tripled within 3 months."</p>
                        <hr>
                        <div class="text-sm">
                            <strong class="d-block text-primary">Ali Raza</strong>
                            <span class="text-muted small">CEO, Raza Dental Clinic</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .max-w-700 { max-width: 700px; }
    .fs-7 { font-size: 0.85rem; }
    .tracking-wide { letter-spacing: 0.05em; }
    .sticky-sidebar { position: sticky; top: 100px; }
    .post-card { transition: box-shadow 0.3s ease; }
    .post-card:hover { box-shadow: 0 1rem 3rem rgba(0,0,0,.1)!important; }
    .post-image { transition: transform 0.6s ease; }
    .post-card:hover .post-image { transform: scale(1.05); }
    .post-title { transition: color 0.2s ease; }
    .post-card:hover .post-title { color: var(--primary-color)!important; }
    .post-card .bi-arrow-right { transition: transform 0.2s; }
    .post-card:hover .bi-arrow-right { transform: translateX(5px); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
