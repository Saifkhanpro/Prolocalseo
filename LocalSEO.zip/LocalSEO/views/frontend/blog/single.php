<?php ob_start(); ?>

<div class="container py-5 my-md-4">
    <div class="row justify-content-center">
        <!-- Main Content -->
        <div class="col-lg-8">
            <article class="bg-white p-4 p-md-5 rounded-4 shadow-sm border mb-5">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-4 small fw-medium">
                    <li class="breadcrumb-item"><a href="/" class="text-muted text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/blog" class="text-muted text-decoration-none">Blog</a></li>
                    <li class="breadcrumb-item active text-dark" aria-current="page"><?= \Core\Helpers::escape($post['title']) ?></li>
                  </ol>
                </nav>

                <h1 class="display-4 fw-bolder mb-4 text-dark lh-sm"><?= \Core\Helpers::escape($post['title']) ?></h1>
                
                <div class="d-flex align-items-center mb-5 pb-4 border-bottom flex-wrap gap-4">
                    <div class="d-flex align-items-center">
                        <?php if (isset($post['author']['avatar_url']) && $post['author']['avatar_url']): ?>
                            <img src="<?= $post['author']['avatar_url'] ?>" class="rounded-circle me-3 border" width="48" height="48" alt="<?= \Core\Helpers::escape($post['author']['display_name']) ?>">
                        <?php else: ?>
                            <div class="rounded-circle me-3 bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-5 shadow-sm" style="width: 48px; height: 48px;">
                                <?= strtoupper(substr($post['author']['display_name'], 0, 1)) ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <span class="d-block fw-bold text-dark"><?= \Core\Helpers::escape($post['author']['display_name']) ?></span>
                            <span class="text-muted small">SEO Expert</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center text-muted">
                        <i class="bi bi-calendar3 me-2 fs-5"></i>
                        <div class="small">
                            <span class="d-block fw-semibold text-dark">Published</span>
                            <span><?= date('M d, Y', strtotime($post['published_at'])) ?></span>
                        </div>
                    </div>
                    <?php if (isset($categories) && !empty($categories)): ?>
                    <div class="d-flex align-items-center text-muted border-start ps-4">
                        <i class="bi bi-folder2-open me-2 fs-5 text-primary"></i>
                        <div class="small">
                            <span class="d-block fw-semibold text-dark">Category</span>
                            <a href="/category/<?= $categories[0]['slug'] ?>" class="text-decoration-none text-primary"><?= \Core\Helpers::escape($categories[0]['name']) ?></a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($post['featured_image_id']): ?>
                    <?php 
                        $db = \Core\Database::getInstance();
                        $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$post['featured_image_id']]);
                        if ($media): ?>
                        <div class="mb-5 rounded-4 overflow-hidden border shadow-sm">
                            <img src="/<?= ltrim($media['file_path'], '/') ?>" class="img-fluid w-100" alt="<?= \Core\Helpers::escape($post['title']) ?>">
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="content-formatted fs-5 text-dark pb-4 border-bottom mb-5">
                    <?= $post['content'] ?>
                    
                    <?php if (isset($tags) && !empty($tags)): ?>
                        <div class="mt-5 pt-3">
                            <span class="fw-bold text-dark me-2 small text-uppercase tracking-wide">Tags:</span>
                            <?php foreach ($tags as $tag): ?>
                                <a href="/tag/<?= $tag['slug'] ?>" class="badge bg-light text-dark text-decoration-none border px-2 py-1 me-1 hover-primary transition-all"><?= \Core\Helpers::escape($tag['name']) ?></a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Author Bio Box -->
                <div class="bg-light rounded-4 p-4 d-flex align-items-center border mb-5">
                    <?php if (isset($post['author']['avatar_url']) && $post['author']['avatar_url']): ?>
                        <img src="<?= $post['author']['avatar_url'] ?>" class="rounded-circle me-4 border bg-white" width="80" height="80" alt="<?= \Core\Helpers::escape($post['author']['display_name']) ?>">
                    <?php else: ?>
                        <div class="rounded-circle me-4 bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-2 shadow-sm flex-shrink-0" style="width: 80px; height: 80px;">
                            <?= strtoupper(substr($post['author']['display_name'], 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                    <div>
                        <h4 class="fw-bold mb-1 fs-5">Written by <?= \Core\Helpers::escape($post['author']['display_name']) ?></h4>
                        <p class="text-muted mb-0 small lh-sm">Lead SEO Strategist at LocalSEO.pk. passionate about helping businesses grow their revenue through organic local search visibility.</p>
                    </div>
                </div>
            </article>

            <!-- Comments Area (Placeholder logic) -->
            <?php if ($post['comment_status'] === 'open'): ?>
            <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border" id="comments">
                <h3 class="fw-bolder mb-4">Leave a Comment</h3>
                <form action="/comment" method="POST">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                    
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-medium small">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control bg-light border-0 py-2" name="author_name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-medium small">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control bg-light border-0 py-2" name="author_email" required>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-medium small">Your Comment <span class="text-danger">*</span></label>
                        <textarea class="form-control bg-light border-0 py-2" name="content" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold py-2">Submit Comment</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4 ps-xl-5 mt-5 mt-lg-0">
            <div class="sticky-sidebar top-100">
                <div class="card border-0 shadow-sm rounded-4 mb-4 bg-primary text-white text-center">
                    <div class="card-body p-5">
                        <i class="bi bi-graph-up-arrow fs-1 text-warning mb-3 d-block"></i>
                        <h4 class="fw-bold h3 mb-3 text-white">Need Higher Rankings?</h4>
                        <p class="mb-4 opacity-85">Stop struggling with DIY SEO. Let our experts craft a custom strategy for your business.</p>
                        <a href="/contact" class="btn btn-warning w-100 rounded-pill py-3 fw-bold text-dark shadow-sm">View Free Audit</a>
                    </div>
                </div>

                <div class="card border border-light-subtle rounded-4 shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold border-bottom pb-3 mb-4"><i class="bi bi-fire text-danger me-2"></i> Recent Posts</h5>
                        <ul class="list-unstyled mb-0 recent-posts-list">
                            <?php 
                            $db = \Core\Database::getInstance();
                            $recentPosts = $db->fetchAll("SELECT title, slug, published_at FROM {$db->t('posts')} WHERE status='published' AND type='post' AND id != ? ORDER BY published_at DESC LIMIT 5", [$post['id']]);
                            foreach ($recentPosts as $rp): ?>
                                <li class="mb-3 border-bottom pb-3 last-no-border">
                                    <h6 class="fw-bold mb-1 lh-base"><a href="/blog/<?= \Core\Helpers::escape($rp['slug']) ?>" class="text-decoration-none text-dark hover-primary transition-all"><?= \Core\Helpers::escape($rp['title']) ?></a></h6>
                                    <span class="text-muted small fs-7"><i class="bi bi-calendar3 me-1"></i> <?= date('M d, Y', strtotime($rp['published_at'])) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .tracking-wide { letter-spacing: 0.05em; }
    .fs-7 { font-size: 0.85rem; }
    .sticky-sidebar { position: sticky; top: 100px; }
    .hover-primary:hover { color: var(--primary-color)!important; border-color: var(--primary-color)!important; }
    .transition-all { transition: all 0.2s ease; }
    .recent-posts-list .last-no-border:last-child { border-bottom: none!important; margin-bottom: 0!important; padding-bottom: 0!important; }
    .content-formatted h2 { margin-top: 2.5rem; margin-bottom: 1rem; font-weight: 800; color: #0f172a; font-size: 2.25rem; }
    .content-formatted h3 { margin-top: 2rem; margin-bottom: 1rem; font-weight: 700; color: #1e293b; font-size: 1.75rem;}
    .content-formatted p { line-height: 1.85; color: #334155; margin-bottom: 1.5rem; }
    .content-formatted ul, .content-formatted ol { margin-bottom: 1.5rem; padding-left: 2rem; }
    .content-formatted li { margin-bottom: 0.5rem; line-height: 1.85; color: #334155; }
    .content-formatted a { color: var(--primary-color); text-decoration: none; font-weight: 500; border-bottom: 1px solid transparent; transition: all 0.2s; }
    .content-formatted a:hover { border-bottom: 1px solid var(--primary-color); }
    .content-formatted img { max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1.5rem 0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .content-formatted blockquote { border-left: 4px solid var(--primary-color); background: #f8f9fa; padding: 1.5rem; margin: 2rem 0; border-radius: 0 0.5rem 0.5rem 0; font-style: italic; color: #475569; }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
