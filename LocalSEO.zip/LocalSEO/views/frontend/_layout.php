<?php
use Core\Helpers;
?>
<!DOCTYPE html>
<html lang="<?= Helpers::setting('language', 'en') ?>">
<head>
    <?php include VIEW_PATH . '/partials/seo-head.php'; ?>
    <?php include VIEW_PATH . '/partials/tracking-codes.php'; ?>
    <?= $extraHead ?? '' ?>
</head>
<body class="d-flex flex-column min-vh-100">

    <?php include VIEW_PATH . '/partials/header.php'; ?>

    <!-- Main Content Area -->
    <main class="site-main flex-grow-1">
        <?php if ($flash = Helpers::flash('success')): ?>
            <div class="container mt-4">
                <div class="alert alert-success alert-dismissible bg-success text-white border-0 shadow-sm fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($flash = Helpers::flash('error')): ?>
            <div class="container mt-4">
                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 shadow-sm fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        <!-- Content Injection -->
        <?= $content ?>
    </main>

    <?php include VIEW_PATH . '/partials/footer.php'; ?>
    <?php include VIEW_PATH . '/partials/whatsapp-button.php'; ?>
    <?php include VIEW_PATH . '/partials/cookie-notice.php'; ?>

    <!-- Core Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="/assets/js/main.js?v=<?= LSEO_VERSION ?>"></script>

    <?= $extraFooter ?? '' ?>
    
    <!-- Body Close Scripts -->
    <?= Helpers::setting('custom_body_close_code') ?>
</body>
</html>
