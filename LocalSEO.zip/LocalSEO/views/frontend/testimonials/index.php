<?php ob_start(); ?>

<section class="py-5 bg-primary text-white text-center">
    <div class="container py-lg-5">
        <h1 class="display-3 fw-bold mb-3">Client Success Stories</h1>
        <p class="lead opacity-75 mx-auto" style="max-width: 700px;">Our results speak through the voices of the businesses we lead to dominance in local search results.</p>
    </div>
</section>

<section class="py-5">
    <div class="container py-lg-5">
        <div class="row g-4">
            <?php if (empty($testimonials)): ?>
                <div class="col-12 text-center py-5">
                    <p class="text-muted">Coming soon...</p>
                </div>
            <?php else: ?>
                <?php foreach ($testimonials as $t): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 border-0 shadow-sm rounded-4 p-4 text-center">
                            <div class="mb-3 text-warning">
                                <?php for($i=0; $i<$t['rating']; $i++): ?>
                                    <i class="bi bi-star-fill"></i>
                                <?php endfor; ?>
                            </div>
                            <blockquote class="mb-4 fst-italic text-dark">
                                "<?= htmlspecialchars($t['content']) ?>"
                            </blockquote>
                            <div class="mt-auto">
                                <h5 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($t['client_name']) ?></h5>
                                <div class="small text-muted"><?= htmlspecialchars($t['designation']) ?>, <?= htmlspecialchars($t['company']) ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
