<?php ob_start(); ?>

<?php 
$headerBg = 'background-color: #0f172a;';
if ($case['featured_image_id']) {
    $db = \Core\Database::getInstance();
    $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$case['featured_image_id']]);
    if ($media) {
        $headerBg = "background-image: linear-gradient(rgba(15, 23, 42, 0.85), rgba(15, 23, 42, 0.95)), url('/" . ltrim($media['file_path'], '/') . "'); background-size: cover; background-position: center;";
    }
}
?>

<div class="case-hero py-6 text-white position-relative" style="<?= $headerBg ?>">
    <div class="container py-5 position-relative z-1 text-center">
        <nav aria-label="breadcrumb" class="d-flex justify-content-center mb-4">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="/case-studies" class="text-white-50 text-decoration-none">Case Studies</a></li>
            <li class="breadcrumb-item active text-white" aria-current="page"><?= \Core\Helpers::escape($case['client_name']) ?></li>
          </ol>
        </nav>
        
        <span class="badge bg-primary text-white rounded-pill px-4 py-2 mb-4 fw-bold tracking-wide text-uppercase">Case Study: <?= \Core\Helpers::escape($case['industry']) ?></span>
        
        <h1 class="display-3 fw-bolder mb-5 mx-auto" style="max-width: 900px;"><?= \Core\Helpers::escape($case['title']) ?></h1>
        
        <!-- Key Metrics Highlights in Header -->
        <?php if ($case['metrics_html']): ?>
        <div class="row justify-content-center g-4 mt-2">
            <?= $case['metrics_html'] // Assuming this is clean, pre-formatted HTML from admin like <div class="col-md-4"><h2>+X%</h2><p>Traffic</p></div> ?>
        </div>
        <?php else: ?>
        <div class="row justify-content-center mt-2">
            <div class="col-lg-8">
                <div class="bg-white bg-opacity-10 rounded-4 p-4 p-md-5 border border-white border-opacity-25 backdrop-blur">
                    <p class="lead mb-0 fs-4 fw-medium text-white-50">Local SEO Campaign for <?= \Core\Helpers::escape($case['client_name']) ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="container py-5 my-4">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8">
            
            <div class="card border-0 shadow-sm rounded-4 mb-5 p-4 p-md-5 mt-n5 position-relative z-2 bg-white">
                <div class="row g-4 text-center">
                    <div class="col-md-4 border-end-md">
                        <span class="d-block text-muted small text-uppercase tracking-wide fw-bold mb-2">Client</span>
                        <span class="fs-5 fw-bold text-dark"><?= \Core\Helpers::escape($case['client_name']) ?></span>
                    </div>
                    <div class="col-md-4 border-end-md">
                        <span class="d-block text-muted small text-uppercase tracking-wide fw-bold mb-2">Industry</span>
                        <span class="fs-5 fw-bold text-dark"><?= \Core\Helpers::escape($case['industry']) ?></span>
                    </div>
                    <div class="col-md-4">
                        <span class="d-block text-muted small text-uppercase tracking-wide fw-bold mb-2">Services Used</span>
                        <span class="fs-6 fw-semibold text-primary"><?= str_replace(',', '<br>', \Core\Helpers::escape($case['services_used'])) ?></span>
                    </div>
                </div>
            </div>

            <!-- Challenge & Solution blocks -->
            <div class="row g-5 mb-5 pb-4 border-bottom">
                <div class="col-md-6">
                    <h3 class="fw-bold mb-3 d-flex align-items-center"><i class="bi bi-exclamation-triangle text-warning me-2 fs-2"></i> The Challenge</h3>
                    <div class="text-muted lh-lg fs-5">
                        <?= $case['challenge'] ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <h3 class="fw-bold mb-3 d-flex align-items-center"><i class="bi bi-lightbulb text-primary me-2 fs-2"></i> Our Solution</h3>
                    <div class="text-muted lh-lg fs-5">
                        <?= $case['solution'] ?>
                    </div>
                </div>
            </div>

            <article class="content-formatted fs-5 mb-5">
                <h2 class="fw-bolder mb-4">The Implementation & Results</h2>
                <?= $case['content'] ?>
                
                <h3 class="fw-bolder mt-5 mb-4 text-success">Final Results</h3>
                <div class="bg-success-subtle p-4 p-md-5 rounded-4 border border-success border-opacity-25">
                    <?= $case['results'] ?>
                </div>
            </article>

            <!-- Testimonial if attached -->
            <?php if ($case['testimonial_id']): 
                $test = \Core\Database::getInstance()->fetch("SELECT * FROM " . \Core\Database::getInstance()->t('testimonials') . " WHERE id = ?", [$case['testimonial_id']]);
                if ($test):
            ?>
            <div class="card border-0 shadow-sm bg-light rounded-4 p-4 p-md-5 mb-5 text-center">
                <i class="bi bi-quote fs-1 text-primary opacity-25 mb-3 d-block"></i>
                <p class="fs-4 fst-italic fw-medium text-dark mb-4">"<?= \Core\Helpers::escape($test['content']) ?>"</p>
                <div class="text-center">
                    <strong class="d-block fs-5 text-primary"><?= \Core\Helpers::escape($test['client_name']) ?></strong>
                    <span class="text-muted small"><?= \Core\Helpers::escape($test['designation']) ?>, <?= \Core\Helpers::escape($test['company']) ?></span>
                </div>
            </div>
            <?php endif; endif; ?>

            <div class="bg-primary text-white rounded-4 p-4 p-md-5 text-center shadow">
                <h3 class="fw-bolder mb-3 text-white">Want similar results for your business?</h3>
                <p class="lead opacity-85 mb-4 max-w-700 mx-auto">Contact us today to discuss how our custom local SEO strategies can help you dominate your market.</p>
                <a href="/contact" class="btn btn-warning btn-lg rounded-pill px-5 py-3 fw-bold text-dark shadow-sm">Get Your Proposal</a>
            </div>

        </div>
    </div>
</div>

<style>
    .py-6 { padding-top: 6rem!important; padding-bottom: 6rem!important; }
    .tracking-wide { letter-spacing: 0.05em; }
    .backdrop-blur { backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); }
    @media (min-width: 768px) { .border-end-md { border-right: 1px solid #e2e8f0; } }
    .content-formatted h2 { margin-top: 2.5rem; margin-bottom: 1.25rem; font-weight: 800; color: #0f172a; font-size: 2.25rem; }
    .content-formatted h3 { margin-top: 2rem; margin-bottom: 1rem; font-weight: 700; color: #1e293b; font-size: 1.75rem;}
    .content-formatted p { line-height: 1.85; color: #334155; margin-bottom: 1.5rem; }
    .content-formatted ul, .content-formatted ol { margin-bottom: 1.5rem; padding-left: 2rem; }
    .content-formatted li { margin-bottom: 0.5rem; line-height: 1.85; color: #334155; }
    .content-formatted img { max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1.5rem 0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
