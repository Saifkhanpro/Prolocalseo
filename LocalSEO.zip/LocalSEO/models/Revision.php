<?php
namespace Models;
use Core\Model;

class Revision extends Model {
    protected $table = 'post_revisions';
    protected $fillable = ['post_id', 'author_id', 'title', 'content', 'excerpt', 'reason'];

    public function getByPost(int $postId) {
        return $this->all("post_id = ?", [$postId], "created_at DESC");
    }

    public function deleteOld(int $postId, int $keep = 10) {
        $prefix = $this->db->getTablePrefix();
        $sql = "DELETE FROM {$prefix}post_revisions WHERE post_id = ? AND id NOT IN (
                    SELECT id FROM (
                        SELECT id FROM {$prefix}post_revisions WHERE post_id = ? ORDER BY created_at DESC LIMIT ?
                    ) as tmp
                )";
        return $this->db->execute($sql, [$postId, $postId, $keep]);
    }
}

