<?php
namespace Models;
use Core\Model;

class Media extends Model {
    protected $table = 'media';
    protected $fillable = [
        'file_name', 'original_name', 'file_path', 'file_type', 'mime_type',
        'file_size', 'title', 'alt_text', 'caption', 'description',
        'uploaded_by', 'width', 'height', 'is_optimized', 'optimized_size',
        'optimization_date', 'webp_path'
    ];

    public function deleteWithFiles(int $id): bool {
        $media = $this->find($id);
        if (!$media) return false;

        $paths = [
            $media['file_path'],
            $media['webp_path']
        ];

        // Derived sizes based on filename pattern (thumbnail, medium, large)
        if ($media['file_path']) {
            $info = pathinfo($media['file_path']);
            $dir = $info['dirname'];
            $base = $info['filename'];
            $ext = $info['extension'] ?? 'jpg';
            
            $paths[] = $dir . '/' . $base . '-thumb.' . $ext;
            $paths[] = $dir . '/' . $base . '-medium.' . $ext;
            $paths[] = $dir . '/' . $base . '-large.' . $ext;
        }

        foreach ($paths as $path) {
            if ($path) {
                $fullPath = ROOT_PATH . '/' . ltrim($path, '/');
                if (file_exists($fullPath)) @unlink($fullPath);
            }
        }

        return $this->delete($id) > 0;
    }
}
