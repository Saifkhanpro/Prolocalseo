<?php
namespace Models;
use Core\Model;

class CityPage extends Model {
    protected $table = 'city_pages';
    protected $fillable = [
        'city_name', 'slug', 'state_province', 'population', 'latitude', 'longitude',
        'content', 'featured_image_id', 'status', 'map_embed_code',
        'focus_keyword', 'secondary_keywords', 'seo_title', 'meta_description',
        'robots_index', 'robots_follow', 'robots_advanced', 'canonical_url',
        'readability_score', 'seo_score', 'schema_type', 'schema_data',
        'published_at'
    ];
}
