<?php
namespace Models;
use Core\Model;

class Comment extends Model {
    protected $table = 'comments';
    protected $fillable = [
        'post_id', 'user_id', 'author_name', 'author_email', 'author_ip', 'author_user_agent',
        'content', 'status', 'parent_id', 'is_pinned'
    ];

    public function getPostComments(int $postId, string $status = 'approved'): array {
        $sql = "SELECT c.*, u.avatar_id, u.display_name 
                FROM {$this->table} c
                LEFT JOIN {$this->db->t('users')} u ON c.user_id = u.id
                WHERE c.post_id = ? AND c.status = ? 
                ORDER BY c.created_at ASC";
        $flat = $this->db->fetchAll($sql, [$postId, $status]);
        
        $tree = [];
        $references = [];
        
        foreach ($flat as $comment) {
            $comment['children'] = [];
            $references[$comment['id']] = $comment;
        }

        foreach ($references as $id => &$comment) {
            if ($comment['parent_id'] === null) {
                $tree[] = &$comment;
            } else {
                if (isset($references[$comment['parent_id']])) {
                    $references[$comment['parent_id']]['children'][] = &$comment;
                } else { // Fallback if parent is missing
                    $tree[] = &$comment;
                }
            }
        }

        return $tree;
    }
}
