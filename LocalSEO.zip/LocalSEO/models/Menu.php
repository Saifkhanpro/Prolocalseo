<?php
namespace Models;
use Core\Model;

class Menu extends Model {
    protected $table = 'menus';
    protected $fillable = ['name', 'location', 'status'];

    public function getItems() {
        $prefix = $this->db->getTablePrefix();
        return $this->db->fetchAll("SELECT * FROM {$prefix}menu_items WHERE menu_id = ? ORDER BY order_index ASC", [$this->id]);
    }

    public static function getByLocation(string $location) {
        $model = new self();
        return $model->first("location = ? AND status = 'active'", [$location]);
    }

    public static function getTree(string $location) {
        $menu = self::getByLocation($location);
        if (!$menu) return [];
        
        $items = (new MenuItem())->all("menu_id = ?", [$menu['id']], "order_index ASC");
        return self::buildTree($items);
    }

    private static function buildTree(array $items, int $parentId = 0) {
        $branch = [];
        foreach ($items as $item) {
            if ($item['parent_id'] == $parentId) {
                $children = self::buildTree($items, $item['id']);
                if ($children) {
                    $item['children'] = $children;
                }
                $branch[] = $item;
            }
        }
        return $branch;
    }
}

