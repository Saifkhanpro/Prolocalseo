<?php
namespace Models;
use Core\Model;

class User extends Model {
    protected $table = 'users';
    protected $fillable = [
        'username', 'email', 'password', 'display_name', 'first_name', 'last_name',
        'role', 'avatar_id', 'bio', 'website', 'social_facebook', 'social_twitter',
        'social_linkedin', 'social_instagram', 'is_active', 'seo_role',
        'login_attempts', 'locked_until', 'last_login', 'last_login_ip', 'last_activity'
    ];

    public function findByEmail(string $email): ?array {
        return $this->first("email = ?", [$email]);
    }

    public function findByUsername(string $username): ?array {
        return $this->first("username = ?", [$username]);
    }
}
