<?php
namespace Models;
use Core\Model;

class Post extends Model {
    protected $table = 'posts';
    protected $fillable = [
        'author_id', 'title', 'slug', 'content', 'excerpt', 'status', 'post_type',
        'visibility', 'password', 'featured_image_id', 'comment_status', 'ping_status',
        'focus_keyword', 'secondary_keywords', 'seo_title', 'meta_description',
        'robots_index', 'robots_follow', 'robots_advanced', 'canonical_url', 'primary_category_id',
        'readability_score', 'seo_score', 'schema_type', 'schema_data',
        'published_at'
    ];

    public function getWithAuthor(int $id): ?array {
        $sql = "SELECT p.*, u.display_name, u.avatar_id, u.bio, m.file_path as featured_image
                FROM {$this->table} p
                LEFT JOIN {$this->db->t('users')} u ON p.author_id = u.id
                LEFT JOIN {$this->db->t('media')} m ON p.featured_image_id = m.id
                WHERE p.id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    public function getCategories(int $postId): array {
        $sql = "SELECT c.* FROM {$this->db->t('categories')} c
                JOIN {$this->db->t('post_categories')} pc ON c.id = pc.category_id
                WHERE pc.post_id = ? ORDER BY c.name ASC";
        return $this->db->fetchAll($sql, [$postId]);
    }

    public function syncCategories(int $postId, array $categoryIds): void {
        $t = $this->db->t('post_categories');
        $this->db->delete($t, "post_id = ?", [$postId]);
        foreach ($categoryIds as $catId) {
            $this->db->insert($t, ['post_id' => $postId, 'category_id' => $catId]);
        }
    }

    public function getTags(int $postId): array {
        $sql = "SELECT t.* FROM {$this->db->t('tags')} t
                JOIN {$this->db->t('post_tags')} pt ON t.id = pt.tag_id
                WHERE pt.post_id = ? ORDER BY t.name ASC";
        return $this->db->fetchAll($sql, [$postId]);
    }

    public function syncTags(int $postId, array $tagIds): void {
        $t = $this->db->t('post_tags');
        $this->db->delete($t, "post_id = ?", [$postId]);
        foreach ($tagIds as $tagId) {
            $this->db->insert($t, ['post_id' => $postId, 'tag_id' => $tagId]);
        }
    }
}
