<?php
namespace Models;
use Core\Model;

class Testimonial extends Model {
    protected $table = 'testimonials';
    protected $fillable = [
        'client_name', 'designation', 'company', 'content', 'rating',
        'avatar_id', 'status', 'order_index', 'source', 'source_url'
    ];
}
