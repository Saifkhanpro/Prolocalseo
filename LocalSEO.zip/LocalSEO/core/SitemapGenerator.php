<?php
namespace Core;

class SitemapGenerator {
    private $db;
    private $settings;
    private $baseUrl;
    private $cacheDir;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->settings = $GLOBALS['settings'] ?? [];
        $this->baseUrl = rtrim($this->settings['site_url'] ?? APP_URL, '/');
        $this->cacheDir = CACHE_PATH . '/sitemaps';
        if (!is_dir($this->cacheDir)) @mkdir($this->cacheDir, 0755, true);
    }

    public function generateIndex(): string {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        $types = ['posts', 'pages', 'services', 'cities', 'categories', 'case_studies', 'images'];
        foreach ($types as $type) {
            if ($this->settings["sitemap_{$type}"] ?? '1' === '1') {
                $xml .= "  <sitemap>\n";
                $xml .= "    <loc>{$this->baseUrl}/" . str_replace('_', '-', $type) . "-sitemap.xml</loc>\n";
                $xml .= "    <lastmod>" . date('c') . "</lastmod>\n";
                $xml .= "  </sitemap>\n";
            }
        }
        
        $xml .= '</sitemapindex>';
        file_put_contents($this->cacheDir . '/index.xml', $xml);
        return $xml;
    }

    public function generatePosts(): string {
        $urls = $this->getDbUrls('posts', 'post');
        return $this->buildXml($urls, 'posts');
    }

    public function generatePages(): string {
        $urls = $this->getDbUrls('pages', 'page');
        $urls = array_merge([['loc' => $this->baseUrl . '/', 'lastmod' => date('c'), 'changefreq' => 'daily', 'priority' => '1.0']], $urls);
        return $this->buildXml($urls, 'pages');
    }

    public function generateServices(): string {
        return $this->buildXml($this->getDbUrls('services', 'service'), 'services');
    }

    public function generateCities(): string {
        return $this->buildXml($this->getDbUrls('city_pages', 'city'), 'cities');
    }

    public function generateCategories(): string {
        $urls = [];
        $cats = $this->db->fetchAll("SELECT slug, updated_at FROM {$this->db->t('categories')} WHERE robots_index = 'index'");
        foreach ($cats as $c) {
            $urls[] = [
                'loc' => $this->baseUrl . '/category/' . $c['slug'],
                'lastmod' => date('c', strtotime($c['updated_at'])),
                'changefreq' => 'weekly',
                'priority' => '0.6'
            ];
        }
        return $this->buildXml($urls, 'categories');
    }

    public function generateCaseStudies(): string {
        return $this->buildXml($this->getDbUrls('case_studies', 'case_study'), 'case_studies');
    }

    public function generateImages(): string {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
        
        $media = $this->db->fetchAll("SELECT m.file_path, m.title, m.alt_text, p.slug as post_slug FROM {$this->db->t('media')} m LEFT JOIN {$this->db->t('posts')} p ON m.id = p.featured_image_id WHERE m.file_type = 'image' AND p.status = 'published'");
        
        $grouped = [];
        foreach ($media as $m) {
            if (!$m['post_slug']) continue;
            $url = $this->baseUrl . '/blog/' . $m['post_slug'];
            if (!isset($grouped[$url])) $grouped[$url] = [];
            $grouped[$url][] = $m;
        }

        foreach ($grouped as $url => $images) {
            $xml .= "  <url>\n";
            $xml .= "    <loc>{$url}</loc>\n";
            foreach ($images as $img) {
                $xml .= "    <image:image>\n";
                $xml .= "      <image:loc>{$this->baseUrl}/" . ltrim($img['file_path'], '/') . "</image:loc>\n";
                if ($img['title']) $xml .= "      <image:title><![CDATA[" . htmlspecialchars($img['title']) . "]]></image:title>\n";
                if ($img['alt_text']) $xml .= "      <image:caption><![CDATA[" . htmlspecialchars($img['alt_text']) . "]]></image:caption>\n";
                $xml .= "    </image:image>\n";
            }
            $xml .= "  </url>\n";
        }
        
        $xml .= '</urlset>';
        file_put_contents($this->cacheDir . '/images.xml', $xml);
        return $xml;
    }

    private function getDbUrls(string $table, string $type): array {
        $urls = [];
        $t = $this->db->t($table);
        $rows = $this->db->fetchAll("SELECT slug, updated_at FROM {$t} WHERE status = 'published' AND robots_index = 'index'");
        $prefix = ['post' => '/blog/', 'page' => '/', 'service' => '/services/', 'city' => '/local-seo/', 'case_study' => '/case-studies/'][$type];
        $priority = ['post' => '0.8', 'page' => '0.8', 'service' => '0.9', 'city' => '0.9', 'case_study' => '0.7'][$type];
        
        foreach ($rows as $r) {
            $urls[] = [
                'loc' => $this->baseUrl . $prefix . ltrim($r['slug'], '/'),
                'lastmod' => date('c', strtotime($r['updated_at'])),
                'changefreq' => 'weekly',
                'priority' => $priority
            ];
        }
        return $urls;
    }

    private function buildXml(array $urls, string $type): string {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as $url) {
            $xml .= "  <url>\n";
            $xml .= "    <loc>{$url['loc']}</loc>\n";
            $xml .= "    <lastmod>{$url['lastmod']}</lastmod>\n";
            $xml .= "    <changefreq>{$url['changefreq']}</changefreq>\n";
            $xml .= "    <priority>{$url['priority']}</priority>\n";
            $xml .= "  </url>\n";
        }
        $xml .= '</urlset>';
        file_put_contents($this->cacheDir . "/{$type}.xml", $xml);
        return $xml;
    }

    public function generateAll(): void {
        $this->generatePosts();
        $this->generatePages();
        $this->generateServices();
        $this->generateCities();
        $this->generateCategories();
        $this->generateCaseStudies();
        $this->generateImages();
        $this->generateIndex();
        $this->db->update($this->db->t('settings'), ['setting_value' => date('Y-m-d H:i:s')], "setting_key = 'sitemap_last_generated'");
    }

    public function getCached(string $type): ?string {
        $file = $this->cacheDir . "/{$type}.xml";
        return file_exists($file) ? file_get_contents($file) : null;
    }
}
