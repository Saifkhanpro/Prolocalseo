<?php
namespace Core;

class CriticalCSS {
    private $cachePath;
    public function __construct() {
        $this->cachePath = CACHE_PATH . '/critical-css';
        if (!is_dir($this->cachePath)) @mkdir($this->cachePath, 0755, true);
    }
    public function get(string $template): string {
        $file = $this->cachePath . '/' . md5($template) . '.css';
        if (file_exists($file)) return file_get_contents($file);
        return '';
    }
    public function generate(string $template, string $cssContent): void {
        $critical = $this->extractCritical($cssContent);
        $file = $this->cachePath . '/' . md5($template) . '.css';
        file_put_contents($file, $critical, LOCK_EX);
    }
    private function extractCritical(string $css): string {
        $critical = '';
        $patterns = ['/:root\s*\{[^}]+\}/s','/body\s*\{[^}]+\}/s','/\.header[^{]*\{[^}]+\}/s','/\.hero[^{]*\{[^}]+\}/s','/\.nav[^{]*\{[^}]+\}/s','/h[1-6]\s*\{[^}]+\}/s','/\.container[^{]*\{[^}]+\}/s','/\.btn[^{]*\{[^}]+\}/s'];
        foreach ($patterns as $p) { if (preg_match_all($p, $css, $m)) $critical .= implode("\n", $m[0]) . "\n"; }
        return $critical;
    }
    public function clear(): void {
        foreach (glob($this->cachePath . '/*.css') as $f) @unlink($f);
    }
}
