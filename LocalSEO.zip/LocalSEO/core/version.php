<?php
// LocalSEO.pk — Version Information
define('LSEO_VERSION', '1.0.0');
define('LSEO_VERSION_ID', 10000);
define('LSEO_MIN_PHP', '8.0.0');
define('LSEO_MIN_MYSQL', '5.7.0');
define('LSEO_DB_VERSION', '1.0.0');
define('LSEO_BUILD_DATE', '2026-03-12');
