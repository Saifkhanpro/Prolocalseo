<?php
namespace Core;

class PageCache extends Cache {
    public function __construct() {
        parent::__construct('pages');
    }

    public function get(string $url, $default = null) {
        if (!$this->enabled) return $default;
        $isMobile = Helpers::isMobile();
        $key = $this->buildKey($url, $isMobile);
        return parent::get($key, $default);
    }

    public function set(string $url, $content, int $ttl = 0): bool {
        if (!$this->enabled) return false;
        $isMobile = Helpers::isMobile();
        $key = $this->buildKey($url, $isMobile);
        $settings = $GLOBALS['settings'] ?? [];
        if ($ttl === 0) {
            if ($url === '/' || $url === '') $ttl = (int)($settings['cache_ttl_homepage'] ?? 3600);
            elseif (strpos($url, '/blog') === 0) $ttl = (int)($settings['cache_ttl_post'] ?? 86400);
            elseif (strpos($url, '/services') === 0) $ttl = (int)($settings['cache_ttl_service'] ?? 86400);
            elseif (strpos($url, '/contact') === 0) $ttl = (int)($settings['cache_ttl_contact'] ?? 604800);
            else $ttl = (int)($settings['cache_ttl_page'] ?? 86400);
        }
        return parent::set($key, $content, $ttl);
    }

    private function buildKey(string $url, bool $mobile): string {
        $sep = ($GLOBALS['settings']['cache_separate_mobile'] ?? '1') === '1';
        return ($sep && $mobile ? 'mobile:' : 'desktop:') . $url;
    }
}
