<?php
namespace Core;

class UpdateManager {
    public function install(array $updateData): array {
        // 1. Create a backup if required
        if (($GLOBALS['settings']['update_auto_backup'] ?? '1') === '1' || !empty($updateData['requires_backup'])) {
            $backupMgr = new BackupManager();
            $backupResult = $backupMgr->createFullBackup();
            if (!$backupResult['success']) {
                return ['success' => false, 'error' => 'Failed to create pre-update backup: ' . $backupResult['error']];
            }
        }

        // 2. Download package
        $tempFile = TEMP_PATH . '/update-' . time() . '.zip';
        $ch = curl_init($updateData['download_url']);
        $fp = fopen($tempFile, 'w+');
        curl_setopt_array($ch, [
            CURLOPT_FILE => $fp,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_FOLLOWLOCATION => true
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode !== 200) {
            @unlink($tempFile);
            return ['success' => false, 'error' => 'Failed to download update package.'];
        }

        // 3. Verify checksum if provided
        if (!empty($updateData['checksum'])) {
            if (hash_file('sha256', $tempFile) !== $updateData['checksum']) {
                @unlink($tempFile);
                return ['success' => false, 'error' => 'Checksum verification failed. Package may be corrupted.'];
            }
        }

        // 4. Extract and overwrite files
        $zip = new \ZipArchive();
        if ($zip->open($tempFile) === true) {
            // Protected files/directories that shouldn't be overwritten directly via extractTo
            // You can implement custom extraction logic here if needed.
            // For now, extract everything to ROOT_PATH.
            if (!$zip->extractTo(ROOT_PATH)) {
                $zip->close();
                @unlink($tempFile);
                return ['success' => false, 'error' => 'Failed to extract update package. Check permissions.'];
            }
            $zip->close();
        } else {
            @unlink($tempFile);
            return ['success' => false, 'error' => 'Failed to open update zip.'];
        }

        @unlink($tempFile);

        // 5. Run DB migrations if provided
        if (!empty($updateData['requires_database_update']) && !empty($updateData['database_update_script'])) {
            try {
                $db = Database::getInstance();
                $queries = explode(';', $updateData['database_update_script']);
                foreach ($queries as $q) {
                    $q = trim($q);
                    if ($q) $db->query($q);
                }
            } catch (\Exception $e) {
                // Log and continue, database script might have failed harmlessly
            }
        }

        // 6. Clear caches
        $m = new CacheMonitor();
        $m->clearAll();

        // 7. Log history
        $db = Database::getInstance();
        $db->insert($db->t('update_history'), [
            'from_version' => defined('APP_VERSION') ? APP_VERSION : 'unknown',
            'to_version' => $updateData['version'],
            'update_type' => $updateData['update_type'],
            'status' => 'completed',
            'completed_at' => date('Y-m-d H:i:s'),
            'updated_by' => $_SESSION['user_id'] ?? null,
            'ip_address' => Helpers::getClientIP()
        ]);

        return ['success' => true];
    }
}
