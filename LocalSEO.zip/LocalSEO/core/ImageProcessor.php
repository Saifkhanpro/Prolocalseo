<?php
namespace Core;

class ImageProcessor {
    private $quality;
    private $maxWidth;

    public function __construct() {
        $this->quality = (int) Helpers::setting('image_compression', 85);
        $this->maxWidth = (int) Helpers::setting('image_max_width', 1920);
    }

    public function process(string $sourcePath, string $destDir): array {
        $info = getimagesize($sourcePath);
        if (!$info) throw new \Exception('Invalid image file.');
        $mime = $info['mime'];
        $origW = $info[0];
        $origH = $info[1];
        $image = $this->createFromFile($sourcePath, $mime);
        if (!$image) throw new \Exception('Cannot process image.');

        // Strip metadata
        if (Helpers::setting('image_strip_metadata', '1') === '1') {
            // GD strips metadata by default on re-save
        }

        // Resize if too large
        if ($origW > $this->maxWidth) {
            $ratio = $this->maxWidth / $origW;
            $newH = (int)($origH * $ratio);
            $image = $this->resize($image, $origW, $origH, $this->maxWidth, $newH);
            $origW = $this->maxWidth;
            $origH = $newH;
        }

        $baseName = pathinfo($sourcePath, PATHINFO_FILENAME);
        $baseName = preg_replace('/[^a-z0-9_-]/', '-', strtolower($baseName));
        $ext = $this->getExtension($mime);
        $fileName = $baseName . '-' . time() . '.' . $ext;

        $result = ['file_name' => $fileName, 'width' => $origW, 'height' => $origH];

        // Save main image
        $mainPath = $destDir . '/' . $fileName;
        $this->saveImage($image, $mainPath, $mime);
        $result['file_path'] = 'uploads/images/' . $fileName;
        $result['file_size'] = filesize($mainPath);

        // Thumbnail
        $thumbW = (int) Helpers::setting('thumbnail_width', 300);
        $thumbH = (int) Helpers::setting('thumbnail_height', 300);
        $thumb = $this->cropResize($image, $origW, $origH, $thumbW, $thumbH);
        $thumbName = $baseName . '-' . time() . '-thumb.' . $ext;
        $thumbPath = $destDir . '/' . $thumbName;
        $this->saveImage($thumb, $thumbPath, $mime);
        imagedestroy($thumb);
        $result['thumbnail_path'] = 'uploads/images/' . $thumbName;

        // Medium
        $medW = (int) Helpers::setting('medium_width', 768);
        if ($origW > $medW) {
            $ratio = $medW / $origW;
            $medH = (int)($origH * $ratio);
            $med = $this->resize($image, $origW, $origH, $medW, $medH);
            $medName = $baseName . '-' . time() . '-medium.' . $ext;
            $this->saveImage($med, $destDir . '/' . $medName, $mime);
            imagedestroy($med);
            $result['medium_path'] = 'uploads/images/' . $medName;
        }

        // Large
        $lgW = (int) Helpers::setting('large_width', 1200);
        if ($origW > $lgW) {
            $ratio = $lgW / $origW;
            $lgH = (int)($origH * $ratio);
            $lg = $this->resize($image, $origW, $origH, $lgW, $lgH);
            $lgName = $baseName . '-' . time() . '-large.' . $ext;
            $this->saveImage($lg, $destDir . '/' . $lgName, $mime);
            imagedestroy($lg);
            $result['large_path'] = 'uploads/images/' . $lgName;
        }

        // WebP conversion
        if (Helpers::setting('auto_webp_conversion', '1') === '1' && function_exists('imagewebp') && $mime !== 'image/webp') {
            $webpName = $baseName . '-' . time() . '.webp';
            $webpQuality = (int) Helpers::setting('image_webp_quality', 80);
            imagewebp($image, $destDir . '/' . $webpName, $webpQuality);
            $result['webp_path'] = 'uploads/images/' . $webpName;
        }

        imagedestroy($image);
        return $result;
    }

    private function createFromFile(string $path, string $mime) {
        switch ($mime) {
            case 'image/jpeg': case 'image/jpg': return imagecreatefromjpeg($path);
            case 'image/png': return imagecreatefrompng($path);
            case 'image/gif': return imagecreatefromgif($path);
            case 'image/webp': return function_exists('imagecreatefromwebp') ? imagecreatefromwebp($path) : null;
            case 'image/bmp': return function_exists('imagecreatefrombmp') ? imagecreatefrombmp($path) : null;
            default: return null;
        }
    }

    private function resize($src, int $srcW, int $srcH, int $dstW, int $dstH) {
        $dst = imagecreatetruecolor($dstW, $dstH);
        $this->preserveTransparency($dst, $src);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $dstW, $dstH, $srcW, $srcH);
        return $dst;
    }

    private function cropResize($src, int $srcW, int $srcH, int $dstW, int $dstH) {
        $srcRatio = $srcW / $srcH;
        $dstRatio = $dstW / $dstH;
        if ($srcRatio > $dstRatio) {
            $cropW = (int)($srcH * $dstRatio);
            $cropH = $srcH;
            $cropX = (int)(($srcW - $cropW) / 2);
            $cropY = 0;
        } else {
            $cropW = $srcW;
            $cropH = (int)($srcW / $dstRatio);
            $cropX = 0;
            $cropY = (int)(($srcH - $cropH) / 2);
        }
        $dst = imagecreatetruecolor($dstW, $dstH);
        $this->preserveTransparency($dst, $src);
        imagecopyresampled($dst, $src, 0, 0, $cropX, $cropY, $dstW, $dstH, $cropW, $cropH);
        return $dst;
    }

    private function preserveTransparency($dst, $src): void {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefill($dst, 0, 0, $transparent);
        imagealphablending($dst, true);
    }

    private function saveImage($image, string $path, string $mime): void {
        switch ($mime) {
            case 'image/jpeg': case 'image/jpg': imagejpeg($image, $path, $this->quality); break;
            case 'image/png': imagepng($image, $path, min(9, (int)(9 - ($this->quality / 11)))); break;
            case 'image/gif': imagegif($image, $path); break;
            case 'image/webp': imagewebp($image, $path, $this->quality); break;
            case 'image/bmp': imagebmp($image, $path); break;
        }
    }

    private function getExtension(string $mime): string {
        $map = ['image/jpeg'=>'jpg','image/jpg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','image/bmp'=>'bmp'];
        return $map[$mime] ?? 'jpg';
    }
}
