<?php
namespace Core;

class EnvironmentManager {
    public function getSystemInfo(): array {
        return [
            'php_version' => PHP_VERSION,
            'mysql_version' => $this->getDbVersion(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? ROOT_PATH,
            'max_execution_time' => ini_get('max_execution_time'),
            'memory_limit' => ini_get('memory_limit'),
            'post_max_size' => ini_get('post_max_size'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'extensions' => get_loaded_extensions()
        ];
    }

    public function optimizeDatabase(): array {
        try {
            $db = Database::getInstance();
            $tables = $db->fetchAll("SHOW TABLES");
            $results = [];
            foreach ($tables as $tRow) {
                $table = array_values($tRow)[0];
                $res = $db->fetch("OPTIMIZE TABLE `{$table}`");
                $results[$table] = $res['Msg_text'] ?? 'Optimized';
            }
            return ['success' => true, 'data' => $results];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function repairDatabase(): array {
        try {
            $db = Database::getInstance();
            $tables = $db->fetchAll("SHOW TABLES");
            $results = [];
            foreach ($tables as $tRow) {
                $table = array_values($tRow)[0];
                $res = $db->fetch("REPAIR TABLE `{$table}`");
                $results[$table] = $res['Msg_text'] ?? 'Repaired';
            }
            return ['success' => true, 'data' => $results];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    private function getDbVersion(): string {
        try {
            return Database::getInstance()->fetchColumn("SELECT VERSION()");
        } catch (\Exception $e) {
            return 'Unknown';
        }
    }
}
