<?php
namespace Core;

class HTMLOptimizer {
    public function optimize(string $html): string {
        $settings = $GLOBALS['settings'] ?? [];
        if (($settings['cache_minify_html'] ?? '0') === '1') {
            $html = $this->minify($html);
        }
        if (($settings['cache_lazy_load'] ?? '1') === '1') {
            $html = $this->addLazyLoad($html);
        }
        if (($settings['speed_defer_js'] ?? '1') === '1') {
            $html = $this->deferJS($html);
        }
        if (($settings['speed_remove_query_strings'] ?? '1') === '1') {
            $html = $this->removeQueryStrings($html);
        }
        return $html;
    }

    private function minify(string $html): string {
        $html = preg_replace('/<!--(?!\[if).*?-->/s', '', $html);
        $html = preg_replace('/\s+/', ' ', $html);
        $html = str_replace(['> <'], ['><'], $html);
        return trim($html);
    }

    private function addLazyLoad(string $html): string {
        return preg_replace('/<img(?![^>]*loading=)([^>]*?)(?<!\/)>/i', '<img loading="lazy"$1>', $html);
    }

    private function deferJS(string $html): string {
        return preg_replace('/<script(?![^>]*(?:defer|async|type=["\']module))([^>]*src=[^>]*)>/i', '<script defer$1>', $html);
    }

    private function removeQueryStrings(string $html): string {
        return preg_replace('/(<(?:script|link)[^>]+(?:src|href)=["\'][^"\']*)\?ver=[^"\']*(["\'])/i', '$1$2', $html);
    }
}
