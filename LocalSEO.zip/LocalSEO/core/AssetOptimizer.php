<?php
namespace Core;

class AssetOptimizer {
    private $cssDir;
    private $jsDir;

    public function __construct() {
        $this->cssDir = CACHE_PATH . '/assets/css';
        $this->jsDir = CACHE_PATH . '/assets/js';
        if (!is_dir($this->cssDir)) @mkdir($this->cssDir, 0755, true);
        if (!is_dir($this->jsDir)) @mkdir($this->jsDir, 0755, true);
    }

    public function minifyCSS(string $css): string {
        $css = preg_replace('!/\*.*?\*/!s', '', $css);
        $css = preg_replace('/\s+/', ' ', $css);
        $css = str_replace([' { ',' } ','; ',': ',' , '], ['{','}',';',':',','], $css);
        $css = preg_replace('/;\s*}/', '}', $css);
        return trim($css);
    }

    public function minifyJS(string $js): string {
        $js = preg_replace('!/\*.*?\*/!s', '', $js);
        $js = preg_replace('/(?<!:)\/\/[^\n]*/', '', $js);
        $js = preg_replace('/\s+/', ' ', $js);
        return trim($js);
    }

    public function getCombinedCSS(array $files): string {
        $hash = md5(implode('|', $files) . filemtime(ASSET_PATH . '/css/style.css'));
        $cachedFile = $this->cssDir . '/' . $hash . '.css';
        if (file_exists($cachedFile)) return '/cache/assets/css/' . $hash . '.css';

        $combined = '';
        foreach ($files as $file) {
            $path = ROOT_PATH . '/' . ltrim($file, '/');
            if (file_exists($path)) $combined .= file_get_contents($path) . "\n";
        }

        if (Helpers::setting('cache_minify_css', '1') === '1') {
            $combined = $this->minifyCSS($combined);
        }
        file_put_contents($cachedFile, $combined, LOCK_EX);
        return '/cache/assets/css/' . $hash . '.css';
    }

    public function getCombinedJS(array $files): string {
        $hash = md5(implode('|', $files) . (file_exists(ASSET_PATH . '/js/main.js') ? filemtime(ASSET_PATH . '/js/main.js') : ''));
        $cachedFile = $this->jsDir . '/' . $hash . '.js';
        if (file_exists($cachedFile)) return '/cache/assets/js/' . $hash . '.js';

        $combined = '';
        foreach ($files as $file) {
            $path = ROOT_PATH . '/' . ltrim($file, '/');
            if (file_exists($path)) $combined .= file_get_contents($path) . ";\n";
        }

        if (Helpers::setting('cache_minify_js', '1') === '1') {
            $combined = $this->minifyJS($combined);
        }
        file_put_contents($cachedFile, $combined, LOCK_EX);
        return '/cache/assets/js/' . $hash . '.js';
    }

    public function clear(): int {
        $count = 0;
        foreach ([$this->cssDir, $this->jsDir] as $dir) {
            if (!is_dir($dir)) continue;
            foreach (glob($dir . '/*') as $f) { if (is_file($f)) { @unlink($f); $count++; } }
        }
        return $count;
    }
}
