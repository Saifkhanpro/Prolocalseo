<?php
namespace Core;

class QueryCache extends Cache {
    public function __construct() { parent::__construct('queries'); }
    public function query(string $sql, array $params = [], int $ttl = 300) {
        $key = 'q:' . md5($sql . serialize($params));
        $cached = $this->get($key);
        if ($cached !== null) return $cached;
        $db = Database::getInstance();
        $result = $db->fetchAll($sql, $params);
        $this->set($key, $result, $ttl);
        return $result;
    }
    public function queryOne(string $sql, array $params = [], int $ttl = 300) {
        $key = 'q1:' . md5($sql . serialize($params));
        $cached = $this->get($key);
        if ($cached !== null) return $cached;
        $db = Database::getInstance();
        $result = $db->fetch($sql, $params);
        $this->set($key, $result, $ttl);
        return $result;
    }
    public function invalidateTable(string $table): int {
        return $this->clear();
    }
}
