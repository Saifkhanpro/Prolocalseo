<?php
namespace Core;

class ImageOptimizer {
    public function optimizeSingle(int $mediaId): array {
        $db = Database::getInstance();
        $media = $db->fetch("SELECT * FROM {$db->t('media')} WHERE id = ? AND file_type = 'image'", [$mediaId]);
        if (!$media) return ['success' => false, 'error' => 'Image not found.'];

        $filePath = ROOT_PATH . '/' . $media['file_path'];
        if (!file_exists($filePath)) return ['success' => false, 'error' => 'File missing.'];

        $originalSize = filesize($filePath);
        $info = @getimagesize($filePath);
        if (!$info) return ['success' => false, 'error' => 'Invalid image.'];

        $quality = (int) Helpers::setting('image_quality_level', 82);
        $image = $this->loadImage($filePath, $info['mime']);
        if (!$image) return ['success' => false, 'error' => 'Cannot load image.'];

        $maxDim = (int) Helpers::setting('image_max_dimension', 2560);
        $w = $info[0]; $h = $info[1];
        if ($w > $maxDim || $h > $maxDim) {
            $ratio = min($maxDim / $w, $maxDim / $h);
            $nw = (int)($w * $ratio); $nh = (int)($h * $ratio);
            $resized = imagecreatetruecolor($nw, $nh);
            imagealphablending($resized, false); imagesavealpha($resized, true);
            imagecopyresampled($resized, $image, 0, 0, 0, 0, $nw, $nh, $w, $h);
            imagedestroy($image);
            $image = $resized;
        }

        $this->saveOptimized($image, $filePath, $info['mime'], $quality);
        imagedestroy($image);

        $newSize = filesize($filePath);
        $saved = $originalSize - $newSize;
        $percent = $originalSize > 0 ? round(($saved / $originalSize) * 100, 1) : 0;

        $db->update($db->t('media'), [
            'is_optimized' => 1,
            'optimized_size' => $newSize,
            'optimization_date' => date('Y-m-d H:i:s'),
        ], 'id = ?', [$mediaId]);

        // WebP conversion
        if (Helpers::setting('image_convert_to_webp', '1') === '1' && function_exists('imagewebp') && $info['mime'] !== 'image/webp') {
            $webpPath = preg_replace('/\.[^.]+$/', '.webp', $filePath);
            $img2 = $this->loadImage($filePath, $info['mime']);
            if ($img2) {
                imagewebp($img2, $webpPath, (int) Helpers::setting('image_webp_quality', 80));
                imagedestroy($img2);
                $db->update($db->t('media'), ['webp_path' => str_replace(ROOT_PATH . '/', '', $webpPath)], 'id = ?', [$mediaId]);
            }
        }

        return ['success' => true, 'original_size' => $originalSize, 'new_size' => $newSize, 'saved' => $saved, 'percent' => $percent];
    }

    public function optimizeBulk(int $batch = 20): array {
        $db = Database::getInstance();
        $images = $db->fetchAll("SELECT id FROM {$db->t('media')} WHERE file_type = 'image' AND is_optimized = 0 LIMIT ?", [$batch]);
        $results = ['total' => count($images), 'success' => 0, 'failed' => 0, 'saved' => 0];
        foreach ($images as $img) {
            $r = $this->optimizeSingle($img['id']);
            if ($r['success']) { $results['success']++; $results['saved'] += $r['saved'] ?? 0; }
            else { $results['failed']++; }
        }
        return $results;
    }

    private function loadImage(string $path, string $mime) {
        switch ($mime) {
            case 'image/jpeg': case 'image/jpg': return @imagecreatefromjpeg($path);
            case 'image/png': return @imagecreatefrompng($path);
            case 'image/gif': return @imagecreatefromgif($path);
            case 'image/webp': return function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : null;
            default: return null;
        }
    }

    private function saveOptimized($image, string $path, string $mime, int $quality): void {
        switch ($mime) {
            case 'image/jpeg': case 'image/jpg': imagejpeg($image, $path, $quality); break;
            case 'image/png': imagepng($image, $path, min(9, (int)(9 - ($quality / 11)))); break;
            case 'image/gif': imagegif($image, $path); break;
            case 'image/webp': imagewebp($image, $path, $quality); break;
        }
    }
}
