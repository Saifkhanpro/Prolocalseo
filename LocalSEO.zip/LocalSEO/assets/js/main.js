/**
 * LocalSEO.pk — Premium Frontend JS
 * Version: 1.0.0
 */

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // 1. Header scroll effect
    const header = document.querySelector('.site-header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // 2. Dynamic Table of Contents Generator
    const tocContainer = document.getElementById('toc-content');
    if (tocContainer) {
        const article = document.querySelector('.post-content');
        if (article) {
            const headings = article.querySelectorAll('h2, h3');
            if (headings.length > 0) {
                const ul = document.createElement('ul');
                ul.className = 'nav flex-column';
                
                headings.forEach((heading, index) => {
                    const id = 'heading-' + index;
                    heading.id = id;
                    
                    const li = document.createElement('li');
                    li.className = 'nav-item';
                    
                    const a = document.createElement('a');
                    a.className = 'nav-link' + (index === 0 ? ' active' : '');
                    a.href = '#' + id;
                    a.textContent = heading.textContent;
                    
                    if (heading.tagName === 'H3') li.style.paddingLeft = '15px';
                    
                    li.appendChild(a);
                    ul.appendChild(li);
                });
                
                tocContainer.appendChild(ul);
            } else {
                document.querySelector('.toc-widget')?.remove();
            }
        }
    }

    // 3. Smooth scrolling for internal links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

    // 4. Cookie Notice
    const cookieNotice = document.getElementById('cookieNotice');
    if (cookieNotice && !localStorage.getItem('cookiesAccepted')) {
        setTimeout(() => {
            cookieNotice.style.display = 'block';
            cookieNotice.classList.add('animate-fade-up');
        }, 2000);
    }

    window.acceptCookies = function() {
        localStorage.setItem('cookiesAccepted', 'true');
        cookieNotice.style.display = 'none';
    };

    // 5. Initialize Tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

});
