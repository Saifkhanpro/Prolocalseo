/**
 * LocalSEO.pk — Admin Panel Logic
 */

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // 1. Sidebar Toggler
    const toggler = document.querySelector('.admin-topbar .btn-light');
    const sidebar = document.querySelector('.admin-sidebar');
    if (toggler && sidebar) {
        toggler.addEventListener('click', () => {
            sidebar.classList.toggle('d-none');
        });
    }

    // 2. SEO Score Calculator (Basic Simulation)
    const titleInput = document.querySelector('input[name="seo_title"]');
    const descInput = document.querySelector('textarea[name="meta_description"]');
    const scoreBadge = document.getElementById('global-seo-score');

    function updateSeoScores() {
        if (!titleInput || !descInput || !scoreBadge) return;
        
        let score = 0;
        const titleLen = titleInput.value.length;
        const descLen = descInput.value.length;

        if (titleLen >= 30 && titleLen <= 60) score += 40;
        else if (titleLen > 0) score += 20;

        if (descLen >= 120 && descLen <= 160) score += 40;
        else if (descLen > 0) score += 20;

        scoreBadge.textContent = `Score: ${score}/100`;
        scoreBadge.className = `seo-score-badge badge p-2 px-3 rounded-pill ${score > 70 ? 'bg-success' : (score > 40 ? 'bg-warning' : 'bg-danger')}`;
        
        // Update progress bars
        const titleBar = document.getElementById('title-progress');
        if (titleBar) titleBar.style.width = Math.min(100, (titleLen / 60) * 100) + '%';
        
        const descBar = document.getElementById('desc-progress');
        if (descBar) descBar.style.width = Math.min(100, (descLen / 160) * 100) + '%';
    }

    if (titleInput) {
        titleInput.addEventListener('input', updateSeoScores);
        descInput.addEventListener('input', updateSeoScores);
        updateSeoScores(); // Initial run
    }

    // 3. Google Preview Real-time update
    const previewTitle = document.getElementById('preview-title');
    const previewDesc = document.getElementById('preview-desc');

    if (previewTitle && titleInput) {
        titleInput.addEventListener('input', (e) => {
            previewTitle.textContent = e.target.value || 'Page Title Goes Here';
        });
        descInput.addEventListener('input', (e) => {
            previewDesc.textContent = e.target.value || 'Description preview...';
        });
    }
});
