<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\CaseStudy;

class CaseStudyController extends Controller {
    public function index() {
        $caseModel = new CaseStudy();
        $cases = $caseModel->where("status = 'published'", [], "published_at DESC");

        $data = [
            'cases' => $cases,
            'pageTitle' => 'Local SEO Case Studies & Results | LocalSEO.pk',
            'metaDescription' => 'Explore our local SEO case studies showing how we helped Pakistani businesses dominate their local markets and increase revenue.',
            'canonicalUrl' => APP_URL . '/case-studies'
        ];

        $this->frontendView('case_studies/index', $data);
    }

    public function show(string $slug) {
        $caseModel = new CaseStudy();
        $case = $caseModel->findBySlug($slug);

        if (!$case || $case['status'] !== 'published') {
            http_response_code(404);
            $this->frontendView('404', ['pageTitle' => 'Case Study Not Found']);
            return;
        }

        $data = [
            'case' => $case,
            'pageTitle' => $case['seo_title'] ?: $case['title'] . ' - SEO Case Study',
            'metaDescription' => $case['meta_description'] ?: substr(strip_tags($case['challenge']), 0, 150),
            'canonicalUrl' => $case['canonical_url'] ?: APP_URL . '/case-studies/' . $case['slug'],
            'schema' => json_decode($case['schema_data'] ?? '[]', true),
            'robots' => []
        ];

        if ($case['robots_index'] === 'noindex') $data['robots'][] = 'noindex';
        if ($case['robots_follow'] === 'nofollow') $data['robots'][] = 'nofollow';

        $this->frontendView('case_studies/single', $data);
    }
}
