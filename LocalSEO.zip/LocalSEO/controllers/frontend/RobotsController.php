<?php
namespace Controllers\Frontend;

use Core\Controller;
use Core\Helpers;
use Models\Setting;

class RobotsController extends Controller {
    public function index() {
        // Output Plain Text
        header('Content-Type: text/plain; charset=utf-8');
        
        $settings = new Setting();
        
        // Check if indexing is disabled globally
        $discourage = $settings->get('seo_discourage_search_engines', '0');
        
        if ($discourage === '1') {
            echo "User-agent: *\n";
            echo "Disallow: /\n";
        } else {
            // Custom robots.txt content from settings
            $customRobots = $settings->get('seo_robots_txt', '');
            if (!empty(trim($customRobots))) {
                echo $customRobots;
            } else {
                // Default optimized robots.txt
                echo "User-agent: *\n";
                echo "Disallow: /admin/\n";
                echo "Disallow: /install.php\n";
                echo "Disallow: /*?*\n"; // Disallow query parameters broadly to prevent duplicate content
                echo "Allow: /*?p=*\n";  // Allow pagination
                echo "Allow: /admin/api/auto-meta\n"; // Allow API endpoints necessary occasionally
                
                echo "\n# Block common bad bots\n";
                echo "User-agent: AhrefsBot\n";
                echo "Disallow: /\n";
                echo "User-agent: SemrushBot\n";
                echo "Disallow: /\n";
                echo "User-agent: MJ12bot\n";
                echo "Disallow: /\n";
                
                echo "\nSitemap: " . APP_URL . "/sitemap.xml\n";
            }
        }
        exit;
    }
}
