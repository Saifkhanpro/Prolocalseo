<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\CityPage;

class CityController extends Controller {
    public function index() {
        $cityModel = new CityPage();
        $cities = $cityModel->where("status = 'published'", [], "city_name ASC");

        $data = [
            'cities' => $cities,
            'pageTitle' => 'Local SEO Services by City in Pakistan',
            'metaDescription' => 'Find specialized local SEO services for your city in Pakistan. We help businesses rank higher in local search results.',
            'canonicalUrl' => APP_URL . '/local-seo'
        ];

        $this->frontendView('cities/index', $data);
    }

    public function show(string $slug) {
        $cityModel = new CityPage();
        $city = $cityModel->findBySlug($slug);

        if (!$city || $city['status'] !== 'published') {
            http_response_code(404);
            $this->frontendView('404', ['pageTitle' => 'City Not Found']);
            return;
        }

        $data = [
            'city' => $city,
            'pageTitle' => $city['seo_title'] ?: 'Local SEO Expert in ' . $city['city_name'],
            'metaDescription' => $city['meta_description'],
            'canonicalUrl' => $city['canonical_url'] ?: APP_URL . '/local-seo/' . $city['slug'],
            'schema' => json_decode($city['schema_data'] ?? '[]', true),
            'robots' => []
        ];

        if ($city['robots_index'] === 'noindex') $data['robots'][] = 'noindex';
        if ($city['robots_follow'] === 'nofollow') $data['robots'][] = 'nofollow';

        $this->frontendView('cities/single', $data);
    }
}
