<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Page;
use Models\Service;
use Models\Testimonial;
use Models\CaseStudy;

class HomeController extends Controller {
    public function index() {
        $pageModel = new Page();
        $serviceModel = new Service();
        $testModel = new Testimonial();
        $caseModel = new CaseStudy();

        // Try to load a specific page designated as homepage
        $homePageId = (int)$this->setting('homepage_id', 0);
        $page = null;
        if ($homePageId > 0) {
            $page = $pageModel->find($homePageId);
        }

        // If no specific page is set, we might use a default slug or just fallback data
        if (!$page) {
            $page = $pageModel->findBySlug('home');
        }

        // Services for the homepage grid
        $services = $serviceModel->where("status = 'published'", [], "order_index ASC LIMIT 6");
        
        // Testimonials
        $testimonials = $testModel->where("status = 'published'", [], "order_index ASC LIMIT 3");
        
        // Featured Case Studies
        $caseStudies = $caseModel->where("status = 'published'", [], "published_at DESC LIMIT 3");

        $data = [
            'page' => $page,
            'services' => $services,
            'testimonials' => $testimonials,
            'case_studies' => $caseStudies,
            'pageTitle' => $page['seo_title'] ?? $this->setting('site_title', 'LocalSEO.pk - Top Rated SEO Agency'),
            'metaDescription' => $page['meta_description'] ?? $this->setting('site_description', ''),
            'canonicalUrl' => rtrim(APP_URL, '/'),
            'schema' => json_decode($page['schema_data'] ?? '[]', true)
        ];

        $this->frontendView('home', $data);
    }
}
