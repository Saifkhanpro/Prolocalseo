<?php
namespace Controllers\Frontend;

use Core\Controller;
use Core\Helpers;

class SitemapController extends Controller {
    public function index() {
        // Output XML
        header('Content-Type: application/xml; charset=utf-8');
        
        // Initialize SitemapGenerator
        // Wait, SitemapGenerator is in Core namespace. Let's make sure it's loaded.
        if (class_exists('\Core\SitemapGenerator')) {
            $generator = new \Core\SitemapGenerator();
            
            // Try cache first
            $cached = $generator->getCached('index');
            if ($cached) {
                echo $cached;
                exit;
            }
            
            // Generate fallback if not cached
            echo $generator->generateIndex();
        } else {
            // Basic fallback sitemap
            echo '<?xml version="1.0" encoding="UTF-8"?>';
            echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            echo '  <url>';
            echo '    <loc>' . Helpers::escape(APP_URL) . '/</loc>';
            echo '    <lastmod>' . date('Y-m-d') . '</lastmod>';
            echo '  </url>';
            echo '</urlset>';
        }
        exit;
    }
}
