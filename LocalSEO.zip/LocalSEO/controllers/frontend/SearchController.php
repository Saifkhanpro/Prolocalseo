<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Post;
use Models\Page;
use Models\Service;

class SearchController extends Controller {
    public function index() {
        $query = trim($this->input('s', ''));
        $results = [];

        if (!empty($query)) {
            $db = \Core\Database::getInstance();
            $searchTerm = "%{$query}%";

            // Search Posts
            $posts = $db->fetchAll("SELECT title, slug, excerpt as desc, 'blog' as type FROM {$db->t('posts')} WHERE status = 'published' AND (title LIKE ? OR content LIKE ?) LIMIT 10", [$searchTerm, $searchTerm]);
            
            // Search Pages
            $pages = $db->fetchAll("SELECT title, slug, meta_description as desc, 'page' as type FROM {$db->t('pages')} WHERE status = 'published' AND (title LIKE ? OR content LIKE ?) LIMIT 5", [$searchTerm, $searchTerm]);

            // Search Services
            $services = $db->fetchAll("SELECT title, slug, excerpt as desc, 'service' as type FROM {$db->t('services')} WHERE status = 'published' AND (title LIKE ? OR content LIKE ?) LIMIT 5", [$searchTerm, $searchTerm]);

            $results = array_merge($posts, $pages, $services);
        }

        $this->frontendView('search/index', [
            'pageTitle' => 'Search Results for: ' . htmlspecialchars($query),
            'query' => $query,
            'results' => $results
        ]);
    }
}
