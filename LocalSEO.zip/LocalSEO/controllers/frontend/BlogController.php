<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Post;
use Models\Category;

class BlogController extends Controller {
    public function index() {
        $postModel = new Post();
        $page = (int)$this->input('p', 1);
        $perPage = (int)$this->setting('posts_per_page', 10);
        
        $posts = $postModel->paginate($page, $perPage, "status = 'published'", [], 'published_at DESC');

        $data = [
            'posts' => $posts,
            'pageTitle' => 'Blog - Local SEO Tips & Strategies | LocalSEO.pk',
            'metaDescription' => 'Read our latest insights, tips, and strategies for improving your local SEO and dominating local search in Pakistan.',
            'canonicalUrl' => APP_URL . '/blog' . ($page > 1 ? '?p=' . $page : '')
        ];

        $this->frontendView('blog/index', $data);
    }

    public function show(string $slug) {
        $postModel = new Post();
        $post = $postModel->findBySlug($slug);

        if (!$post || $post['status'] !== 'published') {
            http_response_code(404);
            $this->frontendView('404', ['pageTitle' => 'Post Not Found']);
            return;
        }

        $postFull = $postModel->getWithAuthor($post['id']);
        $categories = $postModel->getCategories($post['id']);
        $tags = $postModel->getTags($post['id']);

        // Internal linker processing
        if ($this->setting('seo_auto_links_enabled', '0') === '1') {
            $linker = new \Core\InternalLinker();
            $postFull['content'] = $linker->processAutoLinks($postFull['content'], $post['id']);
        }

        $data = [
            'post' => $postFull,
            'categories' => $categories,
            'tags' => $tags,
            'pageTitle' => $post['seo_title'] ?: $post['title'],
            'metaDescription' => $post['meta_description'] ?: $post['excerpt'],
            'canonicalUrl' => $post['canonical_url'] ?: APP_URL . '/blog/' . $post['slug'],
            'schema' => json_decode($post['schema_data'] ?? '[]', true),
            'robots' => []
        ];

        if ($post['robots_index'] === 'noindex') $data['robots'][] = 'noindex';
        if ($post['robots_follow'] === 'nofollow') $data['robots'][] = 'nofollow';

        $this->frontendView('blog/single', $data);
    }
}
