<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Testimonial;

class TestimonialController extends Controller {
    public function index() {
        $model = new Testimonial();
        $testimonials = $model->all("status = 'active'", [], 'order_index ASC, created_at DESC');

        $this->frontendView('testimonials/index', [
            'pageTitle' => 'Client Testimonials - See What Our Clients Say | LocalSEO.pk',
            'metaDescription' => 'Read reviews and testimonials from businesses across Pakistan who have achieved local search dominance with LocalSEO.pk.',
            'testimonials' => $testimonials
        ]);
    }
}
