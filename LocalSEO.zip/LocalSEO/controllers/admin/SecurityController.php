<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\BlockedIp;
use Models\SecurityLog;

class SecurityController extends Controller {
    public function index() {
        $this->requireAuth();
        $this->log();
    }

    public function log() {
        $this->requireAuth();
        
        $logModel = new SecurityLog();
        $logs = $logModel->all('', [], 'created_at DESC LIMIT 100');
        
        $this->renderAdmin('admin/security/log', [
            'pageTitle' => 'Security Logs',
            'logs' => $logs
        ]);
    }

    public function blockedIps() {
        $this->requireAuth();
        
        $blockedModel = new BlockedIp();
        $ips = $blockedModel->all('', [], 'created_at DESC');
        
        $this->renderAdmin('admin/security/blocked-ips', [
            'pageTitle' => 'Blocked IPs',
            'ips' => $ips
        ]);
    }

    public function blockIP() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $ip = $_POST['ip_address'] ?? '';
        $reason = $_POST['reason'] ?? 'Manual block';
        
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            Helpers::flash('error', 'Invalid IP address.');
            Helpers::back();
        }
        
        $blockedModel = new BlockedIp();
        $blockedModel->create([
            'ip_address' => $ip,
            'reason' => $reason,
            'is_permanent' => 1
        ]);
        
        Helpers::flash('success', "IP $ip has been blocked.");
        Helpers::back();
    }

    public function unblockIP($id) {
        $this->requireAuth();
        
        $blockedModel = new BlockedIp();
        $blockedModel->delete((int)$id);
        
        Helpers::flash('success', 'IP unblocked.');
        Helpers::back();
    }

    public function settings() {
        $this->requireAuth();
        
        $this->renderAdmin('admin/security/settings', [
            'pageTitle' => 'Security Settings'
        ]);
    }

    public function saveSettings() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $settings = new \Models\Setting();
        $settings->set('security_login_max_attempts', $_POST['max_attempts'] ?? '5', 'security');
        $settings->set('security_lockout_duration', $_POST['lockout_duration'] ?? '15', 'security');
        $settings->set('security_block_suspicious', $_POST['block_suspicious'] ?? '1', 'security');
        
        Helpers::flash('success', 'Security settings updated.');
        Helpers::back();
    }
}
