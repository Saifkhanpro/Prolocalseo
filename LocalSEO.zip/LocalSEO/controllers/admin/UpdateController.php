<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;

class UpdateController extends Controller {
    const MANIFEST_URL = 'https://updates.localseo.pk/manifest.json';

    public function index() {
        $this->requireAuth();
        
        $currentVersion = defined('LSEO_VERSION') ? LSEO_VERSION : '1.0.0';
        $updateAvailable = Helpers::setting('update_available', '0') === '1';
        
        $this->renderAdmin('admin/updates/index', [
            'pageTitle' => 'System Updates',
            'currentVersion' => $currentVersion,
            'updateAvailable' => $updateAvailable,
            'lastCheck' => Helpers::setting('last_update_check', 'Never')
        ]);
    }

    public function check() {
        $this->requireAuth();
        
        // Simulation of update check
        $settings = new \Models\Setting();
        $settings->set('last_update_check', date('Y-m-d H:i:s'), 'system');
        
        // For demo: randomly say an update is available or not
        $isAvailable = (rand(0, 10) > 7) ? '1' : '0';
        $settings->set('update_available', $isAvailable, 'system');
        
        if ($isAvailable === '1') {
            Helpers::flash('info', 'A new version of LocalSEO.pk is available!');
        } else {
            Helpers::flash('success', 'Your system is up to date.');
        }
        
        Helpers::back();
    }

    public function install() {
        $this->requireAuth();
        
        // Simulation of update installation
        // In real world, this would download a zip, extract, and run migrations
        
        $settings = new \Models\Setting();
        $settings->set('update_available', '0', 'system');
        
        Helpers::flash('success', 'System updated successfully to version 1.1.0 (Simulation).');
        Helpers::back();
    }

    public function history() {
        $this->requireAuth();
        $this->renderAdmin('admin/updates/history', [
            'pageTitle' => 'Update History'
        ]);
    }
}
