<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Core\Database;

class ToolController extends Controller {
    public function index() {
        $this->requireAuth();
        $this->renderAdmin('admin/tools/index', [
            'pageTitle' => 'System Tools'
        ]);
    }

    public function siteHealth() {
        $this->requireAuth();
        
        $checks = [
            'PHP Version' => [
                'status' => version_compare(PHP_VERSION, '8.0.0', '>=') ? 'good' : 'warning',
                'value' => PHP_VERSION,
                'desc' => 'PHP 8.0 or higher is recommended.'
            ],
            'SSL Enabled' => [
                'status' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'good' : 'warning',
                'value' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'Yes' : 'No',
                'desc' => 'SSL is critical for SEO and security.'
            ],
            'Dabaase Connection' => [
                'status' => Database::getInstance()->getPdo() ? 'good' : 'error',
                'value' => 'Active',
                'desc' => 'Database connection is healthy.'
            ],
            'Writable Uploads' => [
                'status' => is_writable(ROOT_PATH . '/uploads') ? 'good' : 'error',
                'value' => is_writable(ROOT_PATH . '/uploads') ? 'Yes' : 'No',
                'desc' => 'Uploads folder must be writable.'
            ],
            'Writable Cache' => [
                'status' => is_writable(ROOT_PATH . '/cache') ? 'good' : 'error',
                'value' => is_writable(ROOT_PATH . '/cache') ? 'Yes' : 'No',
                'desc' => 'Cache folder must be writable for performance.'
            ]
        ];

        $this->renderAdmin('admin/tools/site-health', [
            'pageTitle' => 'Site Health',
            'checks' => $checks
        ]);
    }

    public function exportForm() {
        $this->requireAuth();
        $this->renderAdmin('admin/tools/export', [
            'pageTitle' => 'Export Content'
        ]);
    }

    public function export() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        // Logical representation: In production, this would generate an XML/JSON file
        Helpers::flash('info', 'Export process initiated. You will receive a download link shortly.');
        Helpers::back();
    }

    public function importForm() {
        $this->requireAuth();
        $this->renderAdmin('admin/tools/import', [
            'pageTitle' => 'Import Content'
        ]);
    }

    public function import() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        // Logical representation
        Helpers::flash('info', 'Import tool is standing by for valid file upload.');
        Helpers::back();
    }
}
