<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\User;

class ProfileController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $user = new User();
        $currentUser = $user->find($_SESSION['user_id']);
        
        $this->renderAdmin('admin/profile/index', [
            'pageTitle' => 'My Profile',
            'user' => $currentUser
        ]);
    }

    public function update() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $id = (int)$_SESSION['user_id'];
        $data = [
            'display_name' => $_POST['display_name'] ?? '',
            'first_name' => $_POST['first_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'bio' => $_POST['bio'] ?? '',
            'website' => $_POST['website'] ?? '',
            'social_facebook' => $_POST['social_facebook'] ?? '',
            'social_twitter' => $_POST['social_twitter'] ?? '',
            'social_linkedin' => $_POST['social_linkedin'] ?? '',
            'social_instagram' => $_POST['social_instagram'] ?? ''
        ];
        
        $user = new User();
        $user->update($id, $data);
        
        Helpers::flash('success', 'Profile updated successfully.');
        Helpers::back();
    }

    public function changePassword() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $id = (int)$_SESSION['user_id'];
        $currentPass = $_POST['current_password'] ?? '';
        $newPass = $_POST['new_password'] ?? '';
        $confirmPass = $_POST['confirm_password'] ?? '';
        
        if ($newPass !== $confirmPass) {
            Helpers::flash('error', 'New passwords do not match.');
            Helpers::back();
        }
        
        $userModel = new User();
        $user = $userModel->find($id);
        
        if (!password_verify($currentPass, $user['password'])) {
            Helpers::flash('error', 'Current password is incorrect.');
            Helpers::back();
        }
        
        $userModel->update($id, ['password' => password_hash($newPass, PASSWORD_DEFAULT)]);
        
        Helpers::flash('success', 'Password changed successfully.');
        Helpers::back();
    }

    public function updateAvatar() {
        $this->requireAuth();
        // Placeholder for avatar upload logic
        Helpers::flash('info', 'Avatar upload feature coming soon.');
        Helpers::back();
    }
}
