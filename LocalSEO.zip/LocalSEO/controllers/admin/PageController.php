<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Page;

class PageController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $pageModel = new Page();
        $pages = $pageModel->getIdsFlatTree();

        $this->adminView('pages/index', [
            'pageTitle' => 'All Pages',
            'pages' => $pages,
            'counts' => [
                'all' => $pageModel->count("status != 'trash'"),
                'published' => $pageModel->count("status='published'"),
                'draft' => $pageModel->count("status='draft'")
            ]
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $pageModel = new Page();
        
        $this->adminView('pages/form', [
            'pageTitle' => 'Add New Page',
            'page' => null,
            'parents' => $pageModel->getIdsFlatTree()
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $pageModel = new Page();
        $page = $pageModel->find($id);

        if (!$page) {
            Helpers::flash('error', 'Page not found.');
            $this->redirect('/admin/pages');
            return;
        }

        $featuredImageUrl = '';
        if ($page['featured_image_id']) {
            $db = \Core\Database::getInstance();
            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$page['featured_image_id']]);
            if ($media) $featuredImageUrl = '/' . $media['file_path'];
        }

        $this->adminView('pages/form', [
            'pageTitle' => 'Edit Page',
            'page' => $page,
            'parents' => $pageModel->getIdsFlatTree(),
            'featuredImageUrl' => $featuredImageUrl
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $pageModel = new Page();
        $user = $this->auth->user();

        $title = $this->input('title');
        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $title, 'pages', $id);
        
        $content = $_POST['content'] ?? '';
        $seoTitle = $this->input('seo_title');
        $focusKw = $this->input('focus_keyword', '');

        $seoAnalyzer = new \Core\SEOAnalyzer();
        $seoAnalysis = $seoAnalyzer->analyze($content, $seoTitle ?: $title, $focusKw);
        $readAnalysis = $seoAnalyzer->getReadability($content);

        $status = $this->input('status', 'draft');
        $now = date('Y-m-d H:i:s');
        $publishedAt = $this->input('published_at');
        if ($status === 'published' && !$publishedAt) {
            $publishedAt = $now;
        }

        $parentId = (int)$this->input('parent_id');
        if ($parentId === 0 || $parentId === $id) $parentId = null;

        $data = [
            'author_id' => $id > 0 ? $pageModel->find($id)['author_id'] : $user['id'],
            'title' => $title,
            'slug' => $slug,
            'content' => $content,
            'status' => $status,
            'visibility' => $this->input('visibility', 'public'),
            'password' => $this->input('password', ''),
            'featured_image_id' => $this->input('featured_image_id') ?: null,
            'parent_id' => $parentId,
            'template' => $this->input('template', 'default'),
            'order_index' => (int)$this->input('order_index', 0),
            'focus_keyword' => $focusKw,
            'secondary_keywords' => $this->input('secondary_keywords', ''),
            'seo_title' => $seoTitle,
            'meta_description' => $this->input('meta_description', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'robots_advanced' => implode(',', (array)$this->input('robots_advanced', [])),
            'canonical_url' => $this->input('canonical_url', ''),
            'readability_score' => $readAnalysis['score'],
            'seo_score' => $seoAnalysis['score'],
            'schema_type' => $this->input('schema_type', 'WebPage'),
        ];

        if ($status === 'published') $data['published_at'] = $publishedAt;

        if ($id > 0) {
            $pageModel->update($id, $data);
            $this->security->logActivity('update_page', $user['id'], 'page', $id, "Updated page: {$title}");
            Helpers::flash('success', 'Page updated successfully.');
        } else {
            $id = $pageModel->create($data);
            $this->security->logActivity('create_page', $user['id'], 'page', $id, "Created page: {$title}");
            Helpers::flash('success', 'Page created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/pages/edit/' . $id);
    }
}
