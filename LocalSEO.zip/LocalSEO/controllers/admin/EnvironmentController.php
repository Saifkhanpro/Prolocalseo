<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Core\Database;

class EnvironmentController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $data = [
            'pageTitle' => 'Environment & System Info',
            'phpVersion' => PHP_VERSION,
            'serverSoftware' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'mysqlVersion' => $this->getMysqlVersion(),
            'loadedExtensions' => get_loaded_extensions(),
            'isModRewriteEnabled' => $this->isModRewriteEnabled(),
            'uploadMaxFilesize' => ini_get('upload_max_filesize'),
            'postMaxSize' => ini_get('post_max_size'),
            'memoryLimit' => ini_get('memory_limit'),
            'maxExecutionTime' => ini_get('max_execution_time'),
            'displayErrors' => ini_get('display_errors'),
        ];
        
        $this->renderAdmin('admin/environment/index', $data);
    }

    public function htaccess() {
        $this->requireAuth();
        $path = ROOT_PATH . '/.htaccess';
        $content = file_exists($path) ? file_get_contents($path) : '';
        
        $this->renderAdmin('admin/environment/htaccess', [
            'pageTitle' => 'Edit .htaccess',
            'content' => $content,
            'writable' => is_writable($path) || is_writable(ROOT_PATH)
        ]);
    }

    public function saveHtaccess() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $content = $_POST['content'] ?? '';
        $path = ROOT_PATH . '/.htaccess';
        
        if (file_put_contents($path, $content) !== false) {
            Helpers::flash('success', '.htaccess updated successfully.');
        } else {
            Helpers::flash('error', 'Failed to write .htaccess. Check file permissions.');
        }
        
        Helpers::back();
    }

    public function database() {
        $this->requireAuth();
        $db = Database::getInstance();
        $tables = $db->fetchAll("SHOW TABLE STATUS");
        
        $this->renderAdmin('admin/environment/database', [
            'pageTitle' => 'Database Management',
            'tables' => $tables
        ]);
    }

    private function getMysqlVersion() {
        try {
            return Database::getInstance()->fetchColumn("SELECT VERSION()");
        } catch (\Exception $e) {
            return 'Unknown';
        }
    }

    private function isModRewriteEnabled() {
        if (function_exists('apache_get_modules')) {
            return in_array('mod_rewrite', apache_get_modules());
        }
        return 'Unknown (Not Apache or function disabled)';
    }
}
