<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Core\Cache;
use Core\PageCache;

class CacheController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $cache = new Cache();
        $pageCache = new PageCache();
        
        $data = [
            'pageTitle' => 'Cache Management',
            'objectCacheSize' => $cache->getSize(),
            'objectCacheCount' => $cache->getFileCount(),
            'pageCacheSize' => $pageCache->getSize(),
            'pageCacheCount' => $pageCache->getFileCount(),
            'cacheEnabled' => Helpers::setting('cache_enabled', '1') === '1'
        ];
        
        $this->renderAdmin('admin/cache/index', $data);
    }

    public function clearAll() {
        $this->requireAuth();
        
        $cache = new Cache();
        $pageCache = new PageCache();
        
        $count = $cache->clear() + $pageCache->clear();
        
        Helpers::flash('success', "Cache cleared successfully. Total $count files removed.");
        Helpers::back();
    }

    public function clearType($type) {
        $this->requireAuth();
        
        if ($type === 'pages') {
            $count = (new PageCache())->clear();
        } else {
            $count = (new Cache($type))->clear();
        }
        
        Helpers::flash('success', ucfirst($type) . " cache cleared ($count files).");
        Helpers::back();
    }

    public function saveSettings() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $settings = new \Models\Setting();
        $settings->set('cache_enabled', $_POST['cache_enabled'] ?? '0', 'performance');
        $settings->set('cache_ttl', $_POST['cache_ttl'] ?? '3600', 'performance');
        $settings->set('cache_separate_mobile', $_POST['cache_separate_mobile'] ?? '1', 'performance');
        
        Helpers::flash('success', 'Cache settings updated.');
        Helpers::back();
    }
}
