<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\Redirect;

class RedirectController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $model = new Redirect();
        $redirects = $model->all('', [], 'created_at DESC');
        
        $this->renderAdmin('admin/redirects/index', [
            'pageTitle' => '301 Redirects',
            'redirects' => $redirects
        ]);
    }

    public function store() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $data = [
            'old_url' => $_POST['old_url'] ?? '',
            'new_url' => $_POST['new_url'] ?? '',
            'type' => (int)($_POST['type'] ?? 301),
            'match_type' => $_POST['match_type'] ?? 'exact',
            'is_active' => isset($_POST['is_active']) ? 1 : 0
        ];
        
        if (empty($data['old_url']) || empty($data['new_url'])) {
            Helpers::flash('error', 'Both URLs are required.');
            Helpers::back();
        }
        
        $model = new Redirect();
        $model->create($data);
        
        Helpers::flash('success', 'Redirect added successfully.');
        Helpers::back();
    }

    public function update($id) {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $data = [
            'old_url' => $_POST['old_url'] ?? '',
            'new_url' => $_POST['new_url'] ?? '',
            'type' => (int)($_POST['type'] ?? 301),
            'match_type' => $_POST['match_type'] ?? 'exact',
            'is_active' => isset($_POST['is_active']) ? 1 : 0
        ];
        
        $model = new Redirect();
        $model->update((int)$id, $data);
        
        Helpers::flash('success', 'Redirect updated.');
        Helpers::back();
    }

    public function delete($id) {
        $this->requireAuth();
        (new Redirect())->delete((int)$id);
        Helpers::flash('success', 'Redirect deleted.');
        Helpers::back();
    }
}
