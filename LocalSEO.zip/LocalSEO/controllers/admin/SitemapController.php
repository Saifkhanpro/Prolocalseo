<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Core\SitemapGenerator;

class SitemapController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $this->renderAdmin('admin/sitemap/index', [
            'pageTitle' => 'Sitemap Settings',
            'lastGenerated' => Helpers::setting('sitemap_last_generated', 'Never'),
            'sitemapUrl' => APP_URL . '/sitemap.xml'
        ]);
    }

    public function generate() {
        $this->requireAuth();
        
        try {
            $generator = new SitemapGenerator();
            $generator->generateAll();
            
            $settings = new \Models\Setting();
            $settings->set('sitemap_last_generated', date('Y-m-d H:i:s'), 'seo');
            
            Helpers::flash('success', 'Sitemap generated successfully.');
        } catch (\Exception $e) {
            Helpers::flash('error', 'Sitemap generation failed: ' . $e->getMessage());
        }
        
        Helpers::back();
    }

    public function save() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $settings = new \Models\Setting();
        $settings->set('sitemap_include_posts', $_POST['include_posts'] ?? '1', 'seo');
        $settings->set('sitemap_include_pages', $_POST['include_pages'] ?? '1', 'seo');
        $settings->set('sitemap_include_services', $_POST['include_services'] ?? '1', 'seo');
        $settings->set('sitemap_include_cities', $_POST['include_cities'] ?? '1', 'seo');
        $settings->set('sitemap_include_images', $_POST['include_images'] ?? '1', 'seo');
        $settings->set('sitemap_frequency', $_POST['frequency'] ?? 'weekly', 'seo');
        
        Helpers::flash('success', 'Sitemap settings updated.');
        Helpers::back();
    }
}
