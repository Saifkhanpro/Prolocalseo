<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\Team;

class TeamController extends Controller {
    public function index() {
        $this->requireAuth();
        $model = new Team();
        $members = $model->all('', [], 'order_index ASC');
        
        $this->renderAdmin('admin/team/index', [
            'pageTitle' => 'Team Management',
            'members' => $members
        ]);
    }

    public function create() {
        $this->requireAuth();
        $this->renderAdmin('admin/team/create', [
            'pageTitle' => 'Add Team Member'
        ]);
    }

    public function store() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $data = $this->getPostData();
        
        $model = new Team();
        $model->create($data);
        
        Helpers::flash('success', 'Team member added.');
        header('Location: /admin/team');
        exit;
    }

    public function edit($id) {
        $this->requireAuth();
        $model = new Team();
        $member = $model->find((int)$id);
        
        if (!$member) {
            Helpers::flash('error', 'Member not found.');
            Helpers::back();
        }
        
        $this->renderAdmin('admin/team/edit', [
            'pageTitle' => 'Edit Team Member',
            'member' => $member
        ]);
    }

    public function update($id) {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $data = $this->getPostData();
        
        $model = new Team();
        $model->update((int)$id, $data);
        
        Helpers::flash('success', 'Team member updated.');
        header('Location: /admin/team');
        exit;
    }

    public function delete($id) {
        $this->requireAuth();
        (new Team())->delete((int)$id);
        Helpers::flash('success', 'Team member removed.');
        Helpers::back();
    }

    private function getPostData() {
        return [
            'name' => $_POST['name'] ?? '',
            'designation' => $_POST['designation'] ?? '',
            'bio' => $_POST['bio'] ?? '',
            'avatar_id' => !empty($_POST['avatar_id']) ? (int)$_POST['avatar_id'] : null,
            'facebook_url' => $_POST['facebook_url'] ?? '',
            'twitter_url' => $_POST['twitter_url'] ?? '',
            'linkedin_url' => $_POST['linkedin_url'] ?? '',
            'order_index' => (int)($_POST['order_index'] ?? 0),
            'status' => $_POST['status'] ?? 'active'
        ];
    }
}
