<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Core\Database;

class SpeedController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $db = Database::getInstance();
        $tables = $db->fetchAll("SHOW TABLE STATUS");
        
        $totalSize = 0;
        foreach ($tables as $table) {
            $totalSize += $table['Data_length'] + $table['Index_length'];
        }
        
        $this->renderAdmin('admin/speed/index', [
            'pageTitle' => 'Speed & Optimization',
            'tables' => $tables,
            'sitemapUrl' => APP_URL . '/sitemap.xml',
            'totalDbSize' => Helpers::formatBytes($totalSize)
        ]);
    }

    public function databaseCleanup() {
        $this->requireAuth();
        
        $db = Database::getInstance();
        $prefix = $db->getTablePrefix();
        
        // 1. Optimize tables
        $tables = $db->fetchAll("SHOW TABLES");
        foreach ($tables as $table) {
            $tableName = array_values($table)[0];
            $db->query("OPTIMIZE TABLE `$tableName`");
        }
        
        // 2. Delete old revisions (older than 30 days)
        $db->query("DELETE FROM {$prefix}revisions WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        
        // 3. Clear expired transients if implemented
        
        Helpers::flash('success', 'Database optimized and cleaned successfully.');
        Helpers::back();
    }

    public function save() {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') Helpers::back();
        
        $settings = new \Models\Setting();
        $settings->set('speed_minify_html', $_POST['minify_html'] ?? '0', 'performance');
        $settings->set('speed_combine_css', $_POST['combine_css'] ?? '0', 'performance');
        $settings->set('speed_lazy_load', $_POST['lazy_load'] ?? '1', 'performance');
        
        Helpers::flash('success', 'Performance settings saved.');
        Helpers::back();
    }
}
