<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\Comment;

class CommentController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $commentModel = new Comment();
        $db = \Core\Database::getInstance();
        $page = (int)$this->input('p', 1);
        $perPage = 20;
        
        $where = "1=1";
        $params = [];

        $s = $this->input('s');
        if ($s) {
            $where .= " AND (author_name LIKE ? OR author_email LIKE ? OR content LIKE ?)";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
        }

        $status = $this->input('status');
        if ($status && in_array($status, ['approved', 'pending', 'spam', 'trash'])) {
            $where .= " AND status = ?";
            $params[] = $status;
        } elseif (!$status) {
            $where .= " AND status != 'trash'";
        }

        $paginated = $commentModel->paginate($page, $perPage, $where, $params, "created_at DESC");

        // Attach post title
        foreach ($paginated['items'] as &$item) {
            $item['post_title'] = $db->fetchColumn("SELECT title FROM {$db->t('posts')} WHERE id = ?", [$item['post_id']]);
        }

        $this->adminView('comments/index', [
            'pageTitle' => 'Comments',
            'comments' => $paginated['items'],
            'pagination' => $paginated,
            'counts' => [
                'all' => $commentModel->count("status != 'trash'"),
                'pending' => $commentModel->count("status='pending'"),
                'approved' => $commentModel->count("status='approved'"),
                'spam' => $commentModel->count("status='spam'"),
                'trash' => $commentModel->count("status='trash'")
            ]
        ]);
    }

    public function action() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $action = $this->input('action');
        $ids = (array)$this->input('ids', []);

        if (empty($ids) || empty($action)) {
            $this->redirect('/admin/comments');
            return;
        }

        $commentModel = new Comment();
        $count = 0;

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($action === 'approve') {
                $commentModel->update($id, ['status' => 'approved']);
            } elseif ($action === 'unapprove') {
                $commentModel->update($id, ['status' => 'pending']);
            } elseif ($action === 'spam') {
                $commentModel->update($id, ['status' => 'spam']);
            } elseif ($action === 'trash') {
                $commentModel->update($id, ['status' => 'trash']);
            } elseif ($action === 'delete') {
                $commentModel->delete($id);
            }
            $count++;
        }

        if ($count > 0) {
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
            Helpers::flash('success', "Bulk action '{$action}' applied to {$count} comments.");
        }

        $this->redirect('/admin/comments');
    }
}
