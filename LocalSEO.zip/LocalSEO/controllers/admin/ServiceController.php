<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Service;

class ServiceController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $serviceModel = new Service();
        $services = $serviceModel->all('order_index ASC');

        $this->adminView('services/index', [
            'pageTitle' => 'Local SEO Services',
            'services' => $services,
            'counts' => [
                'all' => $serviceModel->count(),
                'published' => $serviceModel->count("status='published'"),
                'draft' => $serviceModel->count("status='draft'")
            ]
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $this->adminView('services/form', [
            'pageTitle' => 'Add New Service',
            'service' => null
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $serviceModel = new Service();
        $service = $serviceModel->find($id);

        if (!$service) {
            Helpers::flash('error', 'Service not found.');
            $this->redirect('/admin/services');
            return;
        }

        $featuredImageUrl = '';
        if ($service['featured_image_id']) {
            $db = \Core\Database::getInstance();
            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$service['featured_image_id']]);
            if ($media) $featuredImageUrl = '/' . $media['file_path'];
        }

        $this->adminView('services/form', [
            'pageTitle' => 'Edit Service',
            'service' => $service,
            'featuredImageUrl' => $featuredImageUrl
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $serviceModel = new Service();
        $user = $this->auth->user();

        $title = $this->input('title');
        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $title, 'services', $id);
        
        $content = $_POST['content'] ?? '';
        $seoTitle = $this->input('seo_title');
        $focusKw = $this->input('focus_keyword', '');

        $seoAnalyzer = new \Core\SEOAnalyzer();
        $seoAnalysis = $seoAnalyzer->analyze($content, $seoTitle ?: $title, $focusKw);
        $readAnalysis = $seoAnalyzer->getReadability($content);

        $status = $this->input('status', 'draft');
        $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;

        $data = [
            'title' => $title,
            'slug' => $slug,
            'short_description' => $this->input('short_description', ''),
            'content' => $content,
            'icon_class' => $this->input('icon_class', ''),
            'featured_image_id' => $this->input('featured_image_id') ?: null,
            'status' => $status,
            'order_index' => (int)$this->input('order_index', 0),
            'price_range' => $this->input('price_range', ''),
            'focus_keyword' => $focusKw,
            'secondary_keywords' => $this->input('secondary_keywords', ''),
            'seo_title' => $seoTitle,
            'meta_description' => $this->input('meta_description', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'robots_advanced' => implode(',', (array)$this->input('robots_advanced', [])),
            'canonical_url' => $this->input('canonical_url', ''),
            'readability_score' => $readAnalysis['score'],
            'seo_score' => $seoAnalysis['score'],
            'schema_type' => $this->input('schema_type', 'Service'),
        ];

        if ($status === 'published' && $id == 0) $data['published_at'] = $publishedAt;

        if ($id > 0) {
            $serviceModel->update($id, $data);
            $this->security->logActivity('update_service', $user['id'], 'service', $id, "Updated service: {$title}");
            Helpers::flash('success', 'Service updated successfully.');
        } else {
            $id = $serviceModel->create($data);
            $this->security->logActivity('create_service', $user['id'], 'service', $id, "Created service: {$title}");
            Helpers::flash('success', 'Service created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/services/edit/' . $id);
    }
}
